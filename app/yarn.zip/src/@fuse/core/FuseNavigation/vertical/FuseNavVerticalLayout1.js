import List from '@mui/material/List';
import { styled } from '@mui/material/styles';
import clsx from 'clsx';
import { useDispatch, useSelector } from 'react-redux';
import FuseNavItem from '../FuseNavItem';
import {
  getPermisosSesionActualAPIAction,
  getSesionActualAPIAction
} from 'components/Managment/Users/store/actions'
import store from "app/store/index"
import { getCookie } from 'app/js/generalFunctions'
import { React, useEffect, useState } from 'react'

const StyledList = styled(List)(({ theme }) => ({
  '& .fuse-list-item': {
    '&:hover': {
      backgroundColor:
        theme.palette.mode === 'dark' ? 'rgba(255, 255, 255, 0.05)' : 'rgba(0,0,0,.04)',
    },
    '&:focus:not(.active)': {
      backgroundColor:
        theme.palette.mode === 'dark' ? 'rgba(255, 255, 255, 0.06)' : 'rgba(0,0,0,.05)',
    },
  },
  '&.active-square-list': {
    '& .fuse-list-item, & .active.fuse-list-item': {
      width: '100%',
      borderRadius: '0',
    },
  },
  '&.dense': {
    '& .fuse-list-item': {
      paddingTop: 0,
      paddingBottom: 0,
      height: 32,
    },
  },
}));





function FuseNavVerticalLayout1(props) {
  const { navigation, layout, active, dense, className, onItemClick } = props;
  const dispatch = useDispatch();
  const personLogin = useSelector(state => state.fuse.userComponente.person)
  const personLoginPermisos = useSelector(state => state.fuse.userComponente.personPermisos)



  function handleItemClick(item) {
    onItemClick?.(item);
  }




  useEffect(() => {
    dispatch(getPermisosSesionActualAPIAction({
      token: getCookie('token')
    }))

  }, []);


  useEffect(() => {

    if (personLoginPermisos.length > 0) {
      var ordenMenu = []

      //***********************MODULES

      //RISK
      if (personLoginPermisos.find((item) => item['name'] == "Can view risk management") == undefined) {
        ordenMenu.push(0)
      }

      //PEOPLE
      if (personLoginPermisos.find((item) => item['name'] == "Can view sub mision") == undefined) {
        ordenMenu.push(1)
      }

      //IMPROVEMENT
      if (personLoginPermisos.find((item) => item['name'] == "Can view improvement") == undefined) {
        ordenMenu.push(2)
      }

      //DELIVERABLES
      if (personLoginPermisos.find((item) => item['name'] == "Can view deliverable") == undefined) {
        ordenMenu.push(3)
      }

      //DATA KPI
      if (personLoginPermisos.find((item) => item['name'] == "Can view data kpi") == undefined) {
        ordenMenu.push(4)
      }

      //***********************MANAGEMENT

      //DIVISIONES
      if (personLoginPermisos.find((item) => item['name'] == "Can view division") == undefined) {
        ordenMenu.push(5)
      }

      //CONTRACT
      if (personLoginPermisos.find((item) => item['name'] == "Can view service") == undefined) {
        ordenMenu.push(6)
      }

      //DEPARTAMENTO
      if (personLoginPermisos.find((item) => item['name'] == "Can view direccion departamental") == undefined || personLoginPermisos.find((item) => item['name'] == "Can view departamento") == undefined) {
        ordenMenu.push(7)
      }

      //PROCESO
      if (personLoginPermisos.find((item) => item['name'] == "Can view process") == undefined) {
        ordenMenu.push(8)
      }

      //CATEGORIAS
      if (personLoginPermisos.find((item) => item['name'] == "Can view categorizacion") == undefined) {
        ordenMenu.push(9)
      }

      //KPI
      if (personLoginPermisos.find((item) => item['name'] == "Can view kpi") == undefined) {
        ordenMenu.push(10)
      }

      //REQUERIMENTS
      if (personLoginPermisos.find((item) => item['name'] == "Can view aplication") == undefined) {
        ordenMenu.push(11)
      }

      //LOG
      if (personLoginPermisos.find((item) => item['name'] == "Can view log accion") == undefined) {
        ordenMenu.push(12)
      }

      //***********************USER MANEGEMENT

      //USER
      if (personLoginPermisos.find((item) => item['name'] == "Can view user") == undefined) {
        ordenMenu.push(13)
      }

      //CUSTOMER
      if (personLoginPermisos.find((item) => item['name'] == "Can view customer") == undefined) {
        ordenMenu.push(14)
      }

      //LOG PEOPLE
      if (personLoginPermisos.find((item) => item['name'] == "Can view log cambios personas") == undefined) {
        ordenMenu.push(15)
      }

      //GRUPO DE PERMISOS
      if (personLoginPermisos.find((item) => item['name'] == "Can view group") == undefined) {
        ordenMenu.push(16)
      }


      ordenMenu.forEach(function (valor, indice, array) {
        document.getElementsByClassName("MuiButtonBase-root MuiListItem-root MuiListItem-gutters \
                                                    MuiListItem-padding MuiListItem-button fuse-list-item \
                                                    muiltr-l0s0kn-MuiButtonBase-root-MuiListItem-root")[valor].style.display = "none";
      });


      //OCULTAR EL MODULES SI NO VE NINGUN ITEM
      if (ordenMenu.indexOf(0) !== -1 && ordenMenu.indexOf(1) !== -1 && ordenMenu.indexOf(2) !== -1 && ordenMenu.indexOf(3) !== -1 && ordenMenu.indexOf(4) !== -1) {
        document.getElementsByClassName("MuiButtonBase-root MuiListItem-root MuiListItem-gutters MuiListItem-padding \
                                               MuiListItem-button fuse-list-item  \
                                               muiltr-1t4yqt2-MuiButtonBase-root-MuiListItem-root")[0].style.display = "none";

      }

      //OCULTAR EL MANAGEMENT SI NO VE NINGUN ITEM
      if (ordenMenu.indexOf(5) !== -1 && ordenMenu.indexOf(6) !== -1 && ordenMenu.indexOf(7) !== -1 && ordenMenu.indexOf(8) !== -1 && ordenMenu.indexOf(9) !== -1 && ordenMenu.indexOf(10) !== -1 && ordenMenu.indexOf(11) !== -1 && ordenMenu.indexOf(12) !== -1) {
        document.getElementsByClassName("MuiButtonBase-root MuiListItem-root MuiListItem-gutters MuiListItem-padding \
                                               MuiListItem-button fuse-list-item  \
                                               muiltr-1t4yqt2-MuiButtonBase-root-MuiListItem-root")[1].style.display = "none";

      }

      //OCULTAR EL USER MANAGEMENT SI NO VE NINGUN ITEM
      if (ordenMenu.indexOf(13) !== -1 && ordenMenu.indexOf(14) !== -1 && ordenMenu.indexOf(15) !== -1 && ordenMenu.indexOf(16) !== -1) {
        document.getElementsByClassName("MuiButtonBase-root MuiListItem-root MuiListItem-gutters MuiListItem-padding \
                                               MuiListItem-button fuse-list-item  \
                                               muiltr-1t4yqt2-MuiButtonBase-root-MuiListItem-root")[2].style.display = "none";

      }

    }




  }, [personLoginPermisos, personLogin]);


  return (
    <StyledList
      className={clsx(
        'navigation whitespace-nowrap px-12',
        `active-${active}-list`,
        dense && 'dense',
        className
      )}
    >
      {navigation.map((_item) => (

        <FuseNavItem
          key={_item.id}
          type={`vertical-${_item.type}`}
          item={_item}
          nestedLevel={0}
          onItemClick={handleItemClick}
        />
      ))}
    </StyledList>
  );
}

export default FuseNavVerticalLayout1;
