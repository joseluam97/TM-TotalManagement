import FuseHighlight from '@fuse/core/FuseHighlight';
import AppBar from '@mui/material/AppBar';
import Card from '@mui/material/Card';
import Icon from '@mui/material/Icon';
import Tab from '@mui/material/Tab';
import Tabs from '@mui/material/Tabs';
import clsx from 'clsx';
import PropTypes from 'prop-types';
import { useState } from 'react';
import DemoFrame from './DemoFrame';

const propTypes = {
  name: PropTypes.string,
  raw: PropTypes.object,
  currentTabIndex: PropTypes.number,
};

const defaultProps = {
  name: '',
  currentTabIndex: 0,
};

function FuseExample(props) {
  const [currentTab, setCurrentTab] = useState(props.currentTabIndex);
  const { component: Component, raw, iframe, className, name } = props;

  function handleChange(event, value) {
    setCurrentTab(value);
  }

  return (
    <Card className={clsx(className, 'shadow')}>
      <AppBar position="static" color="default" className="shadow-0">
        <Tabs
          classes={{
            root: 'border-b-1',
            flexContainer: 'justify-end',
          }}
          value={currentTab}
          onChange={handleChange}
        >
          {Component && <Tab classes={{ root: 'min-w-64' }} icon={<Icon>remove_red_eye</Icon>} />}
          {raw && <Tab classes={{ root: 'min-w-64' }} icon={<Icon>code</Icon>} />}
        </Tabs>
      </AppBar>
      <div className="flex justify-center max-w-full relative">
        <div className={currentTab === 0 ? 'flex flex-1 max-w-full' : 'hidden'}>
          {Component &&
            (iframe ? (
              <DemoFrame name={name}>
                <Component />
              </DemoFrame>
            ) : (
              <div className="p-24 flex flex-1 justify-center max-w-full">
                <Component />
              </div>
            ))}
        </div>
        <div className={currentTab === 1 ? 'flex flex-1' : 'hidden'}>
          {raw && (
            <div className="flex flex-1">
              <FuseHighlight
                component="pre"
                className="language-javascript w-full"
                sx={{ borderRadius: '0!important' }}
              >
                {raw.default}
              </FuseHighlight>
            </div>
          )}
        </div>
      </div>
    </Card>
  );
}

FuseExample.propTypes = propTypes;
FuseExample.defaultProps = defaultProps;

export default FuseExample;
