//**********************IMPORTACIONES****************************
import * as global from 'global.js';
import { useEffect, useState, useRef } from 'react'
import * as React from 'react';
import Button from '@mui/material/Button';
import TextField from '@mui/material/TextField';
import Dialog from '@mui/material/Dialog';
import DialogActions from '@mui/material/DialogActions';
import DialogContent from '@mui/material/DialogContent';
import DialogTitle from '@mui/material/DialogTitle';
import { makeStyles } from "@material-ui/core/styles";
import InputLabel from '@mui/material/InputLabel';
import MenuItem from '@mui/material/MenuItem';
import FormControl from '@mui/material/FormControl';
import Select, { SelectChangeEvent } from '@mui/material/Select';
import Autocomplete from '@mui/material/Autocomplete';
import { showMessage } from 'app/store/fuse/messageSlice'
//Grid importaciones
import Grid from '@mui/material/Grid';

//Redux importaciones
import { useDispatch, useSelector } from 'react-redux'
//import { cambiarVisibilidadModalInsertarConjuntoAction, insertarProgramaModalInsertarAction, mostrarProgramasAPIAction } from  '../store/actions'
import {

  cambiarValorSeleccionAction,
  cambiarVisibilidadModalInsertarAction,
  insertarSubDivisionModalInsertarAction,
  actualizarSubDivisionModalInsertarAction
} from '../store/actions'

import {
  insertarLogPersonaAPIAction
} from '../../../Managment/LogCambiosPersonas/store/actions'


//**********************END_IMPORTACIONES ***********************/


const useStyles = makeStyles({

  customDialogTitle: {
    backgroundColor: 'rgb(37, 47, 62)',
    color: 'rgb(255, 255, 255)',
    marginBottom: '2em'
  }

});




export function ModalInsertar() {

  const classes = useStyles();
  const dispatch = useDispatch()

  //estados locales del formulario

  const [divisionList, setDivisionListAPI] = useState('')
  const [nombreActual, setNombreActual] = useState('')
  const [descripcionActual, setDescripcionActual] = useState('')
  const [botonControlSave, setBotonControl] = React.useState(true);
  const [responsableActual, setResponsableActual] = useState('')
  const [incidenciaUsuarios, setIncidenciaUsuarios] = useState(false);

  //end_locales_formularios


  // Obtener los states de Redux
  const visibilidadModalInsertar = useSelector(state => state.fuse.subDivisionComponente.visibilidadModalInsertar)
  const errorGlobal = useSelector(state => state.fuse.subDivisionComponente.error)
  const divisionListAPI = useSelector(state => state.fuse.divisionComponente.divisionesListAPI)
  const filaSeleccionadaGrid = useSelector(state => state.fuse.subDivisionComponente.filaSeleccionadaGrid)
  const modo = useSelector(state => state.fuse.subDivisionComponente.modo)
  const subDivisionListAPI = useSelector(state => state.fuse.subDivisionComponente.subdivisionesListAPI)
  const divisionesListAPI = useSelector(state => state.fuse.divisionComponente.divisionesListAPI)
  const usersListAPI = useSelector(state => state.fuse.userComponente.usersListAPI)
  const newSDCreated = useSelector(state => state.fuse.subDivisionComponente.newSDCreated)

  //Creamos funciones para hacer uso de Actions Redux
  const mostrarSubConjuntosAPI = () => dispatch(mostrarSubConjuntosAPIAction())
  const crearConjuntoAPI = (conjunto) => dispatch(insertarSubDivisionModalInsertarAction(conjunto))
  const updateConjuntoAPI = (id, conjunto) => dispatch(actualizarSubDivisionModalInsertarAction(id, conjunto))
  const cambiarVisibilidadModalInsertar = (valor, modo) => dispatch(cambiarVisibilidadModalInsertarAction(valor, modo))
  const cambiarValorSeleccion = (valor) => dispatch(cambiarValorSeleccionAction(valor))
  const insertarLogPersonaAPI = (logAdd) => dispatch(insertarLogPersonaAPIAction(logAdd))

  useEffect(() => {
    if (incidenciaUsuarios == false && divisionList != '' &&
      nombreActual.trim() != '' && responsableActual != '' && responsableActual != null && responsableActual != undefined) {
      //descripcionActual.trim() != '') {
      setBotonControl(false)

    } else {
      setBotonControl(true)

    }
  })

  useEffect(() => {
    if (responsableActual != '' && responsableActual != null && responsableActual != undefined) {

      let vectorIncidencias = [global.rolN8, global.rolN7, global.rolN6, global.rolN5, global.rolN4, global.rolN3]

      //INCIDENCIAS
      if(vectorIncidencias.indexOf(responsableActual.rolUser) != -1){
        setIncidenciaUsuarios(true)

        dispatch(
          showMessage({
            message: "You have assigned a person to a place to which you should assign Departmental Directorate or higher.",
            variant: "error"
          })
        )
      }
      //TODO OK
      else{
        setIncidenciaUsuarios(false)
      }
    }


  }, [responsableActual])

  useEffect(() => {
    //SE HA CREADO UN NUEVO WP, POR TANTO VAMOS A COMPROBAR SI SE HAN REALIZADO OPERACIONES DE INSERCCION DE USUARIOS
    if (newSDCreated != '') {
      let usuarioSeleccionado = usersListAPI.filter(elemento => elemento.id == newSDCreated['manager'])[0]
      if (usuarioSeleccionado != undefined) {
          insertarLogPersonaAPI({
            persona: usuarioSeleccionado['id'],
            fecha_accion: new Date().toISOString().split("T")[0],
            hora_accion: new Date().toLocaleTimeString(),
            accion: "Add",
            subDivision_relacionado: newSDCreated['id'],
            descripcion: "User with IDRes:" + usuarioSeleccionado['IDRes'] + " added to Sub Division " + newSDCreated['name']
          })
      }

      
    }

  }, [newSDCreated])

  function crearConjunto() {

    if (modo == 'nuevo') {
      crearConjuntoAPI({

        id_division: divisionList,
        name: nombreActual,
        description: descripcionActual,
        manager: responsableActual.id
      })
    }

    if (modo == 'editar') {
      updateConjuntoAPI(filaSeleccionadaGrid, {

        id_division: divisionList,
        name: nombreActual,
        description: descripcionActual,
        manager: responsableActual.id
      })

      let subDivisionSelected = subDivisionListAPI.filter(registro => registro.id == filaSeleccionadaGrid)[0]

      if (subDivisionSelected.manager != responsableActual.id) {
        let userDelete = usersListAPI.filter(registro => registro.id == subDivisionSelected.manager)[0]
        //ADD
        insertarLogPersonaAPI({
            persona: responsableActual.id,
            fecha_accion: new Date().toISOString().split("T")[0],
            hora_accion: new Date().toLocaleTimeString(),
            accion: "Add",
            subDivision_relacionado: subDivisionSelected.id,
            descripcion: "User with IDRes:" + responsableActual.IDRes + " added to Sub Division " + subDivisionSelected.name
          })

        //REMOVE
        insertarLogPersonaAPI({
            persona: userDelete.id,
            fecha_accion: new Date().toISOString().split("T")[0],
            hora_accion: new Date().toLocaleTimeString(),
            accion: "Remove",
            subDivision_relacionado: subDivisionSelected.id,
            descripcion: "User with IDRes:" + userDelete.IDRes + " removed to Sub Division " + subDivisionSelected.name
          })
      }


    }


    cambiarVisibilidadModalInsertar(false, '');
    mostrarSubConjuntosAPI();

  }

  useEffect(() => {
    if (modo == 'nuevo') {
      setDivisionListAPI('')
      setNombreActual('')
      setDescripcionActual('')
      setResponsableActual('')
    }

    if (modo == 'editar') {
      let subConjuntoSelected = subDivisionListAPI.filter(registro => registro.id == filaSeleccionadaGrid)[0]

      let divisionSelected = divisionesListAPI.filter(registro => registro.id == subConjuntoSelected.id_division)[0]
      let userManager = usersListAPI.filter(registro => registro.id == subConjuntoSelected.manager)[0]

      if (subConjuntoSelected != null) {
        setDivisionListAPI(divisionSelected.id)
        setNombreActual(subConjuntoSelected.name)
        setDescripcionActual(subConjuntoSelected.description)
        setResponsableActual(userManager)
      }
    }

  }, [modo])


  return (
    <Dialog open={visibilidadModalInsertar} onClose={() => cambiarVisibilidadModalInsertar(false, '')} fullWidth maxWidth='md'>
      <DialogTitle classes={{ root: classes.customDialogTitle }} >
        {modo == 'nuevo' ? "New Sub Division" : "Edit Sub Division"}
      </DialogTitle>
      <DialogContent>

        <Grid container spacing={2} columns={16} style={{ marginTop: "1px" }}>
          <Grid item xs={8}>
            <FormControl variant="outlined" fullWidth size="small">
              <InputLabel id="label-select-subdivision">Division</InputLabel>
              <Select
                labelId="label-select-subdivision"
                id="division"
                label="division"
                onChange={e => setDivisionListAPI(e.target.value)}
                value={divisionList}
              >
                {divisionListAPI.map((elemento, index) => (
                  <MenuItem key={index} value={elemento.id}> {elemento.name} </MenuItem>
                ))}
              </Select>
            </FormControl>


          </Grid>
          <Grid item xs={8}>

            <TextField
              label="Name"
              id="nombre"
              value={nombreActual}
              size="small"
              fullWidth
              onChange={e => setNombreActual(e.target.value)}
            />

          </Grid>
          <Grid item xs={8}>

            <Autocomplete
              id="tags-outlined"
              options={usersListAPI}
              value={responsableActual != undefined ? responsableActual : ''}
              getOptionLabel={(option) =>
                option.first_name != null ? option.IDRes + " - " + option.first_name + " " + option.last_name : ''
              }
              onChange={(event, value) => setResponsableActual(value)}
              filterSelectedOptions
              renderInput={(params) => (
                <TextField
                  {...params}
                  label="Manager"
                  placeholder="Manager"
                  size="small"
                  fullWidth
                />
              )}
            />


          </Grid>
          <Grid item xs={8}>

            <TextField
              id="descripcion"
              label="Description"
              multiline
              rows={5}
              value={descripcionActual}
              size="small"
              fullWidth
              onChange={e => setDescripcionActual(e.target.value)}
            />

          </Grid>

        </Grid>



      </DialogContent>
      <DialogActions>


        <Button onClick={() => cambiarVisibilidadModalInsertar(false, '')}>Close</Button>
        <Button disabled={botonControlSave} onClick={() => crearConjunto()}>Save</Button>

      </DialogActions>
    </Dialog>
  )
}

