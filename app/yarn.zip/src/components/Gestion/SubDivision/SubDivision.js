import { React, useEffect, useState } from 'react'

//DataGrid importaciones
import { DataGrid } from '@mui/x-data-grid';
import DeleteIcon from "@mui/icons-material/Delete";
import EditIcon from '@mui/icons-material/Edit';
import IconButton from "@mui/material/IconButton";
import Dialog from '@mui/material/Dialog';
import DialogActions from '@mui/material/DialogActions';
import DialogContent from '@mui/material/DialogContent';
import DialogTitle from '@mui/material/DialogTitle';
import Tooltip from '@mui/material/Tooltip';
import AddCircleIcon from '@mui/icons-material/AddCircle';
import FormControl from '@mui/material/FormControl';
import Select, { SelectChangeEvent } from '@mui/material/Select';
import MenuItem from '@mui/material/MenuItem';
import {
  gridPageCountSelector,
  gridPageSelector,
  useGridApiContext,
  useGridSelector,
  GridToolbarExport,
  GridToolbarDensitySelector,
  GridToolbarFilterButton,
  GridToolbarColumnsButton,
  GridToolbarContainer
} from '@mui/x-data-grid';
import Pagination from '@mui/material/Pagination';
import Divider from '@mui/material/Divider';

import { useDispatch, useSelector } from 'react-redux'
import store from "app/store/index"
import { getCookie } from 'app/js/generalFunctions'
import Button from '@mui/material/Button';
import { makeStyles } from "@material-ui/core/styles";

import {

  cambiarValorSeleccionAction,
  mostrarSubDivisionsAPIAction,
  cambiarVisibilidadModalInsertarAction,
  insertarSubDivisionModalInsertarAction,
  actualizarSubDivisionModalInsertarAction
} from './store/actions'

import {
  getPermisosSesionActualAPIAction
} from '../../Managment/Users/store/actions'

//Modales importaciones
import {ModalInsertar} from './modals/insertar.js'
import TableModules from '../../tables/TableModules'

import {insertarLogAPIAction} from '../../Managment/Log/store/actions'

const useStyles = makeStyles({

  customButtomPrograma: {

    margin: '1em'
  }

});

export default function GestionSubDivision() {

  const [numPagination, setNumPagination] = useState(10)
  const [addSubDivision, setAddSubDivision] = useState(true)
  const [changeSubDivision, setChangeSubDivision] = useState(true)
  const [deleteSubDivision, setDeleteSubDivision] = useState(true)
  const [visibilidadDialogoConfirmacion, setVisibilidadDialogoConfirmacion] = useState(false)

  const loading = useSelector(state => state.fuse.subDivisionComponente.loading)
  const visibilidad = useSelector(state => state.fuse.divisionViewComponente.valorTabDivision)
  const subdivisionesListAPI = useSelector(state => state.fuse.subDivisionComponente.subdivisionesListAPI)
  const filaSeleccionadaGrid = useSelector(state => state.fuse.subDivisionComponente.filaSeleccionadaGrid)
  const personLoginPermisos = useSelector(state => state.fuse.userComponente.personPermisos)
  const personLogin = useSelector(state => state.fuse.userComponente.person)

  const mostrarSubConjuntosAPI = () => dispatch(mostrarSubDivisionsAPIAction())
  const crearConjuntoAPI = (conjunto) => dispatch(insertarSubDivisionModalInsertarAction(conjunto))
  const updateSubDivision = (id, conjunto) => dispatch(actualizarSubDivisionModalInsertarAction(id, conjunto))
  const cambiarVisibilidadModalInsertar = (valor, modo) => dispatch(cambiarVisibilidadModalInsertarAction(valor, modo))
  const cambiarValorSeleccion = (valor) => dispatch(cambiarValorSeleccionAction(valor))

  const classes = useStyles();
  const dispatch = useDispatch()

  const columnasDataTable = [
    { Header: "Name", accessor: "name", sortable: true, type: 'string' },
    { Header: "Division", accessor: "id_division_name", sortable: true, type: 'list' },
    { Header: "Description", accessor: "description", sortable: true, type: 'string' }
  ]

  function deleteSubDivisionFuncion() {
    let subDivisionSelected = subdivisionesListAPI.filter(registro => registro.id == filaSeleccionadaGrid)[0]

    updateSubDivision(filaSeleccionadaGrid, {
      id_division: subDivisionSelected.id_division,
      name: subDivisionSelected.name,
      description: subDivisionSelected.description,
      active: false
    })

  }

  useEffect(() => {
    mostrarSubConjuntosAPI()

    //GET USER
    store.dispatch(getPermisosSesionActualAPIAction({

      token: getCookie('token')

    }))
    //FIN GET USER
  }, [])

  useEffect(() => {
    if(visibilidad == 'subDivision'){
      store.dispatch(insertarLogAPIAction({
        persona: personLogin['id'],
        fecha_accion: new Date().toISOString().split("T")[0],
        hora_accion: new Date().toLocaleTimeString(),
        modulo: "Sub division",
        descripcion: "Entrance to sub division module"
      }))
    }
    
  }, [visibilidad])

  useEffect(() => {

    if (personLoginPermisos.find((item) => item['name'] == "Can add sub division") != undefined) {
      setAddSubDivision(false)
    }

    if (personLoginPermisos.find((item) => item['name'] == "Can change sub division") != undefined) {
      setChangeSubDivision(false)
    }

    if (personLoginPermisos.find((item) => item['name'] == "Can delete sub division") != undefined) {
      setDeleteSubDivision(false)
    }

  }, [personLoginPermisos])

  function CustomPagination() {
    const apiRef = useGridApiContext();
    const page = useGridSelector(apiRef, gridPageSelector);
    const pageCount = useGridSelector(apiRef, gridPageCountSelector);

    function handleChange() {

    }

    return (
      <>
        <div>
          <div style={{ display: "inline" }}>
            <FormControl variant="standard" >
              <Select
                labelId="demo-simple-select-label"
                id="demo-simple-select"
                value={numPagination}
                label="Size"
                style={{ float: "right", position: "relative" }}
                onChange={e => { setNumPagination(e.target.value); }}
              >
                <MenuItem value={5}>5</MenuItem>
                <MenuItem value={10}>10</MenuItem>
                <MenuItem value={30}>30</MenuItem>
                <MenuItem value={50}>50</MenuItem>
                <MenuItem value={100}>100</MenuItem>
              </Select>
            </FormControl>
          </div>

          <div style={{ display: "inline", float: "right", position: "relative" }}>
            <Pagination
              color="primary"
              count={pageCount}
              page={page + 1}
              onChange={(event, value) => apiRef.current.setPage(value - 1)}
            />
          </div>
        </div>

      </>
    );
  }

  function botonesSuperiores() {
    return (
      <>

        <Tooltip title="New" placement="top">
          <IconButton variant="outlined" style={addSubDivision == false ? { display: "inline" } : { display: "none" }}>
            <AddCircleIcon variant="outlined" onClick={
              () => {
                cambiarVisibilidadModalInsertar(true, 'nuevo')
              }
            }
            >
            </AddCircleIcon>
          </IconButton>
        </Tooltip>

        <Tooltip title="New" placement="top">
          <IconButton disabled={filaSeleccionadaGrid != '' ? false : true} style={changeSubDivision == false ? { display: "inline" } : { display: "none" }}
            onClick={() => {
              cambiarVisibilidadModalInsertar(true, 'editar');
            }}
          >
            <EditIcon />
          </IconButton>
        </Tooltip>

        <Tooltip title="New" placement="top">
          <IconButton disabled={filaSeleccionadaGrid != '' ? false : true} style={deleteSubDivision == false ? { display: "inline" } : { display: "none" }}
            onClick={() => {
              setVisibilidadDialogoConfirmacion(true)


            }}
          >
            <DeleteIcon />
          </IconButton>
        </Tooltip>

        <Divider />
      </>
    );
  }

  return (
    <>
      <div style={visibilidad == 'subDivision' ? { display: "block" } : { display: "none" }}>

        <div style={{ width: '100%' }}>
          {botonesSuperiores()}
          <TableModules rowsProp={subdivisionesListAPI} columnsProp={columnasDataTable} loading={loading} funcionSetValue={cambiarValorSeleccion} />
        </div>

        <ModalInsertar />
      </div>
      <Dialog open={visibilidadDialogoConfirmacion} fullWidth maxWidth='xs'>

        <DialogTitle classes={{ root: classes.customDialogTitle }} >
          Confirmation
        </DialogTitle>
        <DialogContent>
          Are you sure you want to remove the sub division?
        </DialogContent>
        <DialogActions>

          <Button variant="outlined" onClick={() => setVisibilidadDialogoConfirmacion(false)}>Decline</Button>
          <Button variant="outlined" onClick={() => { deleteSubDivisionFuncion(), setVisibilidadDialogoConfirmacion(false) }}> Confirm</Button>

        </DialogActions>

      </Dialog>
    </>
  )

}
