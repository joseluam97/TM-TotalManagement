//**********************IMPORTACIONES****************************

import { useEffect, useState, useRef } from 'react'
import * as React from 'react';
import Button from '@mui/material/Button';
import TextField from '@mui/material/TextField';
import Dialog from '@mui/material/Dialog';
import DialogActions from '@mui/material/DialogActions';
import DialogContent from '@mui/material/DialogContent';
import DialogTitle from '@mui/material/DialogTitle';
import { makeStyles } from "@material-ui/core/styles";
import Checkbox from '@mui/material/Checkbox';


//Grid importaciones

import Grid from '@mui/material/Grid';

//Redux importaciones
import { useDispatch, useSelector } from 'react-redux'

import {

  cambiarValorSeleccionAction,
  mostrarDivisionsAPIAction,
  cambiarVisibilidadModalInsertarAction, 
  insertarDivisionModalInsertarAction, 
  actualizarDivisionModalInsertarAction
} from '../store/actions'


//**********************END_IMPORTACIONES ***********************/


const useStyles = makeStyles({

  customDialogTitle: {
    backgroundColor: 'rgb(37, 47, 62)',
    color: 'rgb(255, 255, 255)',
    marginBottom: '2em'
  }

});

export function ModalInsertar() {

  const classes = useStyles();
  const dispatch = useDispatch()

  //estados locales del formulario
  const [nombreActual, setNombreActual] = useState('')
  const [descripcionActual, setDescripcionActual] = useState('')

  //end_locales_formularios


  // Obtener los states de Redux
  const visibilidadModalInsertar = useSelector(state => state.fuse.divisionComponente.visibilidadModalInsertar)
  const errorGlobal = useSelector(state => state.fuse.divisionComponente.error)
  const filaSeleccionadaGrid = useSelector(state => state.fuse.divisionComponente.filaSeleccionadaGrid)
  const modo = useSelector(state => state.fuse.divisionComponente.modo)
  const divisionesList = useSelector(state => state.fuse.divisionComponente.divisionesListAPI)
  const [botonControlSave, setBotonControl] = React.useState(true);

  //Creamos funciones para hacer uso de Actions Redux
  const mostrarDivisionsAPI = () => dispatch(mostrarDivisionsAPIAction())
  const insertarDivisionModalInsertar = (conjunto) => dispatch(insertarDivisionModalInsertarAction(conjunto))
  const actualizarDivisionModalInsertar = (id, conjunto) => dispatch(actualizarDivisionModalInsertarAction(id, conjunto))
  const cambiarVisibilidadModalInsertar = (valor, modo) => dispatch(cambiarVisibilidadModalInsertarAction(valor, modo))
  const cambiarValorSeleccion = (valor) => dispatch(cambiarValorSeleccionAction(valor))
  
  useEffect(() => {
    if (nombreActual.trim() != '') {
      //descripcionActual.trim() != '') {
            setBotonControl(false)

    } else {
            setBotonControl(true)

    }
  })

  function crearConjunto() {
    
    if(modo == 'nuevo'){
      insertarDivisionModalInsertar({
        name: nombreActual,
        description: descripcionActual
      })
    }

    if(modo == 'editar'){
      actualizarDivisionModalInsertar(filaSeleccionadaGrid, {
        name: nombreActual,
        description: descripcionActual
      })
    }
    

    cambiarVisibilidadModalInsertar(false, '');
    mostrarDivisionsAPI();

  }

  useEffect(() => {
    if(modo == 'nuevo'){
      setNombreActual('')
      setDescripcionActual('')
    }

    if(modo == 'editar'){
      let divisionSelect = divisionesList.filter(registro => registro.id == filaSeleccionadaGrid)[0]

      if (divisionSelect != null) {
        setNombreActual(divisionSelect.name)
        setDescripcionActual(divisionSelect.description)
      }
    }

  }, [modo])


  return (
    <Dialog open={visibilidadModalInsertar} onClose={() => cambiarVisibilidadModalInsertar(false, '')} fullWidth maxWidth='md'>
      <DialogTitle classes={{ root: classes.customDialogTitle }} >
      {modo == 'nuevo' ? "New Division" : "Edit Division"}

      </DialogTitle>
      <DialogContent>

        <Grid container spacing={2} columns={16}>
          <Grid item xs={8}>

            <TextField
              label="Name"
              id="nombre"
              value={nombreActual}
              size="small"
              sx={{ m: 1, width: '37ch' }}
              onChange={e => setNombreActual(e.target.value)}
            />

          </Grid>
          <Grid item xs={8}>

            <TextField
              id="descripcion"
              label="Description"
              multiline
              rows={5}
              value={descripcionActual}
              size="small"
              sx={{ m: 1, width: '37ch' }}
              onChange={e => setDescripcionActual(e.target.value)}
            />

          </Grid>

        </Grid>



      </DialogContent>
      <DialogActions>


        <Button onClick={() => cambiarVisibilidadModalInsertar(false, '')}>Close</Button>
        <Button disabled={botonControlSave} onClick={() => crearConjunto()}>Save</Button>

      </DialogActions>
    </Dialog>
  )
}

