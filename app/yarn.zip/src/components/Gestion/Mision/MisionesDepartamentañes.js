import { React, useEffect, useState } from 'react'
import PersonIcon from '@mui/icons-material/Person';

//DataGrid importaciones
import FusePageCarded from '@fuse/core/FusePageCarded';
import Box from '@mui/material/Box';
import { DataGrid } from '@mui/x-data-grid';
import DeleteIcon from "@mui/icons-material/Delete";
import EditIcon from '@mui/icons-material/Edit';
import IconButton from "@mui/material/IconButton";
import store from "app/store/index"
import { getCookie } from 'app/js/generalFunctions'
import Tooltip from '@mui/material/Tooltip';
import AddCircleIcon from '@mui/icons-material/AddCircle';
import FormControl from '@mui/material/FormControl';
import Select, { SelectChangeEvent } from '@mui/material/Select';
import MenuItem from '@mui/material/MenuItem';
import AppsIcon from '@mui/icons-material/Apps';
import {
  gridPageCountSelector,
  gridPageSelector,
  useGridApiContext,
  useGridSelector,
  GridToolbarExport,
  GridToolbarDensitySelector,
  GridToolbarFilterButton,
  GridToolbarColumnsButton,
  GridToolbarContainer
} from '@mui/x-data-grid';
import Pagination from '@mui/material/Pagination';
import Divider from '@mui/material/Divider';

import { useDispatch, useSelector } from 'react-redux'

import Button from '@mui/material/Button';
import { makeStyles } from "@material-ui/core/styles";

import {
  mostrarMisionDepartamentosAPIAction,
  cambiarVisibilidadModalInsertarAPIAction,
  seleccionarMisionTablaAPIAction,
  cambiarVisibilidadModalRequerimentsAPIAction
} from './store/actions'

import {
  getPermisosSesionActualAPIAction
} from '../../Managment/Users/store/actions'

import {
  mostrarMisionPaquetesAPIAction,
  mostrarMisionPaquetesDepartamentalesAPIAction
} from '../PaqueteTrabajo/store/actions'

import { insertarLogAPIAction } from '../../Managment/Log/store/actions'

import ModalInsertar from './modals/insertar.js'
import ModalRequeriments from './modals/assignedAppMision.js'
import TableModules from '../../tables/TableModules'

const useStyles = makeStyles({

  customButtomPrograma: {

    margin: '1em'
  }

});

export default function MisionesDepartamentales() {

  const [numPagination, setNumPagination] = useState(10)

  const [disabledNewDepartament, setDisabledNewDepartament] = useState(true)
  const [disabledEditDepartament, setDisabledEditDepartament] = useState(true)
  const [disabledRequerimentsDepartament, setDisabledRequerimentsDepartament] = useState(true)

  const loading = useSelector(state => state.fuse.misionComponent.loading)
  const visibilidad = useSelector(state => state.fuse.programasView.valorTab)
  const listMisionAPI = useSelector(state => state.fuse.misionComponent.listMisionAPI)
  const filaSeleccionadaGrid = useSelector(state => state.fuse.misionComponent.filaSeleccionadaGrid)
  const personLoginPermisos = useSelector(state => state.fuse.userComponente.personPermisos)
  const personLogin = useSelector(state => state.fuse.userComponente.person)
  const valorTab = useSelector (state => state.fuse.departamentoViewComponente.valorTabDepartamento)

  const mostrarMisionDepartamentosAPI = () => dispatch(mostrarMisionDepartamentosAPIAction())
  const cambiarVisibilidadModalInsertarAPI = (valor, modo) => dispatch(cambiarVisibilidadModalInsertarAPIAction(valor, modo))
  const seleccionarMisionTablaAPI = (valor) => dispatch(seleccionarMisionTablaAPIAction(valor))
  const cambiarVisibilidadModalRequerimentsAPI = (valorNuevo) => dispatch(cambiarVisibilidadModalRequerimentsAPIAction(valorNuevo))
  const mostrarMisionPaquetesDepartamentalesAPI = () => dispatch(mostrarMisionPaquetesDepartamentalesAPIAction())

  const mostrarMisionPaquetesAPI = () => dispatch(mostrarMisionPaquetesAPIAction())

  const classes = useStyles();
  const dispatch = useDispatch()

  useEffect(() => {

    if (personLoginPermisos.length > 0) {

      if (personLoginPermisos.find((item) => item['name'] == "Can view mision") == undefined) {
        navigate('/')
      }

      if (personLoginPermisos.find((item) => item['name'] == "Can add mision") == undefined) {
        setDisabledNewDepartament(false)
      }

      if (personLoginPermisos.find((item) => item['name'] == "Can change mision") == undefined) {
        setDisabledEditDepartament(false)
      }

      if (personLoginPermisos.find((item) => item['name'] == "Can view mision app") == undefined) {
        setDisabledRequerimentsDepartament(false)
      }

    }

  }, [personLoginPermisos])

  const columnasDataTable = [
    { Header: "Name", accessor: "name", sortable: true, type: 'string' },
    { Header: "Code", accessor: "code", sortable: true, type: 'string' },
    { Header: "Area", accessor: "id_workPackage_name", sortable: true, type: 'list' },
    { Header: "Manager", accessor: "manager_name", sortable: true, type: 'list' }
  ]

  useEffect(() => {
    if(valorTab == 'misionesDepartamentales'){
      seleccionarMisionTablaAPI('');
      mostrarMisionDepartamentosAPI()
      mostrarMisionPaquetesAPI()

      mostrarMisionPaquetesDepartamentalesAPI()

      store.dispatch(insertarLogAPIAction({
        persona: personLogin['id'],
        fecha_accion: new Date().toISOString().split("T")[0],
        hora_accion: new Date().toLocaleTimeString(),
        modulo: "Misiones Departamentañes",
        descripcion: "Entrance to Misiones Departamentañes module"
      }))
    }

  }, [valorTab])

  function CustomPagination() {
    const apiRef = useGridApiContext();
    const page = useGridSelector(apiRef, gridPageSelector);
    const pageCount = useGridSelector(apiRef, gridPageCountSelector);

    function handleChange() {

    }

    return (
      <>
        <div>
          <div style={{ display: "inline" }}>
            <FormControl variant="standard" >
              <Select
                labelId="demo-simple-select-label"
                id="demo-simple-select"
                value={numPagination}
                label="Size"
                style={{ float: "right", position: "relative" }}
                onChange={e => { setNumPagination(e.target.value); }}
              >
                <MenuItem value={5}>5</MenuItem>
                <MenuItem value={10}>10</MenuItem>
                <MenuItem value={30}>30</MenuItem>
                <MenuItem value={50}>50</MenuItem>
                <MenuItem value={100}>100</MenuItem>
              </Select>
            </FormControl>
          </div>

          <div style={{ display: "inline", float: "right", position: "relative" }}>
            <Pagination
              color="primary"
              count={pageCount}
              page={page + 1}
              onChange={(event, value) => apiRef.current.setPage(value - 1)}
            />
          </div>
        </div>

      </>
    );
  }

  function botonesSuperiores() {
    return (
      <>

        <Tooltip title="New" placement="top">
          <IconButton variant="outlined" style={disabledNewDepartament == true ? { display: "inline" } : { display: "none" }}>
            <AddCircleIcon variant="outlined" onClick={
              () => {
                cambiarVisibilidadModalInsertarAPI(true, 'nuevo')
              }
            }
            >
            </AddCircleIcon>
          </IconButton>
        </Tooltip>
        <Tooltip title="Edit" placement="top">
          <IconButton style={disabledEditDepartament == true ? { display: "inline" } : { display: "none" }} disabled={filaSeleccionadaGrid != '' ? false : true}
            onClick={() => {
              cambiarVisibilidadModalInsertarAPI(true, 'editar')
            }}
          >
            <EditIcon />
          </IconButton>
        </Tooltip>

        <Tooltip title="Requirements" placement="top">
          <IconButton style={disabledRequerimentsDepartament == true ? { display: "inline" } : { display: "none" }} disabled={filaSeleccionadaGrid != '' ? false : true}
            onClick={() => {

              cambiarVisibilidadModalRequerimentsAPI(true);

            }}
          >
            <AppsIcon />
          </IconButton>
        </Tooltip>

        <Divider />
      </>
    );
  }

  return (
    <>
      <div style={valorTab == 'misionesDepartamentales' ? { display: "block" } : { display: "none" }}>

        <div style={{ width: '100%' }}>
          {botonesSuperiores()}
          <TableModules rowsProp={listMisionAPI} columnsProp={columnasDataTable} loading={loading} funcionSetValue={seleccionarMisionTablaAPI} />
        </div>
        <ModalInsertar />
        <ModalRequeriments />
      </div>
    </>
  )

}