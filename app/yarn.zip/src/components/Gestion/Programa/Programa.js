//**********************IMPORTACIONES****************************

import { React, useEffect, useState } from 'react'

//DataGrid importaciones
import { DataGrid } from '@mui/x-data-grid';
import DeleteIcon from "@mui/icons-material/Delete";
import EditIcon from '@mui/icons-material/Edit';
import IconButton from "@mui/material/IconButton";
import Dialog from '@mui/material/Dialog';
import DialogActions from '@mui/material/DialogActions';
import DialogContent from '@mui/material/DialogContent';
import DialogTitle from '@mui/material/DialogTitle';
import AddCircleIcon from '@mui/icons-material/AddCircle';
import Button from '@mui/material/Button';
import { showMessage } from 'app/store/fuse/messageSlice'
import { makeStyles } from "@material-ui/core/styles";
import store from "app/store/index"
import { getCookie } from 'app/js/generalFunctions'
import Tooltip from '@mui/material/Tooltip';

import FormControl from '@mui/material/FormControl';
import Select, { SelectChangeEvent } from '@mui/material/Select';
import MenuItem from '@mui/material/MenuItem';
import {
  gridPageCountSelector,
  gridPageSelector,
  useGridApiContext,
  useGridSelector,
  GridToolbarExport,
  GridToolbarDensitySelector,
  GridToolbarFilterButton,
  GridToolbarColumnsButton,
  GridToolbarContainer
} from '@mui/x-data-grid';
import Pagination from '@mui/material/Pagination';
import Divider from '@mui/material/Divider';

//Redux importaciones
import { useDispatch, useSelector } from 'react-redux'
import {
  mostrarProgramasAPIAction,
  cambiarVisibilidadModalInsertarAction,
  cambiarValorSeleccionAction,
  eliminarProgramaAction,
  consultaSubdivisionesAction,
  actualizarProgramaModalInsertarAction
} from './store/actions'

import {
  getPermisosSesionActualAPIAction
} from '../../Managment/Users/store/actions'

//Modales importaciones
import {ModalInsertar} from './modals/insertar.js'
import TableModules from '../../tables/TableModules'

import {insertarLogAPIAction} from '../../Managment/Log/store/actions'


//**********************END_IMPORTACIONES ***********************/



const useStyles = makeStyles({

  customButtomPrograma: {

    margin: '1em'
  }

});



export default function Programa() {

  const [numPagination, setNumPagination] = useState(10)
  const [addProgram, setAddProgram] = useState(true)
  const [changeProgram, setChangeProgram] = useState(true)
  const [deleteProgram, setDeleteProgram] = useState(true)
  const [visibilidadDialogoConfirmacion, setVisibilidadDialogoConfirmacion] = useState(false)

  const loading = useSelector(state => state.fuse.programaComponente.loading)
  //Obtener los states de Redux
  const visibilidad = useSelector(state => state.fuse.divisionViewComponente.valorTabDivision)
  //const visibilidad = useSelector(state => state.fuse.programaComponente.visibilidad)
  const programasListAPI = useSelector(state => state.fuse.programaComponente.programasListAPI)
  const filaSeleccionadaGrid = useSelector(state => state.fuse.programaComponente.filaSeleccionadaGrid)
  const errorGlobal = useSelector(state => state.fuse.programaComponente.error)
  const personLoginPermisos = useSelector(state => state.fuse.userComponente.personPermisos)
  const personLogin = useSelector(state => state.fuse.userComponente.person)

  //Creamos funciones para hacer uso de Actions Redux
  const cambiarVisibilidadModalInsertar = (valor, modoApertura) => dispatch(cambiarVisibilidadModalInsertarAction(valor, modoApertura))
  const mostrarProgramasAPI = () => dispatch(mostrarProgramasAPIAction())
  const cambiarValorSeleccion = (valor) => dispatch(cambiarValorSeleccionAction(valor))
  const eliminarPrograma = (id) => dispatch(eliminarProgramaAction(id))
  const consultaSubdivisiones = () => dispatch(consultaSubdivisionesAction())
  const actualizarProgramaModalInsertar = (id, programa) => dispatch(actualizarProgramaModalInsertarAction(id, programa))

  const classes = useStyles();
  const dispatch = useDispatch()

  const columnasDataTable = [
    { Header: "Name", accessor: "name", sortable: true, type: 'string' },
    { Header: "Sub Division", accessor: "id_subdivision_name", sortable: true, type: 'list' },
    { Header: "Description", accessor: "description", sortable: true, type: 'string' }
  ]

  function deletePrograma() {
    let programSelected = programasListAPI.filter(registro => registro.id == filaSeleccionadaGrid)[0]

    actualizarProgramaModalInsertar(filaSeleccionadaGrid, {
      id_subdivision: programSelected.id_subdivision,
      name: programSelected.name,
      description: programSelected.description,
      manager: programSelected.manager,
      active: false
    })

  }


  function alertaMensaje(mensaje, tipo) {
    dispatch(
      showMessage({
        message: mensaje,
        variant: tipo,
      })
    )
  }

  useEffect(() => {

    mostrarProgramasAPI()

    //GET USER
    store.dispatch(getPermisosSesionActualAPIAction({

      token: getCookie('token')

    }))
    //FIN GET USER

  }, []);

  useEffect(() => {
    if(visibilidad == 'programa'){
      store.dispatch(insertarLogAPIAction({
        persona: personLogin['id'],
        fecha_accion: new Date().toISOString().split("T")[0],
        hora_accion: new Date().toLocaleTimeString(),
        modulo: "Program",
        descripcion: "Entrance to Program module"
      }))
    }
    
  }, [visibilidad])


  useEffect(() => {

    if (personLoginPermisos.find((item) => item['name'] == "Can add program") != undefined) {
      setAddProgram(false)
    }

    if (personLoginPermisos.find((item) => item['name'] == "Can change program") != undefined) {
      setChangeProgram(false)
    }

    if (personLoginPermisos.find((item) => item['name'] == "Can delete program") != undefined) {
      setDeleteProgram(false)
    }

  }, [personLoginPermisos])

  function CustomPagination() {
    const apiRef = useGridApiContext();
    const page = useGridSelector(apiRef, gridPageSelector);
    const pageCount = useGridSelector(apiRef, gridPageCountSelector);

    function handleChange() {

    }

    return (
      <>
        <div>
          <div style={{ display: "inline" }}>
            <FormControl variant="standard" >
              <Select
                labelId="demo-simple-select-label"
                id="demo-simple-select"
                value={numPagination}
                label="Size"
                style={{ float: "right", position: "relative" }}
                onChange={e => { setNumPagination(e.target.value); }}
              >
                <MenuItem value={5}>5</MenuItem>
                <MenuItem value={10}>10</MenuItem>
                <MenuItem value={30}>30</MenuItem>
                <MenuItem value={50}>50</MenuItem>
                <MenuItem value={100}>100</MenuItem>
              </Select>
            </FormControl>
          </div>

          <div style={{ display: "inline", float: "right", position: "relative" }}>
            <Pagination
              color="primary"
              count={pageCount}
              page={page + 1}
              onChange={(event, value) => apiRef.current.setPage(value - 1)}
            />
          </div>
        </div>

      </>
    );
  }

  function botonesSuperiores() {
    return (
      <>
        <Tooltip title="New" placement="top">
          <IconButton variant="outlined" style={addProgram == false ? { display: "inline" } : { display: "none" }}>
            <AddCircleIcon variant="outlined" onClick={
              () => {
                cambiarVisibilidadModalInsertar(true, 'nuevo');
                consultaSubdivisiones()
              }
            }
            >
            </AddCircleIcon>
          </IconButton>
        </Tooltip>

        <Tooltip title="Edit" placement="top">
          <IconButton disabled={filaSeleccionadaGrid != '' ? false : true} style={changeProgram == false ? { display: "inline" } : { display: "none" }}
            onClick={() => {
              consultaSubdivisiones()
              cambiarVisibilidadModalInsertar(true, 'editar');
            }}
          >
            <EditIcon />
          </IconButton>
        </Tooltip>

        <Tooltip title="Delete" placement="top">
          <IconButton disabled={filaSeleccionadaGrid != '' ? false : true} style={deleteProgram == false ? { display: "inline" } : { display: "none" }}
            onClick={() => {

              mostrarProgramasAPI()
              setVisibilidadDialogoConfirmacion(true)

            }}
          >
            <DeleteIcon />
          </IconButton>
        </Tooltip>

        <Divider />
      </>
    );
  }

  return (
    <>
      <div style={visibilidad == 'programa' ? { display: "block" } : { display: "none" }}>

        <div style={{ width: '100%' }}>
          {botonesSuperiores()}
          <TableModules rowsProp={programasListAPI} columnsProp={columnasDataTable} loading={loading} funcionSetValue={cambiarValorSeleccion} />
        </div>

        <ModalInsertar />
      </div>

      <Dialog open={visibilidadDialogoConfirmacion} fullWidth maxWidth='xs'>

        <DialogTitle classes={{ root: classes.customDialogTitle }} >
          Confirmation
        </DialogTitle>
        <DialogContent>
          Are you sure you want to remove the program?
        </DialogContent>
        <DialogActions>

          <Button variant="outlined" onClick={() => setVisibilidadDialogoConfirmacion(false)}>Decline</Button>
          <Button variant="outlined" onClick={() => { deletePrograma(), setVisibilidadDialogoConfirmacion(false) }}> Confirm</Button>

        </DialogActions>

      </Dialog>

    </>
  )
}

