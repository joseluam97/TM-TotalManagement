//**********************IMPORTACIONES****************************

import { useEffect, useState, useRef } from 'react'
import * as React from 'react';
import Button from '@mui/material/Button';
import TextField from '@mui/material/TextField';
import Dialog from '@mui/material/Dialog';
import DialogActions from '@mui/material/DialogActions';
import DialogContent from '@mui/material/DialogContent';
import DialogTitle from '@mui/material/DialogTitle';
import { makeStyles } from "@material-ui/core/styles";
import InputLabel from '@mui/material/InputLabel';
import MenuItem from '@mui/material/MenuItem';
import FormControl from '@mui/material/FormControl';
import Select, { SelectChangeEvent } from '@mui/material/Select';
import Switch from '@mui/material/Switch';
import FormControlLabel from '@mui/material/FormControlLabel';
import Autocomplete from '@mui/material/Autocomplete';

//Grid importaciones
import Grid from '@mui/material/Grid';

//Redux importaciones
import { useDispatch, useSelector } from 'react-redux'
import {
  cambiarVisibilidadModalInsertarAction,
  insertarProgramaModalInsertarAction,
  mostrarProgramasAPIAction,
  consultaSubdivisionesAction,
  actualizarProgramaModalInsertarAction
} from '../store/actions'

import {
  mostrarUserAPIAction
} from '../../../Managment/Users/store/actions'

//**********************END_IMPORTACIONES ***********************/


const useStyles = makeStyles({

  customDialogTitle: {
    backgroundColor: 'rgb(37, 47, 62)',
    color: 'rgb(255, 255, 255)',
    marginBottom: '2em'
  }

});




export function ModalInsertar() {

  const classes = useStyles();
  const dispatch = useDispatch()

  //estados locales del formulario

  const [subdivisionActual, setSubdivisionActual] = useState('')
  const [nombreActual, setNombreActual] = useState('')
  const [descripcionActual, setDescripcionActual] = useState('')
  const [botonControlSave, setBotonControl] = React.useState(true);

  //end_locales_formularios


  // Obtener los states de Redux
  const visibilidadModalInsertar = useSelector(state => state.fuse.programaComponente.visibilidadModalInsertar)
  const subdivisionesListAPI = useSelector(state => state.fuse.programaComponente.subdivisionesListAPI)
  const programasListAPI = useSelector(state => state.fuse.programaComponente.programasListAPI)
  const filaSeleccionadaGrid = useSelector(state => state.fuse.programaComponente.filaSeleccionadaGrid)
  const modo = useSelector(state => state.fuse.programaComponente.modo)
  const usersListAPI = useSelector(state => state.fuse.userComponente.usersListAPI)

  //Creamos funciones para hacer uso de Actions Redux
  const cambiarVisibilidadModalInsertar = (valor, modoApertura) => dispatch(cambiarVisibilidadModalInsertarAction(valor, modoApertura))
  const insertarProgramaModalInsertar = (programa) => dispatch(insertarProgramaModalInsertarAction(programa))
  const actualizarProgramaModalInsertar = (id, programa) => dispatch(actualizarProgramaModalInsertarAction(id, programa))
  const mostrarProgramasAPI = () => dispatch(mostrarProgramasAPIAction())
  const consultaSubdivisiones = () => dispatch(consultaSubdivisionesAction())
  const mostrarUserAPI = () => dispatch(mostrarUserAPIAction())

  useEffect(() => {
    if (subdivisionActual != '' && nombreActual.trim() != '') {
      setBotonControl(false)

    } else {
      setBotonControl(true)

    }
  })

  useEffect(() => {
    mostrarUserAPI()
  }, []);

  function crearPrograma() {
    if (modo == 'nuevo') {
      insertarProgramaModalInsertar({

        id_subdivision: subdivisionActual,
        name: nombreActual,
        description: descripcionActual,
        active: true

      })
    }

    if (modo == 'editar') {
      actualizarProgramaModalInsertar(filaSeleccionadaGrid, {

        id_subdivision: subdivisionActual,
        name: nombreActual,
        description: descripcionActual,
        active: true

      })
    }


    mostrarProgramasAPI()
    cambiarVisibilidadModalInsertar(false, '')

  }

  useEffect(() => {
    consultaSubdivisiones()

    if (modo == 'editar') {

      let programSelected = programasListAPI.filter(registro => registro.id == filaSeleccionadaGrid)[0]
      let subDivisionSelected = subdivisionesListAPI.filter(registro => registro.id == programSelected.id_subdivision)[0]

      if (programSelected != null) {
        setSubdivisionActual(subDivisionSelected.id)
        setNombreActual(programSelected.name)
        setDescripcionActual(programSelected.description)
      }
    }
    if (modo == 'nuevo') {
      setSubdivisionActual('')
      setNombreActual('')
      setDescripcionActual('')
    }

  }, [modo]);


  return (
    <Dialog open={visibilidadModalInsertar} onClose={() => cambiarVisibilidadModalInsertar(false, '')} fullWidth maxWidth='md'>
      <DialogTitle classes={{ root: classes.customDialogTitle }} >
        {modo == 'nuevo' ? "New Program" : "Edit Program"}

      </DialogTitle>
      <DialogContent>

        <Grid container spacing={2} columns={16}>
          <Grid item xs={8}>


            <FormControl variant="outlined" sx={{ m: 1, width: '37ch' }} size="small">
              <InputLabel id="label-select-subdivision">Sub Division</InputLabel>
              <Select
                labelId="label-select-subdivision"
                id="subdivision"
                label="Subdivisión"
                onChange={e => setSubdivisionActual(e.target.value)}
                value={subdivisionActual}
                defaultValue={subdivisionActual}
              >

                {subdivisionesListAPI.map((elemento, index) => (

                  <MenuItem key={index} value={elemento.id}> {elemento.name} </MenuItem>
                ))}

              </Select>
            </FormControl>


          </Grid>
          <Grid item xs={8}>

            <TextField
              label="Name"
              id="nombre"
              value={nombreActual}
              size="small"
              sx={{ m: 1, width: '37ch' }}
              onChange={e => setNombreActual(e.target.value)}
            />

          </Grid>
          <Grid item xs={8}>

            <TextField
              id="Description"
              label="Descripción"
              multiline
              rows={5}
              value={descripcionActual}
              size="small"
              sx={{ m: 1, width: '37ch' }}
              onChange={e => setDescripcionActual(e.target.value)}
            />

          </Grid>

        </Grid>



      </DialogContent>
      <DialogActions>

        <Button onClick={() => cambiarVisibilidadModalInsertar(false, '')}>Close</Button>
        <Button disabled={botonControlSave} onClick={() => crearPrograma()}>Save</Button>

      </DialogActions>
    </Dialog>
  )
}

