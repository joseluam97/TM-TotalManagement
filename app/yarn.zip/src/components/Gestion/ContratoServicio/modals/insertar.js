//**********************IMPORTACIONES****************************

import { useEffect, useState, useRef } from 'react'
import * as React from 'react';
import Button from '@mui/material/Button';
import TextField from '@mui/material/TextField';
import Dialog from '@mui/material/Dialog';
import DialogActions from '@mui/material/DialogActions';
import DialogContent from '@mui/material/DialogContent';
import DialogTitle from '@mui/material/DialogTitle';
import { makeStyles } from "@material-ui/core/styles";
import FormControl from '@mui/material/FormControl';
import Autocomplete from '@mui/material/Autocomplete';
import InfoOutlined from '@mui/icons-material/InfoOutlined';
import IconButton from "@mui/material/IconButton";
import { showMessage } from 'app/store/fuse/messageSlice'
import { DataGrid } from '@mui/x-data-grid';
import Divider from '@mui/material/Divider';

//Grid importaciones
import Grid from '@mui/material/Grid';

//Redux importaciones
import { useDispatch, useSelector } from 'react-redux'
//import { cambiarVisibilidadModalInsertarConjuntoAction, insertarProgramaModalInsertarAction, mostrarProgramasAPIAction } from  '../store/actions'
import {
  mostrarContratoServicioAPIAction,
  crearContratoServicioActionAPIAction,
  updateContratoServicioActionAPIAction,
  cambiarVisibilidadModalInsertarAPIAction,
  obtenerLocationsByMisionAPIAction
} from '../store/actions'

import {
  mostrarSubDivisionsAPIAction
} from '../../SubDivision/store/actions'

import {
  mostrarConjuntosAPIAction
} from '../../Conjunto/store/actions'

import {
  mostrarProgramasAPIAction
} from '../../Programa/store/actions'

import {
  mostrarSubConjuntosAPIAction
} from '../../SubConjunto/store/actions'

import {
  getAllLocationCustomerAPIAction,
  mostrarCustomerAPIAction
} from '../../../Managment/Customers/store/actions'

//**********************END_IMPORTACIONES ***********************/


const useStyles = makeStyles({

  customDialogTitle: {
    backgroundColor: 'rgb(37, 47, 62)',
    color: 'rgb(255, 255, 255)',
    marginBottom: '2em'
  },
  textField: {
    '& p': {
      color: 'red',
    },
  }

});




export function ModalInsertar() {

  const classes = useStyles();
  const dispatch = useDispatch()

  //estados locales del formulario

  const [programaList, setProgramaList] = useState([])
  const [conjuntoList, setConjuntoList] = useState([])
  const [subconjuntoList, setSubconjuntoList] = useState([])
  const [nombreActual, setNombreActual] = useState('')
  const [codigoActual, setCodigoActual] = useState('')
  const [descripcionActual, setDescripcionActual] = useState('')
  const [clienteList, setClienteList] = useState([])
  const [localizacionList, setLocalizacionList] = useState([])
  const [botonControlSave, setBotonControl] = React.useState(true);

  const [selectProgram, setSelectProgram] = React.useState(false);
  const [selectConjunto, setSelectConjunto] = React.useState(false);
  const [selectSubConjunto, setSelectSubConjunto] = React.useState(false);

  const [conjuntosListAPIFilter, setConjuntosListAPIFilter] = useState([])
  const [subConjuntosListAPIFilter, setSubConjuntosListAPIFilter] = useState([])
  const [locationsAPIFilter, setLocationsAPIFilter] = useState([])

  const [ayudaContrato, setAyudaContrato] = useState(false)

  const columnasDataTable = [

    { field: 'id', headerName: 'ID', width: 70 },
    { field: 'name', headerName: 'Name', width: 200 },
    { field: 'manager', headerName: 'Manager', width: 200 },
    { field: 'description', headerName: 'Description', width: 150 }

  ]

  const columnasDataTableLocations = [
    { field: 'id', headerName: 'ID', width: 70 },
    { field: 'id_customer_name', headerName: 'Customer', width: 200 },
    { field: 'name', headerName: 'Name', width: 200 },
    { field: 'code', headerName: 'Code', width: 200 },
    { field: 'direccion', headerName: 'Direction', width: 200 },
    { field: 'telefono', headerName: 'Phone', width: 200 },
    { field: 'latitud', headerName: 'Latitude', width: 150 },
    { field: 'longuitud', headerName: 'Longuitude', width: 150 }
  ]

  //end_locales_formularios


  // Obtener los states de Redux
  const visibilidadModalInsertar = useSelector(state => state.fuse.contratoComponente.visibilidadModalInsertarContrato)
  const subdivisionListAPI = useSelector(state => state.fuse.subDivisionComponente.subdivisionesListAPI)
  const conjuntosListAPI = useSelector(state => state.fuse.conjuntoComponente.listConjuntosAPI)
  const programasListAPI = useSelector(state => state.fuse.programaComponente.programasListAPI)
  const filaSeleccionadaGrid = useSelector(state => state.fuse.contratoComponente.filaSeleccionadaGrid)
  const modo = useSelector(state => state.fuse.contratoComponente.modo)
  const contratoListAPI = useSelector(state => state.fuse.contratoComponente.listContratoAPI)
  const subConjuntosListAPI = useSelector(state => state.fuse.subConjuntoComponente.listSubConjuntosAPI)
  const locationCustomerListAPI = useSelector(state => state.fuse.customerComponent.locationCustomerListAPI)
  const customerListAPI = useSelector(state => state.fuse.customerComponent.customerListAPI)
  const listLocationsMisionesAsociadas = useSelector(state => state.fuse.contratoComponente.listLocationsMisionesAsociadas)

  //Creamos funciones para hacer uso de Actions Redux
  const cambiarVisibilidadModalInsertar = (valor, modo) => dispatch(cambiarVisibilidadModalInsertarAPIAction(valor, modo))
  const crearContratoActionAPI = (conjunto) => dispatch(crearContratoServicioActionAPIAction(conjunto))
  const updateContratoActionAPI = (id, conjunto) => dispatch(updateContratoServicioActionAPIAction(id, conjunto))
  const mostrarContratoAPI = () => dispatch(mostrarContratoServicioAPIAction())
  const mostrarSubDivisionesAPI = () => dispatch(mostrarSubDivisionsAPIAction())
  const mostrarProgramasAPI = () => dispatch(mostrarProgramasAPIAction())
  const mostrarConjuntosAPI = () => dispatch(mostrarConjuntosAPIAction())
  const mostrarSubConjuntosAPI = () => dispatch(mostrarSubConjuntosAPIAction())
  const getAllLocationCustomerAPI = () => dispatch(getAllLocationCustomerAPIAction())
  const mostrarCustomerAPI = () => dispatch(mostrarCustomerAPIAction())
  const obtenerLocationsByMisionAPI = (idContrato) => dispatch(obtenerLocationsByMisionAPIAction(idContrato))

  useEffect(() => {
    mostrarProgramasAPI()
    mostrarConjuntosAPI()
    mostrarSubConjuntosAPI()
    getAllLocationCustomerAPI()
    mostrarCustomerAPI()
  }, [])

  useEffect(() => {
    if (filaSeleccionadaGrid != '') {
      obtenerLocationsByMisionAPI(filaSeleccionadaGrid)
    }
  }, [filaSeleccionadaGrid])

  //FILTROS PARA ELEGIR LA LOCALIZACION
  useEffect(() => {
    //locationCustomerListAPI => TODAS LAS LOCATIONS
    //locationsAPIFilter => LOCATIONS FILTRADAS POR CLIENTES
    let locationsAPIFilterFuncion = []

    if (clienteList.length != 0) {

      for (let value in clienteList) {
        let locationsValidas = locationCustomerListAPI.filter(item => item.id_customer == clienteList[value]['id'])

        if (locationsValidas != undefined) {
          for (let location in locationsValidas) {
            locationsAPIFilterFuncion.push(locationsValidas[location])
          }
        }
      }

      setLocationsAPIFilter(locationsAPIFilterFuncion)
    }
    else {
      setLocationsAPIFilter(locationCustomerListAPI)
    }


  }, [clienteList])

  useEffect(() => {
    if (clienteList.length == 0) {
      setLocationsAPIFilter(locationCustomerListAPI)
    }
  }, [locationCustomerListAPI])

  useEffect(() => {
    if (conjuntosListAPIFilter.length == 0 && subConjuntosListAPIFilter.length == 0) {
      setConjuntosListAPIFilter(conjuntosListAPI)
      setSubConjuntosListAPIFilter(subConjuntosListAPI)
    }

  }, [conjuntosListAPI, subConjuntosListAPI])

  //FILTROS DE ELEGIR LOS PROGRAMAS
  useEffect(() => {

    if (modo != "editar") {

      let vectConjunto = []
      let vectSubConjunto = []

      if (programaList.length != 0) {

        //SET VALUE CONJUNTOS
        for (let itemProgram in programaList) {
          let conjuntosSelected = conjuntosListAPI.filter(registro => registro.id_program == programaList[itemProgram]['id'])

          for (let itemInterno in conjuntosSelected) {
            vectConjunto.push(conjuntosSelected[itemInterno])
          }
        }

        //COMPROBAR VALORES ACTUALES SON CORRECTOS
        if (vectConjunto.length != 0) {
          for (let itemProgram in vectConjunto) {
            let resultado = programaList.filter(item => item.id == vectConjunto[itemProgram].id)
            if (resultado == undefined) {
              //RESET VALUES
              setConjuntoList([])
            }
          }
        }
        else {
          //RESET VALUES
          setConjuntoList([])
        }

        setConjuntosListAPIFilter(vectConjunto)
        setSelectSubConjunto(true)

      }
      else {
        setConjuntosListAPIFilter(conjuntosListAPI)
        setSubConjuntosListAPIFilter(subConjuntosListAPI)

        //RESET VALUES
        setConjuntoList([])

        //DISABLED TODOS LOS CAMPOS
        setSelectProgram(false)
        setSelectConjunto(false)
        setSelectSubConjunto(false)
      }
    }

  }, [programaList, modo])

  //FILTROS DE ELEGIR LOS CONJUNTOS
  useEffect(() => {

    if (modo != "editar") {
      let vectSubConjunto = []

      if (conjuntoList.length != 0) {

        //SET VALUE CONJUNTOS
        for (let itemProgram in conjuntoList) {
          let conjuntosSelected = subConjuntosListAPI.filter(registro => registro.id_set == conjuntoList[itemProgram]['id'])

          for (let itemInterno in conjuntosSelected) {
            vectSubConjunto.push(conjuntosSelected[itemInterno])
          }
        }

        setSubConjuntosListAPIFilter(vectSubConjunto)

        //COMPROBAR VALORES ACTUALES SON CORRECTOS
        if (vectSubConjunto.length != 0) {
          for (let itemProgram in vectSubConjunto) {
            let resultado = conjuntoList.filter(item => item.id == vectSubConjunto[itemProgram].id)
            if (resultado == undefined) {
              //RESET VALUES
              setSubconjuntoList([])
            }
          }
        }
        else {
          //RESET VALUES
          setSubconjuntoList([])
        }

        if (programaList.length == 0) {
          setSelectProgram(true)
        }

        setSelectSubConjunto(false)

      }
      else {
        setSubConjuntosListAPIFilter(subConjuntosListAPI)

        //RESET VALUES
        setSubconjuntoList([])

        //DISABLED TODOS LOS CAMPOS
        setSelectProgram(false)
        setSelectConjunto(false)
      }
    }

  }, [conjuntoList, modo])


  //FILTROS DE ELEGIR LOS SUB CONJUNTOS
  useEffect(() => {
    if (modo != "editar") {
      if (subconjuntoList.length != 0) {
        if (programaList.length == 0 && conjuntoList.length == 0) {
          setSelectProgram(true)
          setSelectConjunto(true)
        }
      }
      else {
        setSelectProgram(false)
        setSelectConjunto(false)
      }
    }

  }, [subconjuntoList, modo])

  useEffect(() => {
    if (subconjuntoList != undefined &&
      nombreActual.trim() != '' &&
      codigoActual.trim() != '') {
      //descripcionActual.trim() != '') {
      setBotonControl(false)

    } else {
      setBotonControl(true)

    }
  })

  function comprobarLocalizacionesCorrectas() {

    let vectIDSite = []
    for (let item in localizacionList) {
      vectIDSite.push(localizacionList[item].id)
    }

    if (listLocationsMisionesAsociadas.length != 0 && modo == "editar") {

      let posibleGuardar = true
      for (let localizacionMision in listLocationsMisionesAsociadas) {
        let data = vectIDSite.includes(listLocationsMisionesAsociadas[localizacionMision])
        if (data == false) {
          posibleGuardar = false
        }
      }

      if (posibleGuardar == true) {
        crearConjunto()
      }
      else {
        dispatch(
          showMessage({
            message: "You have modified the contract/service locations and removed locations that are used in the quests associated with this contract.",
            variant: "error"
          })
        )
      }

    }
    else {
      crearConjunto()
    }
  }

  function crearConjunto() {

    if (programaList.length != 0 || conjuntoList.length != 0 || subconjuntoList.length != 0) {
      let vectProgram = []
      let vectConjunto = []
      let vectSubConjunto = []
      let vectLocalizacion = []

      for (let itemProgram in programaList) {
        vectProgram.push(programaList[itemProgram]['id'])
      }

      for (let itemConjunto in conjuntoList) {
        vectConjunto.push(conjuntoList[itemConjunto]['id'])
      }

      for (let itemSubConjunto in subconjuntoList) {
        vectSubConjunto.push(subconjuntoList[itemSubConjunto]['id'])
      }

      for (let itemLocalizacion in localizacionList) {
        vectLocalizacion.push(localizacionList[itemLocalizacion]['id'])
      }

      if (modo == 'nuevo') {
        crearContratoActionAPI({
          programs: vectProgram,
          sets: vectConjunto,
          subSets: vectSubConjunto,
          name: nombreActual,
          code: codigoActual,
          description: descripcionActual,
          locations: vectLocalizacion
        })
      }

      if (modo == 'editar') {
        updateContratoActionAPI(filaSeleccionadaGrid, {
          programs: vectProgram,
          sets: vectConjunto,
          subSets: vectSubConjunto,
          name: nombreActual,
          code: codigoActual,
          description: descripcionActual,
          locations: vectLocalizacion
        })
      }


      cambiarVisibilidadModalInsertar(false, '');
      mostrarContratoAPI();
    }
    else {
      dispatch(
        showMessage({
          message: "It is necessary to fill in some of the fields: Program, Asembly or Sub Asembly",
          variant: "error"
        })
      )
    }



  }

  useEffect(() => {

    if (modo == 'nuevo') {
      setProgramaList([])
      setConjuntoList([])
      setSubconjuntoList([])
      setNombreActual('')
      setCodigoActual('')
      setDescripcionActual('')
      setLocalizacionList([])
    }

    if (modo == 'editar' || modo == 'consultar') {
      let contratoSelected = contratoListAPI.filter(registro => registro.id == filaSeleccionadaGrid)[0]

      console.log("-datitos-")
      console.log(contratoSelected)
      console.log(filaSeleccionadaGrid)

      if (contratoSelected != null) {

        let vectProgram = []
        let vectConjunto = []
        let vectSubConjunto = []
        let vectLocations = []

        for (let itemProgram in contratoSelected['programs']) {
          let programaSelect = programasListAPI.filter(registro => registro.id == contratoSelected['programs'][itemProgram])[0]
          vectProgram.push(programaSelect)
        }
        setProgramaList(vectProgram)


        for (let itemConjunto in contratoSelected['sets']) {
          let conjuntosSelected = conjuntosListAPI.filter(registro => registro.id == contratoSelected['sets'][itemConjunto])[0]
          vectConjunto.push(conjuntosSelected)
        }
        setConjuntoList(vectConjunto)


        for (let itemSubConjunto in contratoSelected['subSets']) {
          let subConjuntosSelected = subConjuntosListAPI.filter(registro => registro.id == contratoSelected['subSets'][itemSubConjunto])[0]
          vectSubConjunto.push(subConjuntosSelected)
        }
        setSubconjuntoList(vectSubConjunto)

        for (let itemLocation in contratoSelected['locations']) {
          let locationsSelected = locationCustomerListAPI.filter(registro => registro.id == contratoSelected['locations'][itemLocation])[0]
          vectLocations.push(locationsSelected)
        }
        setLocalizacionList(vectLocations)

        setNombreActual(contratoSelected.name)
        setCodigoActual(contratoSelected.code)
        setDescripcionActual(contratoSelected.description)
      }
    }

  }, [modo])


  return (
    <Dialog open={visibilidadModalInsertar} onClose={() => cambiarVisibilidadModalInsertar(false, '')} fullWidth maxWidth='lg'>
      <DialogTitle classes={{ root: classes.customDialogTitle }} >
        {modo == 'nuevo' ? "New Contract" : "Edit Contract"}

      </DialogTitle>
      <DialogContent>
        <IconButton onClick={() => setAyudaContrato(true)} style={{ display: modo == 'consultar' ? 'none' : 'block' }}><InfoOutlined /></IconButton>

        {/*DIALOGO DE INFORMACION DE CREACION CONTRATO */}
        <Dialog open={ayudaContrato} onClose={() => setAyudaContrato(false)} fullWidth maxWidth="md" >
          <DialogTitle>Info</DialogTitle>
          <DialogContent>
            To create a new contract or edit it, one of the following 3 fields must be completed: Program, Asembly, Sub Asembly. These fields are filled progressively, that is, if a program is selected, they will be given a choice between the sets of the selected program, in the same way it will happen if we select a set, the subsets of that set will be given to choose.
            {/*Para crear un nuevo contrato o editarlo es necesario que alguno de los 3 campos siguientes esten completados: Program, Asembly, Sub Asembly. Estos campos se rellenan progresivamente, es decir si se selecciona un programa se daran a elegir entre los conjuntos del programa seleccionado, de igual manera ocurrira si seleccionamos un conjunto, se daran a elegir los subconjuntos de ese conjunto.
            */}
          </DialogContent>
        </Dialog>
        {/* FIN DIALOGO DE INFORMACION DE CREACION CONTRATO*/}

        <Grid container spacing={2} columns={24}>
          <Grid item xs={8} style={{ display: modo == 'consultar' ? 'none' : 'block' }}>
            <FormControl variant="standard" sx={{ m: 1 }} fullWidth>
              <Autocomplete
                multiple
                limitTags={2}
                id="tags-outlined"
                value={programaList}
                options={programasListAPI}
                getOptionLabel={(option) => option.id_subdivision_name + " - " + option.name}
                onChange={(event, value) => setProgramaList(value)}
                disabled={modo == "consultar" || selectProgram == true ? true : false}
                fullWidth
                filterSelectedOptions
                renderInput={(params) => (
                  <TextField
                    {...params}
                    label="Program"
                    placeholder="Program"
                    size="xl"
                  //onChange={e => { setContract(e.target.value); }}
                  />
                )}
              />
            </FormControl>

          </Grid>
          <Grid item xs={8} style={{ display: modo == 'consultar' ? 'none' : 'block' }}>
            <FormControl variant="standard" sx={{ m: 1 }} fullWidth>
              <Autocomplete
                multiple
                limitTags={2}
                id="tags-outlined"
                value={conjuntoList}
                options={conjuntosListAPIFilter}
                getOptionLabel={(option) => option.id_program_name + " - " + option.name}
                onChange={(event, value) => setConjuntoList(value)}
                disabled={modo == "consultar" || selectConjunto == true ? true : false}
                fullWidth
                filterSelectedOptions
                renderInput={(params) => (
                  <TextField
                    {...params}
                    label="Asembly"
                    placeholder="Asembly"
                    size="xl"
                  //onChange={e => { setContract(e.target.value); }}
                  />
                )}
              />
            </FormControl>

          </Grid>
          <Grid item xs={8} style={{ display: modo == 'consultar' ? 'none' : 'block' }}>
            <FormControl variant="standard" sx={{ m: 1 }} fullWidth>
              <Autocomplete
                multiple
                limitTags={2}
                id="tags-outlined"
                value={subconjuntoList}
                options={subConjuntosListAPIFilter}
                getOptionLabel={(option) => option.id_set_name + " - " + option.name}
                onChange={(event, value) => setSubconjuntoList(value)}
                disabled={modo == "consultar" || selectSubConjunto == true ? true : false}
                fullWidth
                filterSelectedOptions
                renderInput={(params) => (
                  <TextField
                    {...params}
                    label="Sub Asembly"
                    placeholder="Sub Asembly"
                    size="xl"
                  //onChange={e => { setContract(e.target.value); }}
                  />
                )}
              />
            </FormControl>

          </Grid>

          <div style={{ width: '100%', textAlign: 'center' }}>
            <Divider style={{ width: '100%' }} />
          </div>

          <Grid item xs={8}>

            <TextField
              label="Name"
              id="nombre"
              value={nombreActual}
              sx={{ m: 1 }}
              fullWidth
              disabled={modo == "consultar" ? true : false}
              onChange={e => setNombreActual(e.target.value)}
            />

          </Grid>

          <Grid item xs={8}>

            <TextField
              label="Code"
              id="codigo"
              value={codigoActual}
              sx={{ m: 1 }}
              fullWidth
              disabled={modo == "consultar" ? true : false}
              onChange={e => setCodigoActual(e.target.value)}
            />

          </Grid>

          <Grid item xs={8}>

            <TextField
              id="descripcion"
              label="Description"
              multiline
              rows={4}
              value={descripcionActual}
              sx={{ m: 1 }}
              fullWidth
              disabled={modo == "consultar" ? true : false}
              onChange={e => setDescripcionActual(e.target.value)}
            />

          </Grid>

          <div style={{ width: '100%', textAlign: 'center' }}>
            <Divider style={{ width: '100%' }} />
          </div>

          <Grid item xs={12} style={{ display: modo == 'consultar' ? 'none' : 'block' }}>
            <FormControl variant="standard" sx={{ m: 1 }} fullWidth>
              <Autocomplete
                multiple
                id="tags-outlined"
                options={customerListAPI}
                getOptionLabel={(option) => option.name}
                onChange={(event, value) => setClienteList(value)}
                disabled={modo == "consultar" ? true : false}
                fullWidth
                filterSelectedOptions
                renderInput={(params) => (
                  <TextField
                    {...params}
                    label="Customer"
                    placeholder="Customer"
                    size="xl"
                    className={classes.textField}
                    helperText="This record will not be stored, it is used to filter the locations."
                  //onChange={e => { setContract(e.target.value); }}
                  />
                )}
              />
            </FormControl>

          </Grid>

          <Grid item xs={12} style={{ display: modo == 'consultar' ? 'none' : 'block' }}>
            <FormControl variant="standard" sx={{ m: 1 }} fullWidth>
              <Autocomplete
                multiple
                limitTags={2}
                id="tags-outlined"
                value={localizacionList}
                options={locationsAPIFilter}
                getOptionLabel={(option) => option.name}
                onChange={(event, value) => setLocalizacionList(value)}
                disabled={modo == "consultar" ? true : false}
                fullWidth
                filterSelectedOptions
                renderInput={(params) => (
                  <TextField
                    {...params}
                    label="Locations"
                    placeholder="Locations"
                    size="xl"
                  //onChange={e => { setContract(e.target.value); }}
                  />
                )}
              />
            </FormControl>

          </Grid>

          <div style={{ height: programaList.length > 3 ? 400 : 100 * (programaList.length) + 50, marginTop: '30px', width: '100%', display: modo == 'consultar' && programaList.length != 0 ? 'block' : 'none' }}>
            <h3>Programs</h3>
            <DataGrid
              autoHeight
              rows={programaList}
              columns={columnasDataTable}
              pageSize={5}
              rowsPerPageOptions={[5]}
              disableMultipleSelection={true}

              initialState={{
                sorting: {
                  sortModel: [
                    {
                      field: 'id', sort: 'asc'
                    }

                  ],
                },
              }}
            />
          </div>

          <div style={{ height: conjuntoList.length > 3 ? 400 : 100 * (conjuntoList.length) + 50, marginTop: '30px', width: '100%', display: modo == 'consultar' && conjuntoList.length != 0 ? 'block' : 'none' }}>
            <h3>Asembly</h3>
            <DataGrid
              autoHeight
              rows={conjuntoList}
              columns={columnasDataTable}
              pageSize={5}
              rowsPerPageOptions={[5]}
              disableMultipleSelection={true}

              initialState={{
                sorting: {
                  sortModel: [
                    {
                      field: 'id', sort: 'asc'
                    }

                  ],
                },
              }}
            />
          </div>

          <div style={{ height: subconjuntoList.length > 3 ? 400 : 100 * (subconjuntoList.length) + 50, marginTop: '30px', width: '100%', display: modo == 'consultar' && subconjuntoList.length != 0 ? 'block' : 'none' }}>
            <h3>Sub Asembly</h3>
            <DataGrid
              autoHeight
              rows={subconjuntoList}
              columns={columnasDataTable}
              pageSize={5}
              rowsPerPageOptions={[5]}
              disableMultipleSelection={true}

              initialState={{
                sorting: {
                  sortModel: [
                    {
                      field: 'id', sort: 'asc'
                    }

                  ],
                },
              }}
            />
          </div>

          <div style={{ height: localizacionList.length > 3 ? 400 : 100 * (localizacionList.length + 1), marginTop: '30px', width: '100%', display: modo == 'consultar' && localizacionList.length != 0 ? 'block' : 'none' }}>
            <h3>Locations</h3>
            <DataGrid
              autoHeight
              rows={localizacionList}
              columns={columnasDataTableLocations}
              pageSize={5}
              rowsPerPageOptions={[5]}
              disableMultipleSelection={true}

              initialState={{
                sorting: {
                  sortModel: [
                    {
                      field: 'id', sort: 'asc'
                    }

                  ],
                },
              }}
            />
          </div>

        </Grid>



      </DialogContent>
      <DialogActions>


        <Button onClick={() => cambiarVisibilidadModalInsertar(false, '')}>Close</Button>
        <Button disabled={botonControlSave} onClick={() => comprobarLocalizacionesCorrectas()}>Save</Button>

      </DialogActions>
    </Dialog>
  )
}

