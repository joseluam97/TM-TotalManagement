import {

    GET_CONTRATO_SERVICIO,
    GET_CONTRATO_SERVICIO_EXITO,
    GET_CONTRATO_SERVICIO_ERROR,

    POST_CONTRATO_SERVICIO,
    POST_CONTRATO_SERVICIO_EXITO,
    POST_CONTRATO_SERVICIO_ERROR,

    PUT_CONTRATO_SERVICIO,
    PUT_CONTRATO_SERVICIO_EXITO,
    PUT_CONTRATO_SERVICIO_ERROR,

    VER_MODAL_ASSIGNED_PEOPLE,
    VER_MODAL_ASSIGNED_PEOPLE_EXITO,
    VER_MODAL_ASSIGNED_PEOPLE_ERROR,

    GET_PEOPLE_CONTRATO,
    GET_PEOPLE_CONTRATO_EXITO,
    GET_PEOPLE_CONTRATO_ERROR,

    CAMBIAR_VALOR_SELECCION_GRID_CONTRATO_SERVICIO,
    CAMBIAR_VALOR_SELECCION_GRID_CONTRATO_SERVICIO_EXITO,
    CAMBIAR_VALOR_SELECCION_GRID_CONTRATO_SERVICIO_ERROR,

    CAMBIAR_MODAL_VISIBILIDAD_INSERTAR_CONTRATO_SERVICIO,
    CAMBIAR_MODAL_VISIBILIDAD_INSERTAR_CONTRATO_SERVICIO_EXITO,
    CAMBIAR_MODAL_VISIBILIDAD_INSERTAR_CONTRATO_SERVICIO_ERROR,

    POST_PEOPLE_CONTRATO,
    POST_PEOPLE_CONTRATO_EXITO,
    POST_PEOPLE_CONTRATO_ERROR,

    GET_APP_CONTRACT,
    GET_APP_CONTRACT_EXITO,
    GET_APP_CONTRACT_ERROR,

    GET_USER_APP_CONTRACT,
    GET_USER_APP_CONTRACT_EXITO,
    GET_USER_APP_CONTRACT_ERROR,

    GET_LOCATIONS_MISION_CONTRACT,
    GET_LOCATIONS_MISION_CONTRACT_EXITO,
    GET_LOCATIONS_MISION_CONTRACT_ERROR


} from './types';


// cada reducer tiene su propio state
const initialState = {
    listContratoAPI: [],
    listPeopleContratoAPI: [],
    listLocationsMisionesAsociadas: [],
    filaSeleccionadaGrid: '',
    visibilidadModalInsertarContrato: false,
    visibilidadModalAssignedPeople: '',
    error: null,
    loading: false,
    modo: '',
    listUserApp: [],
    listContractApp: []
}

export default function(state = initialState, action) {

    switch(action.type) {

        //**********GET LOCATIONS DE MISIONES DE SERVICIOS**********************************/

        case GET_LOCATIONS_MISION_CONTRACT:
            return {
                ...state,
                loading: action.payload
            }
        
        case GET_LOCATIONS_MISION_CONTRACT_EXITO:
            return {
                ...state,
                loading: false,
                error: null,
                listLocationsMisionesAsociadas: action.payload
            }
        
        case GET_LOCATIONS_MISION_CONTRACT_ERROR:
            return {
                ...state,
                loading: false,
                error: action.payload

            }

        //**********GET PERSONAS EN CONTRATO**********************************/

        case GET_APP_CONTRACT:
            return {
                ...state,
                loading: action.payload
            }
        
        case GET_APP_CONTRACT_EXITO:
            return {
                ...state,
                loading: false,
                error: null,
                listContractApp: action.payload
            }
        
        case GET_APP_CONTRACT_ERROR:
            return {
                ...state,
                loading: false,
                error: action.payload

            }

        //**********GET PERSONAS EN CONTRATO**********************************/

        case GET_USER_APP_CONTRACT:
            return {
                ...state,
                loading: action.payload
            }
        
        case GET_USER_APP_CONTRACT_EXITO:
            return {
                ...state,
                loading: false,
                error: null,
                listUserApp: action.payload
            }
        
        case GET_USER_APP_CONTRACT_ERROR:
            return {
                ...state,
                loading: false,
                error: action.payload

            }


        //**********VISIBILIDAD MODAL INSERTAR**********************************/

    case CAMBIAR_MODAL_VISIBILIDAD_INSERTAR_CONTRATO_SERVICIO:
        return {
            ...state,
            loading: action.payload
        }
        
        case CAMBIAR_MODAL_VISIBILIDAD_INSERTAR_CONTRATO_SERVICIO_EXITO:
            return {
                ...state,
                loading: false,
                visibilidadModalInsertarContrato: action.payload,
                modo: action.modo

            }
        
        case CAMBIAR_MODAL_VISIBILIDAD_INSERTAR_CONTRATO_SERVICIO_ERROR:
            return {
                ...state,
                loading: false,
                error: action.payload

            }
        

        //**********FILA SELECIONADA GRID **********************************/

        case CAMBIAR_VALOR_SELECCION_GRID_CONTRATO_SERVICIO:
            return {
                ...state,
                loading: action.payload
            }
        
        case CAMBIAR_VALOR_SELECCION_GRID_CONTRATO_SERVICIO_EXITO:
            return {
                ...state,
                loading: false,
                filaSeleccionadaGrid: action.payload

            }
        
        case CAMBIAR_VALOR_SELECCION_GRID_CONTRATO_SERVICIO_ERROR:
            return {
                ...state,
                loading: false,
                error: action.payload

            }

        //**********GET PERSONAS EN CONTRATO**********************************/

        case GET_PEOPLE_CONTRATO:
            return {
                ...state,
                loading: action.payload
            }
        
        case GET_PEOPLE_CONTRATO_EXITO:
            return {
                ...state,
                loading: false,
                error: null,
                listPeopleContratoAPI: action.payload
            }
        
        case GET_PEOPLE_CONTRATO_ERROR:
            return {
                ...state,
                loading: false,
                error: action.payload

            }

     //**********GET CONJUNTOS**********************************/

        case GET_CONTRATO_SERVICIO:
            return {
                ...state,
                loading: action.payload
            }
        
        case GET_CONTRATO_SERVICIO_EXITO:
            return {
                ...state,
                loading: false,
                error: null,
                listContratoAPI: action.payload
            }
        
        case GET_CONTRATO_SERVICIO_ERROR:
            return {
                ...state,
                loading: false,
                error: action.payload

            }

//**********CAMBIAR VISIBILIDAD MODAL VER PERSONAS ASIGNADAS A CONTRATOS**********************************/

            case VER_MODAL_ASSIGNED_PEOPLE:
            return {
                ...state,
                loading: action.payload
            }
        
        case VER_MODAL_ASSIGNED_PEOPLE_EXITO:
            return {
                ...state,
                loading: false,
                visibilidadModalAssignedPeople: action.payload

            }
        
        case VER_MODAL_ASSIGNED_PEOPLE_ERROR:
            return {
                ...state,
                loading: false,
                error: action.payload

            }

        //**********POST persona a contrato**********************************/

        case POST_PEOPLE_CONTRATO:
            return {
                ...state,
                loading: action.payload
            }
        
        case POST_PEOPLE_CONTRATO_EXITO:
            return {
                ...state,
                loading: false,
                error: null

            }
        
        case POST_PEOPLE_CONTRATO_ERROR:
            return {
                ...state,
                loading: false,
                error: action.payload

            }

     //**********POST CONJUNTO**********************************/

         case POST_CONTRATO_SERVICIO:
            return {
                ...state,
                loading: action.payload
            }
        
        case POST_CONTRATO_SERVICIO_EXITO:
            return {
                ...state,
                loading: false,
                error: null

            }
        
        case POST_CONTRATO_SERVICIO_ERROR:
            return {
                ...state,
                loading: false,
                error: action.payload

            }
            

     //********** PUT CONJUNTO **********************************/ 


     case PUT_CONTRATO_SERVICIO:
        return {
            ...state,
            loading: action.payload
        }
    
    case PUT_CONTRATO_SERVICIO_EXITO:
        return {
            ...state,
            loading: false,
            error: null
        }
    
    case PUT_CONTRATO_SERVICIO_ERROR:
        return {
            ...state,
            loading: false,
            error: action.payload

        }

        default: 
            return state

    }

}