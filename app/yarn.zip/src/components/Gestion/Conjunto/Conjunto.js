import { React, useEffect, useState } from 'react'

//DataGrid importaciones
import { DataGrid } from '@mui/x-data-grid';
import DeleteIcon from "@mui/icons-material/Delete";
import EditIcon from '@mui/icons-material/Edit';
import IconButton from "@mui/material/IconButton";
import store from "app/store/index"
import { getCookie } from 'app/js/generalFunctions'
import { useDispatch, useSelector } from 'react-redux'
import Dialog from '@mui/material/Dialog';
import DialogActions from '@mui/material/DialogActions';
import DialogContent from '@mui/material/DialogContent';
import DialogTitle from '@mui/material/DialogTitle';
import { makeStyles } from "@material-ui/core/styles";
import Tooltip from '@mui/material/Tooltip';
import AddCircleIcon from '@mui/icons-material/AddCircle';
import FormControl from '@mui/material/FormControl';
import Select, { SelectChangeEvent } from '@mui/material/Select';
import MenuItem from '@mui/material/MenuItem';
import {
  gridPageCountSelector,
  gridPageSelector,
  useGridApiContext,
  useGridSelector,
  GridToolbarExport,
  GridToolbarDensitySelector,
  GridToolbarFilterButton,
  GridToolbarColumnsButton,
  GridToolbarContainer
} from '@mui/x-data-grid';
import Pagination from '@mui/material/Pagination';
import Divider from '@mui/material/Divider';

import Button from '@mui/material/Button';

import {
  mostrarConjuntosAPIAction,
  crearConjuntoActionAPIAction,
  updateConjuntoActionAPIAction,
  cambiarVisibilidadModalInsertarConjuntoAction,
  cambiarValorSeleccionAction
} from './store/actions'

import {
  getPermisosSesionActualAPIAction
} from '../../Managment/Users/store/actions'

import { insertarLogAPIAction } from '../../Managment/Log/store/actions'

//Modales importaciones
import { ModalInsertar } from './modals/insertar.js'
import TableModules from '../../tables/TableModules'

const useStyles = makeStyles({

  customButtomConjunto: {

    margin: '1em'
  }

});

export default function Conjunto() {

  const [numPagination, setNumPagination] = useState(10)
  const [addConjunto, setAddConjunto] = useState(true)
  const [changeConjunto, setChangeConjunto] = useState(true)
  const [deleteConjunto, setDeleteConjunto] = useState(true)
  const [visibilidadDialogoConfirmacion, setVisibilidadDialogoConfirmacion] = useState(false)

  const loading = useSelector(state => state.fuse.conjuntoComponente.loading)
  const visibilidad = useSelector(state => state.fuse.divisionViewComponente.valorTabDivision)
  const conjuntosListAPI = useSelector(state => state.fuse.conjuntoComponente.listConjuntosAPI)
  const filaSeleccionadaGrid = useSelector(state => state.fuse.conjuntoComponente.filaSeleccionadaGrid)
  const personLoginPermisos = useSelector(state => state.fuse.userComponente.personPermisos)
  const personLogin = useSelector(state => state.fuse.userComponente.person)

  const mostrarConjuntosAPI = () => dispatch(mostrarConjuntosAPIAction())
  const cambiarVisibilidadModalInsertar = (valor, modo) => dispatch(cambiarVisibilidadModalInsertarConjuntoAction(valor, modo))
  const cambiarValorSeleccion = (valor) => dispatch(cambiarValorSeleccionAction(valor))
  const updateConjuntoActionAPI = (id, conjunto) => dispatch(updateConjuntoActionAPIAction(id, conjunto))

  const classes = useStyles();
  const dispatch = useDispatch()

  const columnasDataTable = [
    { Header: "Name", accessor: "name", sortable: true, type: 'string' },
    { Header: "Description", accessor: "description", sortable: true, type: 'string' },
    { Header: "Program", accessor: "id_program_name", sortable: true, type: 'list' },
  ]

  function deletePrograma() {
    let conjuntoSelected = conjuntosListAPI.filter(registro => registro.id == filaSeleccionadaGrid)[0]

    updateConjuntoActionAPI(filaSeleccionadaGrid, {
      id_program: conjuntoSelected.id_program,
      name: conjuntoSelected.name,
      description: conjuntoSelected.description,
      active: false
    })

  }

  useEffect(() => {
    mostrarConjuntosAPI()

    //GET USER
    store.dispatch(getPermisosSesionActualAPIAction({

      token: getCookie('token')

    }))
    //FIN GET USER
    store.dispatch(insertarLogAPIAction({
      persona: personLogin['id'],
      fecha_accion: new Date().toISOString().split("T")[0],
      hora_accion: new Date().toLocaleTimeString(),
      modulo: "Asembly",
      descripcion: "Entrance to Asembly module"
    }))

  }, [])

  useEffect(() => {
    if (visibilidad == 'conjunto') {
      store.dispatch(insertarLogAPIAction({
        persona: personLogin['id'],
        fecha_accion: new Date().toISOString().split("T")[0],
        hora_accion: new Date().toLocaleTimeString(),
        modulo: "Assembly",
        descripcion: "Entrance to Assembly module"
      }))
    }

  }, [visibilidad])

  useEffect(() => {

    if (personLoginPermisos.find((item) => item['name'] == "Can add set") != undefined) {
      setAddConjunto(false)
    }

    if (personLoginPermisos.find((item) => item['name'] == "Can change set") != undefined) {
      setChangeConjunto(false)
    }

    if (personLoginPermisos.find((item) => item['name'] == "Can delete set") != undefined) {
      setDeleteConjunto(false)
    }

  }, [personLoginPermisos])

  function CustomPagination() {
    const apiRef = useGridApiContext();
    const page = useGridSelector(apiRef, gridPageSelector);
    const pageCount = useGridSelector(apiRef, gridPageCountSelector);

    function handleChange() {

    }

    return (
      <>
        <div>
          <div style={{ display: "inline" }}>
            <FormControl variant="standard" >
              <Select
                labelId="demo-simple-select-label"
                id="demo-simple-select"
                value={numPagination}
                label="Size"
                style={{ float: "right", position: "relative" }}
                onChange={e => { setNumPagination(e.target.value); }}
              >
                <MenuItem value={5}>5</MenuItem>
                <MenuItem value={10}>10</MenuItem>
                <MenuItem value={30}>30</MenuItem>
                <MenuItem value={50}>50</MenuItem>
                <MenuItem value={100}>100</MenuItem>
              </Select>
            </FormControl>
          </div>

          <div style={{ display: "inline", float: "right", position: "relative" }}>
            <Pagination
              color="primary"
              count={pageCount}
              page={page + 1}
              onChange={(event, value) => apiRef.current.setPage(value - 1)}
            />
          </div>
        </div>

      </>
    );
  }

  function botonesSuperiores() {

    return (
      <>
        <Tooltip title="New" placement="top">
          <IconButton variant="outlined" style={addConjunto == false ? { display: "inline" } : { display: "none" }}>
            <AddCircleIcon variant="outlined" onClick={
              () => {
                cambiarVisibilidadModalInsertar(true, 'nuevo')
              }
            }
            >
            </AddCircleIcon>
          </IconButton>
        </Tooltip>

        <Tooltip title="Edit" placement="top">
          <IconButton disabled={filaSeleccionadaGrid != '' ? false : true} style={changeConjunto == false ? { display: "inline" } : { display: "none" }}
            onClick={() => {
              cambiarVisibilidadModalInsertar(true, 'editar');
            }}
          >
            <EditIcon />
          </IconButton>
        </Tooltip>

        <Tooltip title="Delete" placement="top">
          <IconButton disabled={filaSeleccionadaGrid != '' ? false : true} style={deleteConjunto == false ? { display: "inline" } : { display: "none" }}
            onClick={() => {
              setVisibilidadDialogoConfirmacion(true)
            }}
          >
            <DeleteIcon />
          </IconButton>
        </Tooltip>

        <Divider />
      </>
    );
  }

  return (
    <>
      <div style={visibilidad == 'conjunto' ? { display: "block" } : { display: "none" }} >

        <div style={{ width: '100%' }}>
          {botonesSuperiores()}
          <TableModules rowsProp={conjuntosListAPI} columnsProp={columnasDataTable} loading={loading} funcionSetValue={cambiarValorSeleccion} />
        </div>

        <ModalInsertar />
      </div>

      <Dialog open={visibilidadDialogoConfirmacion} fullWidth maxWidth='xs'>

        <DialogTitle classes={{ root: classes.customDialogTitle }} >
          Confirmation
        </DialogTitle>
        <DialogContent>
          Are you sure you want to remove the asembly?
        </DialogContent>
        <DialogActions>

          <Button variant="outlined" onClick={() => setVisibilidadDialogoConfirmacion(false)}>Decline</Button>
          <Button variant="outlined" onClick={() => { deletePrograma(), setVisibilidadDialogoConfirmacion(false) }}> Confirm</Button>

        </DialogActions>

      </Dialog>

    </>
  )
}


