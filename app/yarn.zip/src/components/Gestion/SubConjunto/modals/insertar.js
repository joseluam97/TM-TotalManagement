//**********************IMPORTACIONES****************************

import { useEffect, useState, useRef } from 'react'
import * as React from 'react';
import Button from '@mui/material/Button';
import TextField from '@mui/material/TextField';
import Dialog from '@mui/material/Dialog';
import DialogActions from '@mui/material/DialogActions';
import DialogContent from '@mui/material/DialogContent';
import DialogTitle from '@mui/material/DialogTitle';
import { makeStyles } from "@material-ui/core/styles";
import InputLabel from '@mui/material/InputLabel';
import MenuItem from '@mui/material/MenuItem';
import FormControl from '@mui/material/FormControl';
import Select, { SelectChangeEvent } from '@mui/material/Select';


//Grid importaciones
import Grid from '@mui/material/Grid';

//Redux importaciones
import { useDispatch, useSelector } from 'react-redux'
//import { cambiarVisibilidadModalInsertarConjuntoAction, insertarProgramaModalInsertarAction, mostrarProgramasAPIAction } from  '../store/actions'
import {
  mostrarSubConjuntosAPIAction,
  crearSubConjuntoActionAPIAction,
  updateSubConjuntoActionAPIAction,
  cambiarVisibilidadModalInsertarSubConjuntoAction
} from '../store/actions'


//**********************END_IMPORTACIONES ***********************/


const useStyles = makeStyles({

  customDialogTitle: {
    backgroundColor: 'rgb(37, 47, 62)',
    color: 'rgb(255, 255, 255)',
    marginBottom: '2em'
  }

});




export function ModalInsertar () {

  const classes = useStyles();
  const dispatch = useDispatch()

  //estados locales del formulario

  const [conjuntoList, setConjuntoActual] = useState('')
  const [nombreActual, setNombreActual] = useState('')
  const [descripcionActual, setDescripcionActual] = useState('')
  const [botonControlSave, setBotonControl] = React.useState(true);

  //end_locales_formularios


  // Obtener los states de Redux
  const visibilidadModalInsertar = useSelector(state => state.fuse.subConjuntoComponente.visibilidadModalInsertarSubConjunto)
  const conjuntosListAPI = useSelector(state => state.fuse.conjuntoComponente.listConjuntosAPI)
  const filaSeleccionadaGrid = useSelector(state => state.fuse.subConjuntoComponente.filaSeleccionadaGrid)
  const modo = useSelector(state => state.fuse.subConjuntoComponente.modo)
  const subConjuntosListAPI = useSelector(state => state.fuse.subConjuntoComponente.listSubConjuntosAPI)

  //Creamos funciones para hacer uso de Actions Redux
  const cambiarVisibilidadModalInsertar = (valor, modo) => dispatch(cambiarVisibilidadModalInsertarSubConjuntoAction(valor, modo))
  const crearSubConjuntoActionAPI = (conjunto) => dispatch(crearSubConjuntoActionAPIAction(conjunto))
  const updateSubConjuntoActionAPI = (id, conjunto) => dispatch(updateSubConjuntoActionAPIAction(id, conjunto))
  const mostrarSubConjuntosAPI = () => dispatch(mostrarSubConjuntosAPIAction())

  useEffect(() => {
    if (conjuntoList != '' &&
      nombreActual.trim() != '') {
      //descripcionActual.trim() != '') {
      setBotonControl(false)

    } else {
      setBotonControl(true)

    }
  })

  function crearConjunto() {

    if (modo == 'nuevo') {
      crearSubConjuntoActionAPI({

        id_set: conjuntoList,
        name: nombreActual,
        description: descripcionActual
      })
    }

    if (modo == 'editar') {
      updateSubConjuntoActionAPI(filaSeleccionadaGrid, {

        id_set: conjuntoList,
        name: nombreActual,
        description: descripcionActual
      })
    }


    cambiarVisibilidadModalInsertar(false, '');
    mostrarSubConjuntosAPI();

  }

  useEffect(() => {
    if (modo == 'nuevo') {
      setConjuntoActual('')
      setNombreActual('')
      setDescripcionActual('')
    }

    if (modo == 'editar') {
      let subConjuntoSelected = subConjuntosListAPI.filter(registro => registro.id == filaSeleccionadaGrid)[0]

      if (subConjuntoSelected != null) {
        setConjuntoActual(subConjuntoSelected.id_set)
        setNombreActual(subConjuntoSelected.name)
        setDescripcionActual(subConjuntoSelected.description)
      }
    }

  }, [modo])


  return (
    <Dialog open={visibilidadModalInsertar} onClose={() => cambiarVisibilidadModalInsertar(false, '')} fullWidth maxWidth='md'>
      <DialogTitle classes={{ root: classes.customDialogTitle }} >
        {modo == 'nuevo' ? "New Sub Asembly" : "Edit Sub Asembly"}

      </DialogTitle>
      <DialogContent>

        <Grid container spacing={2} columns={16}>
          <Grid item xs={8}>


            <FormControl variant="outlined" sx={{ m: 1, width: '37ch' }} size="small">
              <InputLabel id="label-select-subdivision">Asembly</InputLabel>
              <Select
                labelId="label-select-subdivision"
                id="Asembly"
                label="Asembly"
                onChange={e => setConjuntoActual(e.target.value)}
                value={conjuntoList}

              >

                {conjuntosListAPI.map((elemento, index) => (

                  <MenuItem key={index} value={elemento.id}> {elemento.name} </MenuItem>
                ))}

              </Select>
            </FormControl>


          </Grid>
          <Grid item xs={8}>

            <TextField
              label="Name"
              id="nombre"
              value={nombreActual}
              size="small"
              sx={{ m: 1, width: '37ch' }}
              onChange={e => setNombreActual(e.target.value)}
            />

          </Grid>
          <Grid item xs={8}>

            <TextField
              id="descripcion"
              label="Description"
              multiline
              rows={5}
              value={descripcionActual}
              size="small"
              sx={{ m: 1, width: '37ch' }}
              onChange={e => setDescripcionActual(e.target.value)}
            />

          </Grid>

        </Grid>



      </DialogContent>
      <DialogActions>


        <Button onClick={() => cambiarVisibilidadModalInsertar(false, '')}>Close</Button>
        <Button disabled={botonControlSave} onClick={() => crearConjunto()}>Save</Button>

      </DialogActions>
    </Dialog>
  )
}

