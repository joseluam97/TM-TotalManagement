import { React, useEffect, useState } from 'react'

//DataGrid importaciones
import { DataGrid } from '@mui/x-data-grid';
import DeleteIcon from "@mui/icons-material/Delete";
import EditIcon from '@mui/icons-material/Edit';
import IconButton from "@mui/material/IconButton";
import store from "app/store/index"
import { getCookie } from 'app/js/generalFunctions'
import { useDispatch, useSelector } from 'react-redux'
import Dialog from '@mui/material/Dialog';
import DialogActions from '@mui/material/DialogActions';
import DialogContent from '@mui/material/DialogContent';
import DialogTitle from '@mui/material/DialogTitle';
import Tooltip from '@mui/material/Tooltip';
import AddCircleIcon from '@mui/icons-material/AddCircle';
import FormControl from '@mui/material/FormControl';
import Select, { SelectChangeEvent } from '@mui/material/Select';
import MenuItem from '@mui/material/MenuItem';
import {
  gridPageCountSelector,
  gridPageSelector,
  useGridApiContext,
  useGridSelector,
  GridToolbarExport,
  GridToolbarDensitySelector,
  GridToolbarFilterButton,
  GridToolbarColumnsButton,
  GridToolbarContainer
} from '@mui/x-data-grid';
import Pagination from '@mui/material/Pagination';
import Divider from '@mui/material/Divider';

import Button from '@mui/material/Button';
import { makeStyles } from "@material-ui/core/styles";

import {
  mostrarSubConjuntosAPIAction,
  cambiarVisibilidadModalInsertarSubConjuntoAction,
  cambiarValorSeleccionAction,
  updateSubConjuntoActionAPIAction
} from './store/actions'

import {
  getPermisosSesionActualAPIAction
} from '../../Managment/Users/store/actions'

//Modales importaciones
import {ModalInsertar} from './modals/insertar.js'
import TableModules from '../../tables/TableModules'

import {insertarLogAPIAction} from '../../Managment/Log/store/actions'

const useStyles = makeStyles({

  customButtomPrograma: {

    margin: '1em'
  }

});


//END_ENTORNO_GLOBAL ************************************************

export default function SubConjunto() {

  const [numPagination, setNumPagination] = useState(10)
  const [addSubConjunto, setAddSubConjunto] = useState(true)
  const [changeSubConjunto, setChangeSubConjunto] = useState(true)
  const [deleteSubConjunto, setDeleteSubConjunto] = useState(true)
  const [visibilidadDialogoConfirmacion, setVisibilidadDialogoConfirmacion] = useState(false)

  const loading = useSelector(state => state.fuse.subConjuntoComponente.loading)
  const visibilidad = useSelector(state => state.fuse.divisionViewComponente.valorTabDivision)
  const subConjuntosListAPI = useSelector(state => state.fuse.subConjuntoComponente.listSubConjuntosAPI)
  const filaSeleccionadaGrid = useSelector(state => state.fuse.subConjuntoComponente.filaSeleccionadaGrid)
  const personLoginPermisos = useSelector(state => state.fuse.userComponente.personPermisos)
  const personLogin = useSelector(state => state.fuse.userComponente.person)

  const mostrarSubConjuntosAPI = () => dispatch(mostrarSubConjuntosAPIAction())
  const cambiarVisibilidadModalInsertar = (valor, modo) => dispatch(cambiarVisibilidadModalInsertarSubConjuntoAction(valor, modo))
  const cambiarValorSeleccion = (valor) => dispatch(cambiarValorSeleccionAction(valor))
  const updateSubConjuntoActionAPI = (id, conjunto) => dispatch(updateSubConjuntoActionAPIAction(id, conjunto))

  const classes = useStyles();
  const dispatch = useDispatch();

  const columnasDataTable = [
    { Header: "Name", accessor: "name", sortable: true, type: 'string' },
    { Header: "Asembly", accessor: "id_set_name", sortable: true, type: 'list' },
    { Header: "Description", accessor: "description", sortable: true, type: 'string' }
  ]

  useEffect(() => {
    mostrarSubConjuntosAPI()

    //GET USER
    store.dispatch(getPermisosSesionActualAPIAction({

      token: getCookie('token')

    }))
    //FIN GET USER
  }, [])

  useEffect(() => {
    if(visibilidad == 'subconjunto'){
      store.dispatch(insertarLogAPIAction({
        persona: personLogin['id'],
        fecha_accion: new Date().toISOString().split("T")[0],
        hora_accion: new Date().toLocaleTimeString(),
        modulo: "Sub Assembly",
        descripcion: "Entrance to Sub Assembly module"
      }))
    }
    
  }, [visibilidad])

  useEffect(() => {

    if (personLoginPermisos.find((item) => item['name'] == "Can add sub set") != undefined) {
      setAddSubConjunto(false)
    }

    if (personLoginPermisos.find((item) => item['name'] == "Can change sub set") != undefined) {
      setChangeSubConjunto(false)
    }

    if (personLoginPermisos.find((item) => item['name'] == "Can delete sub set") != undefined) {
      setDeleteSubConjunto(false)
    }

  }, [personLoginPermisos])


  function deleteSubSet() {
    let subConjuntoSelected = subConjuntosListAPI.filter(registro => registro.id == filaSeleccionadaGrid)[0]

    updateSubConjuntoActionAPI(filaSeleccionadaGrid, {
      id_set: subConjuntoSelected.id_set,
      name: subConjuntoSelected.name,
      description: subConjuntoSelected.description,
      active: false
    })

  }


  {/*function accionSubConjunto(subconjunto, caso) {


    if (caso == "Editar") {

      programasActuales()
      setNombreActual(subconjunto.nombre)
      setDescripcionActual(subconjunto.descripcion)
      setIdActual(subconjunto.id)
      setIdProgramaActual(subconjunto.id_set)
      setVisibleModalModificar(!visibleModalModificar)



    } else {

      axios.delete(baseUrl + subconjunto.id)
        .then((response) => {
          rellenaTabla()
          console.log(response.data)
          setMensajeModalSuccess("Subconjunto eliminado correctamente.")
          setVisibleModalSuccess(true)
        })
        .catch((err) => console.log(err.message));
      console.log(error.response)

    }

  }*/}

  function CustomPagination() {
    const apiRef = useGridApiContext();
    const page = useGridSelector(apiRef, gridPageSelector);
    const pageCount = useGridSelector(apiRef, gridPageCountSelector);

    function handleChange() {

    }

    return (
      <>
        <div>
          <div style={{ display: "inline" }}>
            <FormControl variant="standard" >
              <Select
                labelId="demo-simple-select-label"
                id="demo-simple-select"
                value={numPagination}
                label="Size"
                style={{ float: "right", position: "relative" }}
                onChange={e => { setNumPagination(e.target.value); }}
              >
                <MenuItem value={5}>5</MenuItem>
                <MenuItem value={10}>10</MenuItem>
                <MenuItem value={30}>30</MenuItem>
                <MenuItem value={50}>50</MenuItem>
                <MenuItem value={100}>100</MenuItem>
              </Select>
            </FormControl>
          </div>

          <div style={{ display: "inline", float: "right", position: "relative" }}>
            <Pagination
              color="primary"
              count={pageCount}
              page={page + 1}
              onChange={(event, value) => apiRef.current.setPage(value - 1)}
            />
          </div>
        </div>

      </>
    );
  }

  function botonesSuperiores() {
    return (
      <>

        <Tooltip title="New" placement="top">
          <IconButton variant="outlined" style={addSubConjunto == false ? { display: "inline" } : { display: "none" }}>
            <AddCircleIcon variant="outlined" onClick={
              () => {
                cambiarVisibilidadModalInsertar(true, 'nuevo')
              }
            }
            >
            </AddCircleIcon>
          </IconButton>
        </Tooltip>

        <Tooltip title="Edit" placement="top">
          <IconButton disabled={filaSeleccionadaGrid != '' ? false : true} style={changeSubConjunto == false ? { display: "inline" } : { display: "none" }}
            onClick={() => {
              cambiarVisibilidadModalInsertar(true, 'editar');
            }}
          >
            <EditIcon />
          </IconButton>
        </Tooltip>

        <Tooltip title="Delete" placement="top">
          <IconButton disabled={filaSeleccionadaGrid != '' ? false : true} style={deleteSubConjunto == false ? { display: "inline" } : { display: "none" }}
            onClick={() => {

              setVisibilidadDialogoConfirmacion(true)

            }}
          >
            <DeleteIcon />
          </IconButton>
        </Tooltip>

        <Divider />
      </>
    );
  }


  return (
    <>
      <div style={visibilidad == 'subconjunto' ? { display: "block" } : { display: "none" }}>

        <div style={{ width: '100%' }}>
          {botonesSuperiores()}
          <TableModules rowsProp={subConjuntosListAPI} columnsProp={columnasDataTable} loading={loading} funcionSetValue={cambiarValorSeleccion} />
        </div>

        <ModalInsertar />
      </div>

      <Dialog open={visibilidadDialogoConfirmacion} fullWidth maxWidth='xs'>

        <DialogTitle classes={{ root: classes.customDialogTitle }} >
          Confirmation
        </DialogTitle>
        <DialogContent>
          Are you sure you want to remove the sub asembly?
        </DialogContent>
        <DialogActions>

          <Button variant="outlined" onClick={() => setVisibilidadDialogoConfirmacion(false)}>Decline</Button>
          <Button variant="outlined" onClick={() => { deleteSubSet(), setVisibilidadDialogoConfirmacion(false) }}> Confirm</Button>

        </DialogActions>

      </Dialog>

    </>
  )

}