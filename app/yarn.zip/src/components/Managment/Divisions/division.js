//**********************IMPORTACIONES****************************

import { React, useEffect, useState } from 'react'

import FusePageCarded from '@fuse/core/FusePageCarded';
import Tabs from '@mui/material/Tabs';
import Tab from '@mui/material/Tab';
import Box from '@mui/material/Box';

//Componentes genéricos importaciones
import GestionSubDivision from '../../Gestion/SubDivision/SubDivision.js'
import GestionDivision from '../../Gestion/Division/Division.js'
import GestionPrograma from '../../../components/Gestion/Programa/Programa.js'
import GestionConjunto from '../../../components/Gestion/Conjunto/Conjunto.js'
import GestionSubConjunto from '../../../components/Gestion/SubConjunto/SubConjunto.js'

//Redux importaciones
import { useDispatch, useSelector } from 'react-redux'

import {
    cambiarValorTabDivisionAction
} from './store/actions'

import {
    getPermisosSesionActualAPIAction
} from '../Users/store/actions'

import { useNavigate } from "react-router-dom";

//Redux importaciones
import store from "app/store/index"
import { insertarLogAPIAction } from '../../Managment/Log/store/actions'
import { getCookie } from 'app/js/generalFunctions'



import TableLogic from 'components/tables/TableLogic.jsx';


// !!!!!!!!!!!!!!

import {

    mostrarDivisionsAPIAction,
    cambiarValorSeleccionAction as cambiarValorSeleccionActionDivision,
    cambiarVisibilidadModalInsertarAction as cambiarVisibilidadModalInsertarDivisionAction,
    insertarDivisionModalInsertarAction,
    actualizarDivisionModalInsertarAction as updateDivisionActionAPIAction
} from '../../Gestion/Division/store/actions.js'

import {
    mostrarSubDivisionsAPIAction,
    cambiarValorSeleccionAction as cambiarValorSeleccionActionSubDivision,
    cambiarVisibilidadModalInsertarAction as cambiarVisibilidadModalInsertarSubDivisionAction,
    insertarSubDivisionModalInsertarAction,
    actualizarSubDivisionModalInsertarAction as updateSubDivisionActionAPIAction
} from '../../Gestion/SubDivision/store/actions.js'


import {
    mostrarProgramasAPIAction,
    cambiarValorSeleccionAction as cambiarValorSeleccionActionPrograma,
    cambiarVisibilidadModalInsertarAction as cambiarVisibilidadModalInsertarProgramaAction,
    eliminarProgramaAction,
    consultaSubdivisionesAction,
    actualizarProgramaModalInsertarAction as updateProgramActionAPIAction
} from '../../Gestion/Programa/store/actions.js';


import {
    mostrarConjuntosAPIAction,
    cambiarValorSeleccionAction as cambiarValorSeleccionActionConjunto,
    cambiarVisibilidadModalInsertarConjuntoAction,
    updateConjuntoActionAPIAction
} from '../../Gestion/Conjunto/store/actions.js';

import {
    mostrarSubConjuntosAPIAction,
    cambiarVisibilidadModalInsertarSubConjuntoAction,
    cambiarValorSeleccionAction as cambiarValorSeleccionActionSubConjunto,
    updateSubConjuntoActionAPIAction
} from '../../Gestion/SubConjunto/store/actions.js';


// Quitar el default del export en insertar.js para que funcione la importacion por alias
import { ModalInsertar as ModalInsertarDivision } from '../../Gestion/Division/modals/insertar.js';
import { ModalInsertar as ModalInsertarSubDivision } from '../../Gestion/SubDivision/modals/insertar.js';
import { ModalInsertar as ModalInsertarPrograma } from '../../Gestion/Programa/modals/insertar.js';
import { ModalInsertar as ModalInsertarConjunto } from '../../Gestion/Conjunto/modals/insertar.js';
import { ModalInsertar as ModalInsertarSubConjunto } from '../../Gestion/SubConjunto/modals/insertar.js';


import Tooltip from '@mui/material/Tooltip';

//**********************END_IMPORTACIONES ***********************/


function Divisiones() {




    const [viewDivision, setViewDivision] = useState(true)
    const [viewSubDivision, setViewSubDivision] = useState(true)
    const [viewPrograma, setViewPrograma] = useState(true)
    const [viewConjunto, setViewConjunto] = useState(true)
    const [viewSubConjunto, setViewSubConjunto] = useState(true)

    const navigate = useNavigate();

    //obtener el state de Redux
    const valorTab = useSelector(state => state.fuse.divisionViewComponente.valorTabDivision)
    const personLoginPermisos = useSelector(state => state.fuse.userComponente.personPermisos)

    //creamos una función para hacer uso de Actions
    const dispatch = useDispatch()
    const cambiarValorTab = (valorTab) => dispatch(cambiarValorTabDivisionAction(valorTab))

    const cambiarEstado = (event, newValue) => {
        cambiarValorTab(newValue)
        //navigate('/404')
    }

    useEffect(() => {

        //GET USER
        store.dispatch(getPermisosSesionActualAPIAction({
            token: getCookie('token')
        }))
        //FIN GET USER



    }, []);



    useEffect(() => {

        if (personLoginPermisos.find((item) => item['name'] == "Can view division") != undefined) {
            setViewDivision(false)
        }
        if (personLoginPermisos.find((item) => item['name'] == "Can view sub division") != undefined) {
            setViewSubDivision(false)
        }

        if (personLoginPermisos.find((item) => item['name'] == "Can view division") == undefined &&
            personLoginPermisos.find((item) => item['name'] == "Can view sub division") == undefined) {
            navigate('/')
        }

    }, [personLoginPermisos])



    return (
        <FusePageCarded

            content={
                <Box sx={{ width: '100%' }}>


                    <Tabs
                        value={valorTab}
                        onChange={cambiarEstado}
                        textColor="secondary"
                        indicatorColor="secondary"
                        aria-label="secondary tabs example"
                    >
                        <Tab value="division" label="Division" />
                        <Tab value="subDivision" label="Sub Division" />
                        <Tab value="programa" label="Program" />
                        <Tab value="conjunto" label="Asembly" />
                        <Tab value="subconjunto" label="Sub Asembly" />

                    </Tabs>
                    <GestionDivision style={{ width: '100%' }} />
                    {/*<TableLogic
                        visibilidad={useSelector(state => state.fuse.divisionViewComponente.valorTabDivision)}
                        ModalInsertarComponent={<ModalInsertarDivision />}
                        listApiSelector={useSelector(state => state.fuse.divisionComponente.divisionesListAPI)}
                        selectedGridRowSelector={useSelector(state => state.fuse.divisionComponente.filaSeleccionadaGrid)}
                        showSectionAPIDispatch={() => dispatch(mostrarDivisionsAPIAction())}
                        changeSelectionValue={cambiarValorSeleccionActionDivision}
                        changeVisibilityInsertModalDispatch={(valor, modo) => dispatch(cambiarVisibilidadModalInsertarDivisionAction(valor, modo))}
                        updateSectionAPIDispatch={(id, conjunto) => dispatch(updateDivisionActionAPIAction(id, conjunto))}
                        columDataTableProp={[

                            {
                                field: 'name', headerName: 'Name', width: 300,
                                flex: 1,
                                renderCell: (params) => (
                                    <Tooltip title={params.value}>
                                        <span>{params.value}</span>
                                    </Tooltip>
                                )
                            },
                            {
                                field: 'description', headerName: 'Description', width: 300,
                                flex: 1,
                                renderCell: (params) => (
                                    <Tooltip title={params.value}>
                                        <span>{params.value}</span>
                                    </Tooltip>
                                )
                            }
                        ]}


                        // Pasamos todas las keys menos active. Active se configura en el componente como false directamente. 
                        updateObject={["name", "description"]}
                        sectionName='division'

                        moduleName="Division"
                        canAdd="division"

                    /> */}


                    <GestionSubDivision style={{ width: '100%' }}/>
                    {/*<TableLogic
                    visibilidad={useSelector(state => state.fuse.divisionViewComponente.valorTabDivision)}
                        ModalInsertarComponent={<ModalInsertarSubDivision />}
                        listApiSelector={useSelector(state => state.fuse.subDivisionComponente.subdivisionesListAPI)}
                        selectedGridRowSelector={useSelector(state => state.fuse.subDivisionComponente.filaSeleccionadaGrid)}
                        showSectionAPIDispatch={() => dispatch(mostrarSubDivisionsAPIAction())}
                        changeSelectionValue={cambiarValorSeleccionActionSubDivision}
                        changeVisibilityInsertModalDispatch={(valor, modo) => dispatch(cambiarVisibilidadModalInsertarSubDivisionAction(valor, modo))}
                        updateSectionAPIDispatch={(id, conjunto) => dispatch(updateSubDivisionActionAPIAction(id, conjunto))}
                        columDataTableProp={[

                            {
                                field: 'name', headerName: 'Name', width: 200,
                                flex: 1,
                                renderCell: (params) => (
                                    <Tooltip title={params.value}>
                                        <span>{params.value}</span>
                                    </Tooltip>
                                )
                            },
                            {
                                field: 'id_division_name', headerName: 'Division', width: 200,
                                flex: 1,
                                renderCell: (params) => (
                                    <Tooltip title={params.value}>
                                        <span>{params.value}</span>
                                    </Tooltip>
                                )
                            },
                            {
                                field: 'description', headerName: 'Description', width: 200,
                                flex: 1,
                                renderCell: (params) => (
                                    <Tooltip title={params.value}>
                                        <span>{params.value}</span>
                                    </Tooltip>
                                )
                            }
                        ]}


                        // Pasamos todas las keys menos active. Active se configura en el componente como false directamente. 
                        updateObject={["id_division", "name", "description"]}
                        sectionName='subDivision'

                        moduleName="Sub division"
                        canAdd="sub division"      
                    /> */}
                    <GestionPrograma style={{ width: '100%' }}/>
                    {/*<TableLogic
                    visibilidad={useSelector(state => state.fuse.divisionViewComponente.valorTabDivision)}
                        ModalInsertarComponent={<ModalInsertarPrograma />}
                        listApiSelector={useSelector(state => state.fuse.programaComponente.programasListAPI)}
                        selectedGridRowSelector={useSelector(state => state.fuse.programaComponente.filaSeleccionadaGrid)}
                        showSectionAPIDispatch={() => dispatch(mostrarProgramasAPIAction())}
                        changeSelectionValue={cambiarValorSeleccionActionPrograma}
                        changeVisibilityInsertModalDispatch={(valor, modoApertura) => dispatch(cambiarVisibilidadModalInsertarProgramaAction(valor, modoApertura))}
                        updateSectionAPIDispatch={(id, programa) => dispatch(updateProgramActionAPIAction(id, programa))}
                        columDataTableProp={[

                            {
                                field: 'name', headerName: 'Name', width: 200,
                                flex: 1,
                                renderCell: (params) =>

                                (
                                    <Tooltip title={params.value ? params.value : ""}>
                                        <span>{params.value}</span>
                                    </Tooltip>
                                )

                            },
                            {
                                field: 'id_subdivision_name', headerName: 'Sub Division', width: 200,
                                flex: 1,
                                renderCell: (params) => (
                                    <Tooltip title={params.value ? params.value : ""}>
                                        <span>{params.value}</span>
                                    </Tooltip>
                                )
                            },
                            {
                                field: 'description', headerName: 'Description', width: 200,
                                flex: 1,
                                renderCell: (params) => (
                                    <Tooltip title={params.value ? params.value : ""}>
                                        <span>{params.value}</span>
                                    </Tooltip>
                                )
                            },
                            {
                                field: 'manager', headerName: 'Manager', width: 350,
                                flex: 1,
                                renderCell: (params) => (
                                    <Tooltip title={params.value ? params.value : ""}>
                                        <span>{params.value ? params.value : ""}</span>
                                    </Tooltip>
                                )
                            }
                        ]}


                        // Pasamos todas las keys menos active. Active se configura en el componente como false directamente. 
                        updateObject={["id_subdivision", "name", "description", "manager"]}
                        sectionName='programa'

                        moduleName="Program"
                        canAdd="program"
                    /> */}



                    <GestionConjunto style={{ width: '100%' }} />
                    {/*<TableLogic
                    visibilidad={useSelector(state => state.fuse.divisionViewComponente.valorTabDivision)}
                        ModalInsertarComponent={<ModalInsertarConjunto />}
                        listApiSelector={useSelector(state => state.fuse.conjuntoComponente.listConjuntosAPI)}
                        selectedGridRowSelector={useSelector(state => state.fuse.conjuntoComponente.filaSeleccionadaGrid)}
                        showSectionAPIDispatch={() => dispatch(mostrarConjuntosAPIAction())}
                        changeSelectionValue={cambiarValorSeleccionActionConjunto}
                        changeVisibilityInsertModalDispatch={(valor, modo) => dispatch(cambiarVisibilidadModalInsertarConjuntoAction(valor, modo))}
                        updateSectionAPIDispatch={(id, conjunto) => dispatch(updateConjuntoActionAPIAction(id, conjunto))}
                        columDataTableProp={[
                            {
                                field: 'name', headerName: 'Name', width: 200,
                                flex: 1,
                                renderCell: (params) => (
                                    <Tooltip title={params.value}>
                                        <span>{params.value}</span>
                                    </Tooltip>
                                )
                            },
                            {
                                field: 'description', headerName: 'Description', width: 200,
                                flex: 1,
                                renderCell: (params) => (
                                    <Tooltip title={params.value}>
                                        <span>{params.value}</span>
                                    </Tooltip>
                                )
                            },
                            {
                                field: 'id_program_name', headerName: 'Program', width: 200,
                                flex: 1,
                                renderCell: (params) => (
                                    <Tooltip title={params.value}>
                                        <span>{params.value}</span>
                                    </Tooltip>
                                )
                            }
                        ]}


                        // Pasamos todas las keys menos active. Active se configura en el componente como false directamente. 
                        updateObject={["id_program", "name", "description"]}
                        sectionName='conjunto'

                        moduleName="Assembly"
                        canAdd="set"                   
                    /> */}


                    <GestionSubConjunto style={{ width: '100%' }}/> 
                    {/* SUBCONJUNTO */}
                    {/* <TableLogic
                    visibilidad={useSelector(state => state.fuse.divisionViewComponente.valorTabDivision)}
                        ModalInsertarComponent={<ModalInsertarSubConjunto />}
                        listApiSelector={useSelector(state => state.fuse.subConjuntoComponente.listSubConjuntosAPI)}
                        selectedGridRowSelector={useSelector(state => state.fuse.subConjuntoComponente.filaSeleccionadaGrid)}
                        showSectionAPIDispatch={() => dispatch(mostrarSubConjuntosAPIAction())}
                        changeSelectionValue={cambiarValorSeleccionActionSubConjunto}
                        changeVisibilityInsertModalDispatch={(valor, modo) => dispatch(cambiarVisibilidadModalInsertarSubConjuntoAction(valor, modo))}
                        updateSectionAPIDispatch={(id, conjunto) => dispatch(updateSubConjuntoActionAPIAction(id, conjunto))}
                        columDataTableProp={[

                            {
                                field: 'name', headerName: 'Name', width: 200,
                                flex: 1,
                                renderCell: (params) => (
                                    <Tooltip title={params.value}>
                                        <span>{params.value}</span>
                                    </Tooltip>
                                )
                            },
                            {
                                field: 'id_set_name', headerName: 'Asembly', width: 200,
                                flex: 1,
                                renderCell: (params) => (
                                    <Tooltip title={params.value}>
                                        <span>{params.value}</span>
                                    </Tooltip>
                                )
                            },
                            {
                                field: 'description', headerName: 'Description', width: 200,
                                flex: 1,
                                renderCell: (params) => (
                                    <Tooltip title={params.value}>
                                        <span>{params.value}</span>
                                    </Tooltip>
                                )
                            }
                        ]}


                        // Pasamos todas las keys menos active. Active se configura en el componente como false directamente. 
                        updateObject={["id_set", "name", "description"]}
                        sectionName='subconjunto'
                        moduleName="Sub Assembly"
                        canAdd="sub set"
       
                    />*/}

                </Box>
            }



        />
    );
}

export default Divisiones