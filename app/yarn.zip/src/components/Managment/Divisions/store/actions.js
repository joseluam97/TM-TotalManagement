import {

    CAMBIAR_VALOR_TAB_DIVISION,
    CAMBIAR_VALOR_TAB_DIVISION_EXITO,
    CAMBIAR_VALOR_TAB_DIVISION_ERROR

} from './types';



//Cambiar ValorTabDivision

export function cambiarValorTabDivisionAction(ValorTabDivision) {

    return (dispatch) => {
        dispatch (cambiarValorTabDivision())

        try {
            dispatch (cambiarValorTabDivisionExito(ValorTabDivision))

        } catch (error) {

            dispatch (cambiarValorTabDivisionError(true))
        }

    }

}

const cambiarValorTabDivision = () => ({
    type: CAMBIAR_VALOR_TAB_DIVISION,
    payload: true

})

const cambiarValorTabDivisionExito = ValorTabDivision => ({
    type: CAMBIAR_VALOR_TAB_DIVISION_EXITO,
    payload: ValorTabDivision

})

const cambiarValorTabDivisionError = estado => ({
  type: CAMBIAR_VALOR_TAB_DIVISION_ERROR,
  payload: estado
})