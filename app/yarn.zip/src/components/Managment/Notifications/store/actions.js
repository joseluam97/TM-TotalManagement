import {

    DESCARGAR_ADJUNTO_NOTIFICACION,
    DESCARGAR_ADJUNTO_NOTIFICACION_EXITO,
    DESCARGAR_ADJUNTO_NOTIFICACION_ERROR


} from './types';
import axios from 'axios'
import { showMessage } from 'app/store/fuse/messageSlice'
import { getCookie } from 'app/js/generalFunctions'

//Constantes globales
const urlNotificacionAPI = process.env.REACT_APP_URL_DJANGO + "/api/notifications/"

//************************ MOSTRAR LOG_RISK API GET **********************************************
export function descargarAdjuntoNotificacionAPIAction(idNotificacion) {

    return async (dispatch) => {
        dispatch(descargarAdjuntoNotificacionAPI(true))

        await axios({
            method: "GET",
            url: urlNotificacionAPI + "descarga/" + idNotificacion,
            headers: {
                'Authorization': `Token ${getCookie('token')}`
            }

        })
            .then(response => {

                dispatch(descargarAdjuntoNotificacionAPIExito(response.data))
            })
            .catch(error => {
                console.log(error.response)
                dispatch(descargarAdjuntoNotificacionAPIError(true))
            })

    }
}

const descargarAdjuntoNotificacionAPI = (estado) => ({
    type: DESCARGAR_ADJUNTO_NOTIFICACION,
    payload: true

})

const descargarAdjuntoNotificacionAPIExito = customers => ({
    type: DESCARGAR_ADJUNTO_NOTIFICACION_EXITO,
    payload: customers

})

const descargarAdjuntoNotificacionAPIError = estado => ({
    type: DESCARGAR_ADJUNTO_NOTIFICACION_ERROR,
    payload: estado
})
