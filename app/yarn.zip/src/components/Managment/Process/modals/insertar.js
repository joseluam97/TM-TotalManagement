import { useEffect, useState, useRef } from 'react'
import * as React from 'react';

//DataGrid importaciones


import InputLabel from '@mui/material/InputLabel';
import TextField from '@mui/material/TextField';
import Button from '@mui/material/Button';
import MenuItem from '@mui/material/MenuItem';
import Select, { SelectChangeEvent } from '@mui/material/Select';
import { makeStyles } from "@material-ui/core/styles";
import Dialog from '@mui/material/Dialog';
import DialogActions from '@mui/material/DialogActions';
import DialogContent from '@mui/material/DialogContent';
import DialogTitle from '@mui/material/DialogTitle';
import FormControl from '@mui/material/FormControl';
import Box from '@mui/material/Box';
import Grid from '@mui/material/Grid';
import Stepper from '@mui/material/Stepper';
import Step from '@mui/material/Step';
import StepButton from '@mui/material/StepButton';
import Autocomplete from '@mui/material/Autocomplete';
import SearchIcon from '@mui/icons-material/Search';
import Divider from '@mui/material/Divider';
import ArrowCircleRightIcon from '@mui/icons-material/ArrowCircleRight';

import { useDispatch, useSelector } from 'react-redux'

import {
    cambiarVisibilidadModalInsertarProcessAPI,
    insertarNewProcessAPIAction,
    putProcessAPIAction
} from '../store/actions'

const useStyles = makeStyles({

    customDialogTitle: {
        backgroundColor: 'rgb(37, 47, 62)',
        color: 'rgb(255, 255, 255)',
        marginBottom: '2em'
    }

});

export default function ModalInsertar() {

    const classes = useStyles();
    const dispatch = useDispatch()

    const [botonControlSave, setBotonControl] = useState(true);
    const [nombreActual, setNombreActual] = useState('');
    const [codeActual, setCodeActual] = useState('');
    const [subDivisionSelect, setSubDivisionSelect] = useState('');
    const [userResponsable, setUserResponsable] = useState('');
    const [userEstandarizador, setUserEstandarizador] = useState('');

    const visibilidadNewProcess = useSelector(state => state.fuse.processComponent.visibilidadNewProcess)
    const modoDialogProcess = useSelector(state => state.fuse.processComponent.modoDialogProcess)
    const filaSeleccionadaGrid = useSelector(state => state.fuse.processComponent.filaSeleccionadaGrid)
    const processListAPI = useSelector(state => state.fuse.processComponent.processListAPI)
    const usersListAPI = useSelector(state => state.fuse.userComponente.usersListAPI)
    const subdivisionesListAPI = useSelector(state => state.fuse.subDivisionComponente.subdivisionesListAPI)

    const cambiarVisibilidadModalInsertarUser = (valor, modoDialogUser) => dispatch(cambiarVisibilidadModalInsertarProcessAPI(valor, modoDialogUser))
    const insertarNewProcessAPI = (valor) => dispatch(insertarNewProcessAPIAction(valor))
    const putProcessAPI = (valor, datos) => dispatch(putProcessAPIAction(valor, datos))

    useEffect(() => {

        if (modoDialogProcess == "nuevo") {
            setNombreActual('')
            setCodeActual('')
            setSubDivisionSelect('')
            setUserResponsable('')
            setUserEstandarizador('')
        }

        if (modoDialogProcess == "editar") {

            let processSelected = processListAPI.filter(busq => busq.id == filaSeleccionadaGrid)[0]

            if (processSelected != undefined) {

                let subMisionSelect = subdivisionesListAPI.filter(busq => busq.id == processSelected.id_subDivision)[0]
                let responsableSelect = usersListAPI.filter(busq => busq.id == processSelected.responsable_proceso)[0]
                let estandarizadorSelect = usersListAPI.filter(busq => busq.id == processSelected.estandarizador_proceso)[0]

                setNombreActual(processSelected.nombre_proceso)
                setCodeActual(processSelected.code_proceso)
                if (subMisionSelect != undefined) {
                    setSubDivisionSelect(subMisionSelect)
                }

                if (responsableSelect != undefined) {
                    setUserResponsable(responsableSelect)
                }

                if (estandarizadorSelect != undefined) {
                    setUserEstandarizador(estandarizadorSelect)
                }

            }
        }

    }, [modoDialogProcess])

    useEffect(() => {
        if (nombreActual.trim() != '' && codeActual != '' && subDivisionSelect != '' && userResponsable != '' && userEstandarizador != '') {
            setBotonControl(false)
        } else {
            setBotonControl(true)
        }
    })

    function funcionProcess() {
        if (modoDialogProcess == "nuevo") {
            insertarNewProcessAPI({
                nombre_proceso: nombreActual,
                code_proceso: codeActual,
                id_subDivision: subDivisionSelect.id,
                responsable_proceso: userResponsable.id,
                estandarizador_proceso: userEstandarizador.id,
                active: true
            })
        }

        if (modoDialogProcess == "editar") {
            putProcessAPI(filaSeleccionadaGrid, {
                nombre_proceso: nombreActual,
                code_proceso: codeActual,
                id_subDivision: subDivisionSelect.id,
                responsable_proceso: userResponsable.id,
                estandarizador_proceso: userEstandarizador.id,
                active: true
            })
        }
    }

    return (
        <>
            <Dialog open={visibilidadNewProcess} fullWidth maxWidth='md'>
                <DialogTitle classes={{ root: classes.customDialogTitle }}>
                    {modoDialogProcess == 'nuevo' ? "New Process" : "Edit Process"}
                </DialogTitle>

                <DialogContent>
                    <div>

                    </div>
                    <Grid container spacing={2} columns={16} style={{ marginTop: "1px" }}>
                        <Grid item xs={8}>

                            <TextField
                                label="Code"
                                id="code"
                                value={codeActual}
                                size="small"
                                fullWidth
                                onChange={e => setCodeActual(e.target.value)}
                            />

                        </Grid>

                        <Grid item xs={8}>

                            <TextField
                                label="Name"
                                id="nombre"
                                value={nombreActual}
                                size="small"
                                fullWidth
                                onChange={e => setNombreActual(e.target.value)}
                            />

                        </Grid>

                        <Grid item xs={8}>
                            <Autocomplete
                                id="tags-outlined"
                                options={subdivisionesListAPI}
                                getOptionLabel={(option) => option.name}
                                onChange={(event, value) => setSubDivisionSelect(value)}
                                filterSelectedOptions
                                value={subDivisionSelect != '' ? subDivisionSelect : undefined}
                                size="small"
                                fullWidth
                                renderInput={(params) => (
                                    <TextField
                                        {...params}
                                        label="Sub Division"
                                        placeholder="Sub Division"
                                    />
                                )}
                            />
                        </Grid>

                        <Grid item xs={8}>
                            <Autocomplete
                                id="tags-outlined"
                                options={usersListAPI}
                                getOptionLabel={(option) => option.IDRes + " - " + option.first_name + " " + option.last_name}
                                onChange={(event, value) => setUserResponsable(value)}
                                filterSelectedOptions
                                value={userResponsable != '' ? userResponsable : undefined}
                                size="small"
                                fullWidth
                                renderInput={(params) => (
                                    <TextField
                                        {...params}
                                        label="Process manager"
                                        placeholder="Process manager"
                                    />
                                )}
                            />
                        </Grid>

                        <Grid item xs={8}>
                            <Autocomplete
                                id="tags-outlined"
                                options={usersListAPI}
                                getOptionLabel={(option) => option.IDRes + " - " + option.first_name + " " + option.last_name}
                                onChange={(event, value) => setUserEstandarizador(value)}
                                filterSelectedOptions
                                value={userEstandarizador != '' ? userEstandarizador : undefined}
                                size="small"
                                fullWidth
                                renderInput={(params) => (
                                    <TextField
                                        {...params}
                                        label="Process standardizer"
                                        placeholder="Process standardizer"
                                    />
                                )}
                            />
                        </Grid>

                    </Grid>

                </DialogContent>

                <DialogActions>
                    <Button variant="outlined" onClick={() => { cambiarVisibilidadModalInsertarUser(false, '') }}>Close</Button>
                    <Button variant="outlined" disabled={botonControlSave} onClick={() => { funcionProcess(), cambiarVisibilidadModalInsertarUser(false, '') }}> Save</Button>
                </DialogActions>
            </Dialog>
        </>
    );

}

