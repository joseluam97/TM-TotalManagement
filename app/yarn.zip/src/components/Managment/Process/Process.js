//**********************IMPORTACIONES****************************

import { React, useEffect, useState } from 'react'

//DataGrid importaciones
import { DataGrid } from '@mui/x-data-grid';
import EditIcon from '@mui/icons-material/Edit';
import IconButton from "@mui/material/IconButton";
import FusePageCarded from '@fuse/core/FusePageCarded';
import Box from '@mui/material/Box';
import AddCircleIcon from '@mui/icons-material/AddCircle';
import FormatListBulletedIcon from '@mui/icons-material/FormatListBulleted';
import Tooltip from '@mui/material/Tooltip';
import store from "app/store/index"
import ModalInsertar from './modals/insertar.js'
import { getCookie } from 'app/js/generalFunctions'
import DeleteIcon from "@mui/icons-material/Delete";
import LocationOnIcon from '@mui/icons-material/LocationOn';
import Dialog from '@mui/material/Dialog';
import DialogActions from '@mui/material/DialogActions';
import DialogContent from '@mui/material/DialogContent';
import DialogTitle from '@mui/material/DialogTitle';

import FormControl from '@mui/material/FormControl';
import Select, { SelectChangeEvent } from '@mui/material/Select';
import MenuItem from '@mui/material/MenuItem';
import {
  gridPageCountSelector,
  gridPageSelector,
  useGridApiContext,
  useGridSelector,
  GridToolbarExport,
  GridToolbarDensitySelector,
  GridToolbarFilterButton,
  GridToolbarColumnsButton,
  GridToolbarContainer
} from '@mui/x-data-grid';
import Pagination from '@mui/material/Pagination';
import Divider from '@mui/material/Divider';

import _ from '@lodash';
import { useNavigate } from "react-router-dom";

//Redux importaciones
import { useDispatch, useSelector } from 'react-redux'
import {
  mostrarProcessAPIAction,
  cambiarValorSeleccionAction,
  cambiarVisibilidadModalInsertarProcessAPI,
  putProcessAPIAction
} from './store/actions'

import {
  getSesionActualAPIAction,
  getPermisosSesionActualAPIAction,
  mostrarUserAPIAction
} from '../Users/store/actions'

import {
  mostrarSubDivisionsAPIAction
} from '../../Gestion/SubDivision/store/actions'

import Button from '@mui/material/Button';
import { makeStyles } from "@material-ui/core/styles";

import TableModules from '../../tables/TableModules'

const useStyles = makeStyles({

  customButtomPrograma: {

    margin: '1em'
  }

});

//**********************END_IMPORTACIONES ***********************/


export default function Process() {

  const dispatch = useDispatch()
  const navigate = useNavigate();
  const classes = useStyles();

  const [numPagination, setNumPagination] = useState(10)
  const [disabledNewProcess, setDisabledNewProcess] = useState(true)
  const [disabledEditProcess, setDisabledEditProcess] = useState(true)
  const [disabledDeleteProcess, setDisabledDeleteProcess] = useState(true)
  const [visibilidadDialogoConfirmacionEliminar, setVisibilidadDialogoConfirmacionEliminar] = useState(false)

  //Obtener los states de Redux
  //processComponent
  const loading = useSelector(state => state.fuse.processComponent.loading)
  const processListAPI = useSelector(state => state.fuse.processComponent.processListAPI)
  const personLoginPermisos = useSelector(state => state.fuse.userComponente.personPermisos)
  const filaSeleccionadaGrid = useSelector(state => state.fuse.processComponent.filaSeleccionadaGrid)

  //Creamos funciones para hacer uso de Actions Redux
  const cambiarValorSeleccion = (valor) => dispatch(cambiarValorSeleccionAction(valor))
  const cambiarVisibilidadModalInsertarUser = (valor, modoDialogUser) => dispatch(cambiarVisibilidadModalInsertarProcessAPI(valor, modoDialogUser))
  const mostrarCustomerAPI = () => dispatch(mostrarProcessAPIAction())
  const mostrarSubDivisionsAPI = () => dispatch(mostrarSubDivisionsAPIAction())
  const mostrarUserAPI = () => dispatch(mostrarUserAPIAction())
  const putProcessAPI = (valor, datos) => dispatch(putProcessAPIAction(valor, datos))

  const [resetStates, setResetStates] = useState(false);

  const columnasDataTable = [
    { Header: "ID", accessor: "id", sortable: true, type: 'string' },
    { Header: "Sub Division", accessor: "id_subDivision_name", sortable: true, type: 'string' },
    { Header: "Code", accessor: "code_proceso", sortable: true, type: 'string' },
    { Header: "Name", accessor: "nombre_proceso", sortable: true, type: 'string' },
    { Header: "Process manager", accessor: "fullNameResponsable", sortable: true, type: 'list' },
    { Header: "Process standardizer", accessor: "fullNameEstandarizador", sortable: true, type: 'list' },
  ]


  useEffect(() => {

    mostrarSubDivisionsAPI()
    mostrarUserAPI()

    //GET USER
    store.dispatch(getPermisosSesionActualAPIAction({

      token: getCookie('token')

    }))
    //FIN GET USER

    mostrarCustomerAPI()

  }, [])

  useEffect(() => {

    if (personLoginPermisos.length > 0) {

      if (personLoginPermisos.find((item) => item['name'] == "Can view process") == undefined) {
        navigate('/')
      }

      if (personLoginPermisos.find((item) => item['name'] == "Can add process") == undefined) {
        setDisabledNewProcess(false)
      }

      if (personLoginPermisos.find((item) => item['name'] == "Can change process") == undefined) {
        setDisabledEditProcess(false)
      }

      if (personLoginPermisos.find((item) => item['name'] == "Can delete process") == undefined) {
        setDisabledDeleteProcess(false)
      }


    }

  }, [personLoginPermisos])

  function desactivarProceso() {

    let processSelected = processListAPI.filter(busq => busq.id == filaSeleccionadaGrid)[0]

    if (processSelected != undefined) {
      putProcessAPI(filaSeleccionadaGrid, {
        nombre_proceso: processSelected.nombre_proceso,
        code_proceso: processSelected.code_proceso,
        id_subDivision: processSelected.id_subDivision,
        responsable_proceso: processSelected.responsable_proceso,
        estandarizador_proceso: processSelected.estandarizador_proceso,
        active: false
      })
    }


  }

  function CustomPagination() {
    const apiRef = useGridApiContext();
    const page = useGridSelector(apiRef, gridPageSelector);
    const pageCount = useGridSelector(apiRef, gridPageCountSelector);

    function handleChange() {

    }

    return (
      <>
        <div>
          <div style={{ display: "inline" }}>
            <FormControl variant="standard" >
              <Select
                labelId="demo-simple-select-label"
                id="demo-simple-select"
                value={numPagination}
                label="Size"
                style={{ float: "right", position: "relative" }}
                onChange={e => { setNumPagination(e.target.value); }}
              >
                <MenuItem value={5}>5</MenuItem>
                <MenuItem value={10}>10</MenuItem>
                <MenuItem value={30}>30</MenuItem>
                <MenuItem value={50}>50</MenuItem>
                <MenuItem value={100}>100</MenuItem>
              </Select>
            </FormControl>
          </div>

          <div style={{ display: "inline", float: "right", position: "relative" }}>
            <Pagination
              color="primary"
              count={pageCount}
              page={page + 1}
              onChange={(event, value) => apiRef.current.setPage(value - 1)}
            />
          </div>
        </div>

      </>
    );
  }

  function botonesSuperiores() {
    return (
      <>
        <Tooltip title="New" placement="top">
          <IconButton style={disabledNewProcess == true ? { display: "inline" } : { display: "none" }}>
            <AddCircleIcon variant="outlined" onClick={
              () => {
                cambiarVisibilidadModalInsertarUser(true, 'nuevo');
              }
            }
            >
            </AddCircleIcon>
          </IconButton>
        </Tooltip>

        <Tooltip title="Edit" placement="top">
          <IconButton style={disabledEditProcess == true ? { display: "inline" } : { display: "none" }} disabled={filaSeleccionadaGrid != '' ? false : true}>
            <EditIcon variant="outlined" onClick={() => {
              cambiarVisibilidadModalInsertarUser(true, 'editar');
            }
            }
            >
            </EditIcon>
          </IconButton>
        </Tooltip>

        <Tooltip title="Delete" placement="top">
          <IconButton disabled={filaSeleccionadaGrid != '' ? false : true} style={disabledDeleteProcess == true ? { display: "inline" } : { display: "none" }}
            onClick={() => {
              setVisibilidadDialogoConfirmacionEliminar(true)

            }}
          >
            <DeleteIcon />
          </IconButton>
        </Tooltip>

        <Divider />
      </>
    );
  }

  return (
    <>
      <FusePageCarded

        content={
          <Box sx={{ width: '100%' }}>

            <div style={{ width: '100%' }}>
              {botonesSuperiores()}
              <TableModules rowsProp={processListAPI} columnsProp={columnasDataTable} loading={loading} funcionSetValue={cambiarValorSeleccion} />
            </div>

            <ModalInsertar />
          </Box>
        }
      />

      <Dialog open={visibilidadDialogoConfirmacionEliminar} fullWidth maxWidth='xs'>

        <DialogTitle classes={{ root: classes.customDialogTitle }} >
          Confirmation
        </DialogTitle>
        <DialogContent>
          Are you sure you want to remove the process?
        </DialogContent>
        <DialogActions>

          <Button variant="outlined" onClick={() => setVisibilidadDialogoConfirmacionEliminar(false)}>Decline</Button>
          <Button variant="outlined" onClick={() => { desactivarProceso(), setVisibilidadDialogoConfirmacionEliminar(false) }}> Confirm</Button>

        </DialogActions>

      </Dialog>

    </>
  )
}

