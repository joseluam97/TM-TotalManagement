import {

    MODAL_SIN_PERMISOS,
    MODAL_SIN_PERMISOS_EXITO,
    MODAL_SIN_PERMISOS_ERROR


} from './types';
import axios from 'axios'
import { showMessage } from 'app/store/fuse/messageSlice'
import {getCookie} from 'app/js/generalFunctions'

//MOSTRAR DIALOGO SIN PERMISOS
export function mostrarModalSinPermisosAPIAction(valor) {

    return (dispatch) => {
        dispatch (mostrarModalSinPermisosAPI())

        try {
            dispatch (mostrarModalSinPermisosAPIExito(valor))
            

        } catch (error) {
            dispatch (mostrarModalSinPermisosAPIError())
        }

    }
}

const mostrarModalSinPermisosAPI = () => ({
    type: MODAL_SIN_PERMISOS,
    payload: true

})

const mostrarModalSinPermisosAPIExito = person => ({
    type: MODAL_SIN_PERMISOS_EXITO,
    payload: person

})

const mostrarModalSinPermisosAPIError = () => ({
  type: MODAL_SIN_PERMISOS_ERROR,
  payload: false
})