//**********************IMPORTACIONES****************************

import { useEffect, useState, useRef } from 'react'
import * as React from 'react';

//DataGrid importaciones
import { DataGrid } from '@mui/x-data-grid';
import DeleteIcon from "@mui/icons-material/Delete";
import EditIcon from '@mui/icons-material/Edit';

import InputLabel from '@mui/material/InputLabel';
import TextField from '@mui/material/TextField';
import Button from '@mui/material/Button';
import MenuItem from '@mui/material/MenuItem';
import Select, { SelectChangeEvent } from '@mui/material/Select';
import { showMessage } from 'app/store/fuse/messageSlice'
import { makeStyles } from "@material-ui/core/styles";
import Dialog from '@mui/material/Dialog';
import DialogActions from '@mui/material/DialogActions';
import DialogContent from '@mui/material/DialogContent';
import DialogTitle from '@mui/material/DialogTitle';
import FormControl from '@mui/material/FormControl';
import Box from '@mui/material/Box';
import Grid from '@mui/material/Grid';
import { es } from 'date-fns/locale'
import Stepper from '@mui/material/Stepper';
import Step from '@mui/material/Step';
import StepLabel from '@mui/material/StepLabel';
import Alert from '@mui/material/Alert';
import AlertTitle from '@mui/material/AlertTitle';
import Stack from '@mui/material/Stack';
import * as moment from 'moment';
import FormGroup from '@mui/material/FormGroup';
import FormControlLabel from '@mui/material/FormControlLabel';
import Switch, { SwitchProps } from '@mui/material/Switch';
import Typography from '@mui/material/Typography';
import { styled } from '@mui/material/styles';
import List from '@mui/material/List';
import ListItemText from '@mui/material/ListItemText';
import InfoOutlined from '@mui/icons-material/InfoOutlined';
import IconButton from "@mui/material/IconButton";
import ReactSpeedometer from "react-d3-speedometer"
import Radio from '@mui/material/Radio';
import RadioGroup from '@mui/material/RadioGroup';
import FormLabel from '@mui/material/FormLabel';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import Paper from '@mui/material/Paper';
import ListItem from '@mui/material/ListItem';
import ListItemButton from '@mui/material/ListItemButton';
import ListItemIcon from '@mui/material/ListItemIcon';
import Checkbox from '@mui/material/Checkbox';
import CommentIcon from '@mui/icons-material/Comment';
import ListSubheader from '@mui/material/ListSubheader';

//Redux importaciones
import { useDispatch, useSelector } from 'react-redux'
import { mostrarModalSinPermisosAPIAction } from './store/actions'

//Modales importaciones
import Chart from 'react-apexcharts';
import { useNavigate } from "react-router-dom";


//**********************END_IMPORTACIONES ***********************/

const useStyles = makeStyles({

  customDialogTitle: {
    backgroundColor: 'rgb(37, 47, 62)',
    color: 'rgb(255, 255, 255)',
    marginBottom: '2em'
  }

});



export default function TaskPermisos() {

  const visibilidadModalSinPermisos = useSelector(state => state.fuse.taskModalSinPermisosComponente.visibilidadModalSinPermisos)

  const mostrarModalSinPermisosAPI = (valor) => dispatch(mostrarModalSinPermisosAPIAction(valor))

  const classes = useStyles();
  const dispatch = useDispatch();
  const navigate = useNavigate();

  function atras(){
    navigate('/404')
}
  
  return (
    <>
      <Dialog open={visibilidadModalSinPermisos} fullWidth maxWidth='lg'>

        <DialogTitle classes={{ root: classes.customDialogTitle }}>
          User Permissions
        </DialogTitle>


        <DialogContent>
          <h3>Acceso denegado a esta seccion</h3>

        </DialogContent>
        <DialogActions>
          <Button variant="outlined" onClick={() => {atras(), dispatch(mostrarModalSinPermisosAPI(false)) }}>Aceptar</Button>
        </DialogActions>
      </Dialog>

    </>
  );
}

