//**********************IMPORTACIONES****************************

import { useEffect, useState, useRef } from 'react'
import * as React from 'react';

//DataGrid importaciones

import * as global from 'global.js';
import { showMessage } from 'app/store/fuse/messageSlice'
import InputLabel from '@mui/material/InputLabel';
import TextField from '@mui/material/TextField';
import Button from '@mui/material/Button';
import MenuItem from '@mui/material/MenuItem';
import Select, { SelectChangeEvent } from '@mui/material/Select';
import { makeStyles } from "@material-ui/core/styles";
import Dialog from '@mui/material/Dialog';
import DialogActions from '@mui/material/DialogActions';
import DialogContent from '@mui/material/DialogContent';
import DialogTitle from '@mui/material/DialogTitle';
import FormControl from '@mui/material/FormControl';
import Box from '@mui/material/Box';
import Grid from '@mui/material/Grid';
import Stepper from '@mui/material/Stepper';
import Step from '@mui/material/Step';
import StepButton from '@mui/material/StepButton';
import Autocomplete from '@mui/material/Autocomplete';
import SearchIcon from '@mui/icons-material/Search';
import Divider from '@mui/material/Divider';
import ArrowCircleRightIcon from '@mui/icons-material/ArrowCircleRight';


//Redux importaciones
import { useDispatch, useSelector } from 'react-redux'
import { cambiarVisibilidadModalInsertarUserAPI } from './store/actions'
import { cambiarVisibilidadModalInsertarPermissionsAPI } from '../UserPermissions/store/actions'

import {
  getUserAgressoAPIAction,
  insertarNewUserAPI,
  putUserAPI,
  mostrarUserPermisosAPIAction,
  mostrarUserPermisosByGroupAPIAction,
} from '../../store/actions'

import {
  getSubMisionAPIAction,
  postPersonalAsignadoContratoAPIAction,
  getAllJobAPIAction
} from '../../../../Gestion/SubMision/store/actions'

import {
  mostrarSubDivisionsAPIAction,
  actualizarSubDivisionModalInsertarAction
} from '../../../../Gestion/SubDivision/store/actions'

import {
  mostrarAllMisionAPIAction,
  mostrarMisionDepartamentosAPIAction,
  putMisionAPIAction
} from '../../../../Gestion/Mision/store/actions'

import {
  mostrarMisionPaquetesAPIAction,
  updateMisionPaqueteActionAPIAction
} from '../../../../Gestion/PaqueteTrabajo/store/actions'

import {
  postCorreoSolicitudPersonalAPIAction
} from '../../../../TabsExcel/PeopleManagement/store/actions'

import {
  mostrarAllDireccionDepartamentalAPIAction,
  mostrarAllDepartamentosAPIAction,
  putDireccionDepartamentalAPIAction,
  putDepartamentoAPIAction
} from '../../../../Gestion/Departamentos/store/actions'

import {
  insertarLogPersonaAPIAction
} from '../../../LogCambiosPersonas/store/actions'

//**********************END_IMPORTACIONES ***********************/

const useStyles = makeStyles({

  customDialogTitle: {
    backgroundColor: 'rgb(37, 47, 62)',
    color: 'rgb(255, 255, 255)',
    marginBottom: '2em'
  }

});

const steps = [
  'User data',
  'User permissions',
];

export default function NewUser() {

  const [activeStep, setActiveStep] = React.useState(0);
  const [botonControlSave, setBotonControl] = React.useState(true);


  const [numAgresso, setNumAgresso] = React.useState('');
  const [searchAgresso, setSearchAgresso] = React.useState(false);
  const [firstName, setFirstName] = React.useState('');
  const [lastName, setLastName] = React.useState('');
  const [phone, setPhone] = React.useState('');
  const [organization, setOrganization] = React.useState('');
  const [email, setEmail] = React.useState('');
  const [subMision, setSubMision] = React.useState('');
  const [rolUser, setRolUser] = React.useState('');
  const [departamentoSelect, setDepartamentoSelect] = React.useState('');
  const [direccionDepartamentalSelect, setDireccionDepartamentalSelect] = React.useState('');
  const [userAgressoLocal, setUserAgressoLocal] = React.useState('');
  //const [subDivisionSelect, setSubDivisionSelect] = React.useState('');

  const [workPackageList, setWorkPackageList] = useState('')
  const [misionList, setMisionList] = useState('')

  //const [verSelectorSubDivision, //setVerSelectorSubDivision] = useState(false);
  const [verSelectorDireccionDepartamental, setVerSelectorDireccionDepartamental] = useState(false);
  const [verSelectorDepartamento, setVerSelectorDepartamento] = useState(false);
  const [verSelectorWP, setVerSelectorWP] = useState(false);
  const [verSelectorMision, setVerSelectorMision] = useState(false);
  const [verSelectorSubMision, setVerSelectorSubMision] = useState(false);
  const [emailYaRegistrado, setEmailYaRegistrado] = useState(false);

  const visibilidadNewUser = useSelector(state => state.fuse.newUserComponente.visibilidadNewUser)
  const modoDialogUser = useSelector(state => state.fuse.newUserComponente.modoDialogUser)
  const idFilaSeleccionada = useSelector(state => state.fuse.userComponente.filaSeleccionadaGrid)
  const userList = useSelector(state => state.fuse.userComponente.allUsersListAPI)
  const nuevoUsuarioCreado = useSelector(state => state.fuse.userComponente.nuevoUsuarioCreado)
  const userAgresso = useSelector(state => state.fuse.userComponente.userAgresso)
  const listSubMisionAPI = useSelector(state => state.fuse.subMisionComponent.listSubMisiones)
  const misionPaqueteListAPI = useSelector(state => state.fuse.misionPaqueteComponente.listMisionPaquetesAPI)
  const listAllMisionAPI = useSelector(state => state.fuse.misionComponent.listAllMisionAPI)
  const listMisionDepartamentales = useSelector(state => state.fuse.misionComponent.listMisionAPI)
  const listAllDepartamentAPI = useSelector(state => state.fuse.departamentoViewComponente.listAllDepartamentAPI)
  const listAllDireccionesDepartamentalesAPI = useSelector(state => state.fuse.departamentoViewComponente.listAllDireccionesDepartamentalesAPI)
  const subdivisionesListAPI = useSelector(state => state.fuse.subDivisionComponente.subdivisionesListAPI)
  const listJobSubMision = useSelector(state => state.fuse.subMisionComponent.listJobSubMision)

  const cambiarVisibilidadModalInsertarUser = (valor, modoDialogUser) => dispatch(cambiarVisibilidadModalInsertarUserAPI(valor, modoDialogUser))
  const cambiarVisibilidadModalInsertarPermissions = (valor) => dispatch(cambiarVisibilidadModalInsertarPermissionsAPI(valor))
  const insertarNewUser = (user) => dispatch(insertarNewUserAPI(user))
  const putUser = (id, user) => dispatch(putUserAPI(id, user))
  const getSubMisionAPI = () => dispatch(getSubMisionAPIAction())
  const postPersonalAsignadoContratoAPI = (datos, mensajeSINO, subMisionBusqueda) => dispatch(postPersonalAsignadoContratoAPIAction(datos, mensajeSINO, subMisionBusqueda))
  const getUserAgressoAPI = (nAgresso) => dispatch(getUserAgressoAPIAction(nAgresso))
  const postCorreoSolicitudPersonalAPI = (cuerpoMensaje) => dispatch(postCorreoSolicitudPersonalAPIAction(cuerpoMensaje));
  const updateMisionPaqueteActionAPI = (id, conjunto) => dispatch(updateMisionPaqueteActionAPIAction(id, conjunto))
  const putMisionAPI = (idSubMision, subMisionNew) => dispatch(putMisionAPIAction(idSubMision, subMisionNew))

  const mostrarMisionPaquetesAPI = () => dispatch(mostrarMisionPaquetesAPIAction())
  const mostrarAllMisionAPI = () => dispatch(mostrarAllMisionAPIAction())
  const mostrarMisionDepartamentosAPI = () => dispatch(mostrarMisionDepartamentosAPIAction())

  const mostrarSubDivisionsAPI = () => dispatch(mostrarSubDivisionsAPIAction())
  const mostrarAllDireccionDepartamentalAPI = () => dispatch(mostrarAllDireccionDepartamentalAPIAction())
  const mostrarAllDepartamentosAPI = () => dispatch(mostrarAllDepartamentosAPIAction())
  const putDireccionDepartamentalAPI = (id, data) => dispatch(putDireccionDepartamentalAPIAction(id, data))
  const putDepartamentoAPI = (id, data) => dispatch(putDepartamentoAPIAction(id, data))
  const getAllJobAPI = (idSubMision) => dispatch(getAllJobAPIAction(idSubMision))
  const actualizarSubDivisionModalInsertar = (id, data) => dispatch(actualizarSubDivisionModalInsertarAction(id, data))
  const insertarLogPersonaAPI = (logAdd) => dispatch(insertarLogPersonaAPIAction(logAdd))

  const classes = useStyles();
  const dispatch = useDispatch()

  useEffect(() => {
    //setActiveStep(0);
    getSubMisionAPI()
    mostrarAllMisionAPI()
    mostrarMisionPaquetesAPI()
    mostrarSubDivisionsAPI()
    mostrarAllDireccionDepartamentalAPI()
    mostrarAllDepartamentosAPI()
  }, []);

  useEffect(() => {

    if (visibilidadNewUser == false) {
      //resetValues()
    }

  }, [visibilidadNewUser]);

  function resetValues() {
    setUserAgressoLocal("")
    setNumAgresso("")
    setFirstName("")
    setLastName("")
    setPhone("")
    setOrganization("")
    setEmail("")
    setSubMision("")
    setRolUser("")
    setDepartamentoSelect("")
    setDireccionDepartamentalSelect("")
    setWorkPackageList("")
    setMisionList("")
    //RESET VALUE DE CONSULTA
    getUserAgressoAPI("0000")
  }

  useEffect(() => {
    if (modoDialogUser == "nuevo" && email != "") {
      let emailExiste = userList.filter(elemento => elemento.email == email)
      if (emailExiste.length != 0) {
        setEmailYaRegistrado(true)

        dispatch(
          showMessage({
            message: "The email address you want to register is already registered.",
            variant: "error"
          })
        )
      }
      else {
        setEmailYaRegistrado(false)
      }
    }

  }, [email]);

  useEffect(() => {

    if (rolUser != "") {
      switch (rolUser) {
        case global.rolN1:
          //setVerSelectorSubDivision(true)
          setVerSelectorDireccionDepartamental(false)
          setVerSelectorDepartamento(false)
          setVerSelectorWP(false)
          setVerSelectorMision(false)
          setVerSelectorSubMision(false)

          setDireccionDepartamentalSelect('')
          setDepartamentoSelect('')
          setWorkPackageList('')
          setMisionList('')
          setSubMision('')
          break;

        case global.rolN2:
          //setVerSelectorSubDivision(false)
          setVerSelectorDireccionDepartamental(true)
          setVerSelectorDepartamento(false)
          setVerSelectorWP(false)
          setVerSelectorMision(false)
          setVerSelectorSubMision(false)

          setDepartamentoSelect('')
          setWorkPackageList('')
          setMisionList('')
          setSubMision('')
          break;

        case global.rolN3:
          //setVerSelectorSubDivision(false)
          setVerSelectorDireccionDepartamental(false)
          setVerSelectorDepartamento(true)
          setVerSelectorWP(false)
          setVerSelectorMision(false)
          setVerSelectorSubMision(false)

          setDireccionDepartamentalSelect('')
          setWorkPackageList('')
          setMisionList('')
          setSubMision('')
          break;

          case global.rolN4:
            //setVerSelectorSubDivision(false)
            setVerSelectorDireccionDepartamental(false)
            setVerSelectorDepartamento(false)
            setVerSelectorWP(true)
            setVerSelectorMision(false)
            setVerSelectorSubMision(false)
  
            setDireccionDepartamentalSelect('')
            setDepartamentoSelect('')
            setMisionList('')
            setSubMision('')
            break;

        case global.rolN5:
          //setVerSelectorSubDivision(false)
          setVerSelectorDireccionDepartamental(false)
          setVerSelectorDepartamento(false)
          setVerSelectorWP(false)
          setVerSelectorMision(true)
          setVerSelectorSubMision(false)
          break;

        case global.rolN6:
          //setVerSelectorSubDivision(false)
          setVerSelectorDireccionDepartamental(false)
          setVerSelectorDepartamento(false)
          setVerSelectorWP(false)
          setVerSelectorMision(true)
          setVerSelectorSubMision(false)

          setDireccionDepartamentalSelect('')
          setDepartamentoSelect('')
          setWorkPackageList('')
          setSubMision('')
          break;

        case global.rolN7:
          //setVerSelectorSubDivision(false)
          setVerSelectorDireccionDepartamental(false)
          setVerSelectorDepartamento(false)
          setVerSelectorWP(false)
          setVerSelectorMision(false)
          setVerSelectorSubMision(true)

          setDireccionDepartamentalSelect('')
          setDepartamentoSelect('')
          setWorkPackageList('')
          setSubMision('')
          break;

        case global.rolN8:
          //setVerSelectorSubDivision(false)
          setVerSelectorDireccionDepartamental(false)
          setVerSelectorDepartamento(false)
          setVerSelectorWP(false)
          setVerSelectorMision(false)
          setVerSelectorSubMision(true)

          setDireccionDepartamentalSelect('')
          setDepartamentoSelect('')
          setWorkPackageList('')
          setMisionList('')
          setSubMision('')
          break;
        default:
          //setVerSelectorSubDivision(false)
          setVerSelectorDireccionDepartamental(false)
          setVerSelectorDepartamento(false)
          setVerSelectorWP(false)
          setVerSelectorMision(false)
          setVerSelectorSubMision(false)

          setDireccionDepartamentalSelect('')
          setDepartamentoSelect('')
          setWorkPackageList('')
          setMisionList('')
          setSubMision('')
          break;
      }

      //setDireccionDepartamentalSelect('')
      //setDepartamentoSelect('')
      //setWorkPackageList('')
      //setMisionList('')
      //setSubMision('')

    }

  }, [rolUser]);

  useEffect(() => {
    if (rolUser == global.rolN8 || rolUser == global.rolN7) {
      if (subMision != undefined && subMision.id != undefined) {
        getAllJobAPI(subMision.id)
      }
    }
  }, [rolUser, subMision]);

  useEffect(() => {

    if (nuevoUsuarioCreado['id'] != undefined) {
      //ENVIO DE EMAILS
      /*postCorreoSolicitudPersonalAPI({
        emailEnvio: nuevoUsuarioCreado['email'],
        subject: "BIENVENIDO A CSI",
        body: "Bienvenido " + nuevoUsuarioCreado['first_name'] + " " + nuevoUsuarioCreado['last_name'] + " a CSI, su contraseña generada es: !Sevilla2022"
      })*/

      //OBTENER PERMISOS DEL NUEVO USUARIO CREADO
      dispatch(mostrarUserPermisosAPIAction(nuevoUsuarioCreado['id']))
      dispatch(mostrarUserPermisosByGroupAPIAction(nuevoUsuarioCreado['id']))


      //CREA LA ASIGNACION DE SUB MISION
      //=> ASIGNAR ROL
      if (nuevoUsuarioCreado['rolUser'] == global.rolN8 || nuevoUsuarioCreado['rolUser'] == global.rolN7) {

        if (nuevoUsuarioCreado['rolUser'] == global.rolN7) {
          //BUSQUEDA DEL ROL Manager
          let jobOwner = listJobSubMision.filter(elemento => elemento.name == "Manager")[0]
          postPersonalAsignadoContratoAPI({
            user_id: nuevoUsuarioCreado['id'],
            subMision_id: subMision.id,
            rol_employee: "permanent",
            job: jobOwner.id
          }, false, subMision.id)
        }
        if (nuevoUsuarioCreado['rolUser'] == global.rolN8) {
          //BUSQUEDA DEL ROL Manager
          let jobNoOwner = listJobSubMision.filter(elemento => elemento.name != "Manager")[0]
          if (jobNoOwner != undefined) {
            dispatch(showMessage({
              message: "You have been assigned the role: " + jobNoOwner.name + ", in case you want to modify it access to: Contract > Sub Mission > Users.",
              variant: "success"
            }))
            postPersonalAsignadoContratoAPI({
              user_id: nuevoUsuarioCreado['id'],
              subMision_id: subMision.id,
              rol_employee: "permanent",
              job: jobNoOwner.id
            }, false, subMision.id)

          }
          else {
            dispatch(showMessage({
              message: "No role has been assigned to the user, because no role other than Manager has been found. If you would like to add one, please go to: : Contract > Sub Mission > Job.",
              variant: "error"
            }))

            postPersonalAsignadoContratoAPI({
              user_id: nuevoUsuarioCreado['id'],
              subMision_id: subMision.id,
              rol_employee: "permanent",
              job: ""
            }, false, subMision.id)
          }
        }
      }

      //CREAR LA ASIGNACION DE DIRECCION DEPARTAMENTAL
      if (nuevoUsuarioCreado['rolUser'] == global.rolN2) {
        //DIRECCION DEPARTAMENTAL
        //id wp => nuevoUsuarioCreado['wpPredef']
        //let direccionDepartamentalSelect = listAllDireccionesDepartamentalesAPI.filter(elemento => elemento.id == direccionDepartamentalSelect.id)[0]
        if (direccionDepartamentalSelect != undefined) {
          let vectorResponsablesDD = direccionDepartamentalSelect.responsablesDD
          console.log(vectorResponsablesDD)
          vectorResponsablesDD.push(nuevoUsuarioCreado['id'])
          putDireccionDepartamentalAPI(direccionDepartamentalSelect.id, {
            id_subdivision: direccionDepartamentalSelect.id_subdivision,
            name: direccionDepartamentalSelect.name,
            code: direccionDepartamentalSelect.code,
            responsablesDD: vectorResponsablesDD,
            description: direccionDepartamentalSelect.description
          })

          //INSERT REGISTRO DE LOG PERSONAS
          insertarLogPersonaAPI({
            persona: nuevoUsuarioCreado['id'],
            fecha_accion: new Date().toISOString().split("T")[0],
            hora_accion: new Date().toLocaleTimeString(),
            accion: "Add",
            direccionDepartamental_relacionado: direccionDepartamentalSelect.id,
            descripcion: "User with IDRes:" + nuevoUsuarioCreado['id'] + " added to Department " + direccionDepartamentalSelect.name
          })
        }
      }

      //CREAR LA ASIGNACION DE DEPARTAMENTO A RESPONSABLE FUNCION DEPARTAMENTAL
      if (nuevoUsuarioCreado['rolUser'] == global.rolN3) {
        //DEPARTAMENTO
        //id wp => nuevoUsuarioCreado['wpPredef']
        //let departamentoSelect = listAllDepartamentAPI.filter(elemento => elemento.id == departamentoSelect.id)[0]
        if (departamentoSelect != undefined) {
          let vectorResponsablesD = departamentoSelect.responsableDepartamento
          vectorResponsablesD.push(nuevoUsuarioCreado['id'])
          putDepartamentoAPI(departamentoSelect.id, {
            id_direccion_departamental: departamentoSelect.id_direccion_departamental,
            name: departamentoSelect.name,
            code: departamentoSelect.code,
            responsableDepartamento: vectorResponsablesD,
            description: departamentoSelect.description
          })


          //INSERT REGISTRO DE LOG PERSONAS
          insertarLogPersonaAPI({
            persona: nuevoUsuarioCreado['id'],
            fecha_accion: new Date().toISOString().split("T")[0],
            hora_accion: new Date().toLocaleTimeString(),
            accion: "Add",
            departamento_relacionado: departamentoSelect.id,
            descripcion: "User with IDRes:" + nuevoUsuarioCreado['id'] + " added to Funcion Departamental " + direccionDepartamentalSelect.name
          })
        }

      }

      //CREAR LA ASIGNACION DE MISION O WP SI ES UN ROL PREDEFINIDO
      if (nuevoUsuarioCreado['rolUser'] == global.rolN4) {
        //WP
        if (workPackageList != undefined) {
          let vectorResponsablesWP = workPackageList.responsableWP
          vectorResponsablesWP.push(nuevoUsuarioCreado['id'])
          updateMisionPaqueteActionAPI(workPackageList.id, {
            id_service: workPackageList.id_service,
            name: workPackageList.name,
            description: workPackageList.description,
            code: workPackageList.code,
            responsableWP: vectorResponsablesWP,
            esDepartamento: workPackageList.esDepartamento,
          })
          //INSERT REGISTRO DE LOG PERSONAS
          insertarLogPersonaAPI({
            persona: nuevoUsuarioCreado['id'],
            fecha_accion: new Date().toISOString().split("T")[0],
            hora_accion: new Date().toLocaleTimeString(),
            accion: "Add",
            wp_relacionado: workPackageList.id,
            descripcion: "User with IDRes:" + nuevoUsuarioCreado['id'] + " added to Work Package " + workPackageList.name
          })
        }

      }
      if (nuevoUsuarioCreado['rolUser'] == global.rolN5) {
        //MISION
        //SE AÑADE COMO RESPONSABLE DE LA MISION
        if (misionList != undefined) {
          let vectorResponsablesMision = misionList.responsables
          vectorResponsablesMision.push(nuevoUsuarioCreado['id'])
          putMisionAPI(misionList.id, {
            id_workPackage: misionList.id_workPackage,
            name: misionList.name,
            code: misionList.code,
            responsables: vectorResponsablesMision,
            description: misionList.description,
            site: misionList.site,
            esDepartamento: misionList.esDepartamento,
            empleados: misionList.empleados
          })

          //INSERT REGISTRO DE LOG PERSONAS
          insertarLogPersonaAPI({
            persona: nuevoUsuarioCreado['id'],
            fecha_accion: new Date().toISOString().split("T")[0],
            hora_accion: new Date().toLocaleTimeString(),
            accion: "Add",
            mision_relacionada: misionList.id,
            descripcion: "User with IDRes:" + nuevoUsuarioCreado['id'] + " added to Mission " + misionList.name
          })
        }

      }

      if (nuevoUsuarioCreado['rolUser'] == global.rolN6) {
        //MISION
        //SE AÑADE COMO EMPLEADO DE LA MISION
        if (misionList != undefined) {
          let vectorEmpleadosMision = misionList.empleados
          vectorEmpleadosMision.push(nuevoUsuarioCreado['id'])
          putMisionAPI(misionList.id, {
            id_workPackage: misionList.id_workPackage,
            name: misionList.name,
            code: misionList.code,
            responsables: misionList.responsables,
            description: misionList.description,
            site: misionList.site,
            esDepartamento: misionList.esDepartamento,
            empleados: vectorEmpleadosMision
          })

          //INSERT REGISTRO DE LOG PERSONAS
          insertarLogPersonaAPI({
            persona: nuevoUsuarioCreado['id'],
            fecha_accion: new Date().toISOString().split("T")[0],
            hora_accion: new Date().toLocaleTimeString(),
            accion: "Add",
            mision_relacionada: misionList.id,
            descripcion: "User with IDRes:" + nuevoUsuarioCreado['id'] + " added to Mission " + misionList.name
          })
        }

      }

      setActiveStep(activeStep + 1);
    }

  }, [nuevoUsuarioCreado]);

  function busquedaAgresso() {
    if (numAgresso != '') {
      getUserAgressoAPI(numAgresso)
    }
  }

  useEffect(() => {
    if (numAgresso != "" && userAgresso != "" && userAgresso.length > 0) {
      setUserAgressoLocal(userAgresso)
    }
  }, [userAgresso]);

  useEffect(() => {

    if (userAgressoLocal.length > 0) {
      let dataUser
      if(userAgressoLocal[0] != undefined){
        dataUser = userAgressoLocal[0]
      }
      else{
        dataUser = JSON.parse(userAgressoLocal)['data'][0]
      }

      if (dataUser != undefined) {
        let formatName = dataUser['Nombre'].split(',')

        //COMPLETAR VALORES
        setFirstName(formatName[1])
        setLastName(formatName[0])
        setPhone('-')
        if(dataUser['Empresa'] != null){
          setOrganization(dataUser['Empresa'])
        }
        else{
          setOrganization('')
        }
        setEmail(dataUser['Email'])

        setSearchAgresso(true)
      }
      else {
        dispatch(
          showMessage({
            message: "User not found",
            variant: "error"
          })
        )
      }

    }

  }, [userAgressoLocal, searchAgresso]);

  function funcionAsignaBloque(usuario) {
    if (usuario.rolUser == global.rolN2) {
      //DIRECCION DEPARTAMENTAL
      let ddPredefinido = listAllDireccionesDepartamentalesAPI.filter(elemento => elemento.id == usuario.bloquePredef)[0]
      if (ddPredefinido != undefined) {
        setDireccionDepartamentalSelect(ddPredefinido)
      }
    }

    if (usuario.rolUser == global.rolN3) {
      //DEPARTAMENTO
      let dPredefinido = listAllDepartamentAPI.filter(elemento => elemento.id == usuario.bloquePredef)[0]
      if (dPredefinido != undefined) {
        setDepartamentoSelect(dPredefinido)
      }
    }

    if (usuario.rolUser == global.rolN4) {
      //WP
      let wpPredefinido = misionPaqueteListAPI.filter(elemento => elemento.id == usuario.bloquePredef)[0]
      if (wpPredefinido != undefined) {
        setWorkPackageList(wpPredefinido)
      }
    }

    if (usuario.rolUser == global.rolN6 || usuario.rolUser == global.rolN5) {
      //MISION
      let misionPredefinida = listAllMisionAPI.filter(elemento => elemento.id == usuario.bloquePredef)[0]
      if (misionPredefinida != undefined) {
        setMisionList(misionPredefinida)
      }
    }
  }

  useEffect(() => {
    setActiveStep(0);
    setSearchAgresso(false)
    setNumAgresso('')

    if (modoDialogUser == 'editar') {
      let userSelected = userList.filter(registro => registro.id == idFilaSeleccionada)[0]
      if (userSelected != null) {
        setNumAgresso(userSelected.IDRes)
        setFirstName(userSelected.first_name)
        setLastName(userSelected.last_name)
        setPhone(userSelected.phone)
        setOrganization(userSelected.organization)
        setEmail(userSelected.email)
        setRolUser(userSelected.rolUser)

        funcionAsignaBloque(userSelected)

      }
    }
    if (modoDialogUser == 'nuevo') {
      setNumAgresso('')
      setFirstName('')
      setLastName('')
      setPhone('')
      setOrganization('')
      setEmail('')
      setSubMision('')
      setRolUser('')
      setVerSelectorWP(false)
      setVerSelectorMision(false)
      setVerSelectorSubMision(false)
      setWorkPackageList('')
      setMisionList('')
      setDireccionDepartamentalSelect('')
      setDepartamentoSelect('')
    }
    if (modoDialogUser == 'consultar') {
      let userSelected = userList.filter(registro => registro.id == idFilaSeleccionada)[0];
      if (userSelected != null) {
        setNumAgresso(userSelected.IDRes)
        setFirstName(userSelected.first_name)
        setLastName(userSelected.last_name)
        setPhone(userSelected.phone)
        setOrganization(userSelected.organization)
        setEmail(userSelected.email)
        setRolUser(userSelected.rolUser)

        funcionAsignaBloque(userSelected)
      }
    }
  }, [modoDialogUser]);

  const handleStep = (step) => () => {
    if (modoDialogUser != 'nuevo') {
      setActiveStep(step);
    }
  };

  const funcionNext = () => {
    setActiveStep(activeStep + 1);

    //MOSTRAR DIALOGO DE PERMISOS DEPENDE EL PERMISO SELECCIONADO
    cambiarVisibilidadModalInsertarUser(false, '');
    cambiarVisibilidadModalInsertarPermissions(true)
  };


  useEffect(() => {
    if (emailYaRegistrado == false && firstName.trim() != '' && lastName.trim() != '' && phone.trim() != '' && organization.trim() != '' && email.trim() != '' && rolUser != '' &&
      //CONDICIONES EXTRAS
      //((verSelectorSubDivision == true && subDivisionSelect != '') || (verSelectorSubDivision == false) || (modoDialogUser == "editar")) &&
      ((verSelectorDireccionDepartamental == true && direccionDepartamentalSelect != '') || (verSelectorDireccionDepartamental == false) || (modoDialogUser == "editar")) &&
      ((verSelectorDepartamento == true && departamentoSelect != '') || (verSelectorDepartamento == false) || (modoDialogUser == "editar")) &&
      ((verSelectorWP == true && workPackageList != '') || (verSelectorWP == false) || (modoDialogUser == "editar")) &&
      ((verSelectorMision == true && misionList != '') || (verSelectorMision == false) || (modoDialogUser == "editar")) &&
      ((verSelectorSubMision == true && subMision != '') || (verSelectorSubMision == false) || (modoDialogUser == "editar"))
    ) {

      setBotonControl(false)

    } else {
      setBotonControl(true)

    }
  })

  const createUser = () => {

    //COMPROBACION QUE bloquePredef SE DEBE GUARDAR
    let idSave = ""
    let nameBloqueSave = ""
    switch (rolUser) {
      case global.rolN1:
        idSave = ""
        nameBloqueSave = ""
        break;

      case global.rolN2:
        idSave = direccionDepartamentalSelect.id
        nameBloqueSave = direccionDepartamentalSelect.name
        break;

      case global.rolN3:
        idSave = departamentoSelect.id
        nameBloqueSave = departamentoSelect.name
        break;

      case global.rolN4:
        idSave = workPackageList.id
        nameBloqueSave = workPackageList.name
        break;

      case global.rolN5:
        idSave = misionList.id
        nameBloqueSave = misionList.name
        break;

      case global.rolN6:
        idSave = misionList.id
        nameBloqueSave = misionList.name
        break;

      case global.rolN7:
        idSave = subMision.name
        nameBloqueSave = subMision.name
        break;

      case global.rolN8:
        idSave = subMision.name
        nameBloqueSave = subMision.name
        break;
    }

    //MOSTRAR DIALOGO DE PERMISOS DEPENDE EL PERMISO SELECCIONADO
    cambiarVisibilidadModalInsertarUser(false, '');
    cambiarVisibilidadModalInsertarPermissions(true)

    if (modoDialogUser == 'nuevo') {
      if (activeStep + 1 == 1) {
        //SET PERMISOS
        let vectorPermisos = []
        let today = new Date();
        insertarNewUser({
          IDRes: numAgresso,
          first_name: firstName,
          last_name: lastName,
          organization: organization,
          phone: phone,
          email: email,
          is_superuser: false,
          is_staff: false,
          is_active: true,
          date_joined: today,
          user_permissions: vectorPermisos,
          rolUser: rolUser,
          bloquePredef: idSave,
          nameBloquePredef: nameBloqueSave
        })
      }
    }

    if (modoDialogUser == 'editar') {

      let userSelected = userList.filter(registro => registro.id == idFilaSeleccionada)[0]
      if (userSelected != null) {
        if (userSelected.rolUser != rolUser) {
          //CAMBIO EL ROL DEL USUARIO Y POR TANTO CAMBIA LA ASIGNACION
          funcionActualizaAsignacionUser(userSelected, rolUser)
        }
      }

      //ACTUALIZAR USUARIO
      putUser(idFilaSeleccionada, {
        IDRes: numAgresso,
        first_name: firstName,
        last_name: lastName,
        organization: organization,
        phone: phone,
        email: email,
        rolUser: rolUser,
        bloquePredef: idSave,
        nameBloquePredef: nameBloqueSave
      })


    }
  };

  function funcionActualizaAsignacionUser(userSelected, nuevoRol) {
    //CREAR LA ASIGNACION DE DIRECCION DEPARTAMENTAL
    if (nuevoRol == global.rolN2) {
      //DIRECCION DEPARTAMENTAL
      //let direccionDepartamentalSelect = listAllDireccionesDepartamentalesAPI.filter(elemento => elemento.id == direccionDepartamentalSelect.id)[0]
      if (direccionDepartamentalSelect != undefined) {
        let vectorResponsablesDD = direccionDepartamentalSelect.responsablesDD
        vectorResponsablesDD.push(userSelected['id'])
        putDireccionDepartamentalAPI(direccionDepartamentalSelect.id, {
          id_subdivision: direccionDepartamentalSelect.id_subdivision,
          name: direccionDepartamentalSelect.name,
          code: direccionDepartamentalSelect.code,
          responsablesDD: vectorResponsablesDD,
          description: direccionDepartamentalSelect.description
        })
      }
    }

    //CREAR LA ASIGNACION DE DEPARTAMENTO A RESPONSABLE FUNCION DEPARTAMENTAL
    if (nuevoRol == global.rolN3) {
      //DEPARTAMENTO
      //let departamentoSelect = listAllDepartamentAPI.filter(elemento => elemento.id == departamentoSelect.id)[0]
      if (departamentoSelect != undefined) {
        let vectorResponsablesD = departamentoSelect.responsableDepartamento
        vectorResponsablesD.push(userSelected['id'])
        putDepartamentoAPI(departamentoSelect.id, {
          id_direccion_departamental: departamentoSelect.id_direccion_departamental,
          name: departamentoSelect.name,
          code: departamentoSelect.code,
          responsableDepartamento: vectorResponsablesD,
          description: departamentoSelect.description
        })

      }

    }

    //CREAR LA ASIGNACION DE MISION O WP SI ES UN ROL PREDEFINIDO
    if (nuevoRol == global.rolN4) {
      //WP
      if (workPackageList != undefined) {
        let vectorResponsablesWP = workPackageList.responsableWP
        vectorResponsablesWP.push(userSelected['id'])
        updateMisionPaqueteActionAPI(workPackageList.id, {
          id_service: workPackageList.id_service,
          name: workPackageList.name,
          description: workPackageList.description,
          code: workPackageList.code,
          responsableWP: vectorResponsablesWP,
          esDepartamento: workPackageList.esDepartamento,
        })

      }

    }
    if (nuevoRol == global.rolN5) {
      //MISION
      //SE AÑADE COMO RESPONSABLE DE LA MISION
      if (misionList != undefined) {
        let vectorResponsablesMision = misionList.responsables
        vectorResponsablesMision.push(userSelected['id'])
        putMisionAPI(misionList.id, {
          id_workPackage: misionList.id_workPackage,
          name: misionList.name,
          code: misionList.code,
          responsables: vectorResponsablesMision,
          description: misionList.description,
          site: misionList.site,
          esDepartamento: misionList.esDepartamento,
          empleados: misionList.empleados
        })
      }

    }

    if (nuevoRol == global.rolN6) {
      //MISION
      //SE AÑADE COMO EMPLEADO DE LA MISION
      if (misionList != undefined) {
        let vectorEmpleadosMision = misionList.empleados
        vectorEmpleadosMision.push(userSelected['id'])
        putMisionAPI(misionList.id, {
          id_workPackage: misionList.id_workPackage,
          name: misionList.name,
          code: misionList.code,
          responsables: misionList.responsables,
          description: misionList.description,
          site: misionList.site,
          esDepartamento: misionList.esDepartamento,
          empleados: vectorEmpleadosMision
        })
      }

    }
  }

  return (
    <>
      <Dialog open={visibilidadNewUser} fullWidth maxWidth='md'>
        <Box sx={{ width: '100%' }} style={{ marginTop: "20px", marginBottom: "20px" }}>

          <Stepper activeStep={activeStep} alternativeLabel>
            {steps.map((label, index) => (
              <Step key={label}>
                <StepButton color="inherit" onClick={handleStep(index)}>
                  {label}
                </StepButton>
              </Step>
            ))}
          </Stepper>

        </Box>

        <DialogTitle classes={{ root: classes.customDialogTitle }}>
          {modoDialogUser == 'editar' ? "Edit User" : modoDialogUser == 'nuevo' ? "New User" : "Details User"}
        </DialogTitle>


        <DialogContent>
          <div>{/*style={modoDialogUser == 'nuevo' ? { display: "block" } : { display: "none" }}>*/}
            <Grid container spacing={2} columns={16} >
              <Grid item xs={8}>
                <TextField
                  label="IDRes"
                  id="nAgresso"
                  value={numAgresso}
                  size="small"
                  sx={{ m: 1, width: '37ch' }}
                  onChange={e => setNumAgresso(e.target.value)}
                  disabled={modoDialogUser == 'consultar'}/*} || searchAgresso == true}*/
                />
              </Grid>

              <Grid item xs={8} style={modoDialogUser == 'nuevo' ? { display: "block" } : { display: "none" }}>
                <Button variant="contained" endIcon={<SearchIcon />} onClick={() => { busquedaAgresso() }}>
                  Search in Agresso
                </Button>
              </Grid>
            </Grid>
          </div>

          <div>{/*style={modoDialogUser == 'nuevo' ? { display: "block" } : { display: "none" }}>*/}
            <Divider style={{ margin: '20px' }} />
          </div>

          <Grid container spacing={2} columns={16}>
            <Grid item xs={8}>
              <TextField
                label="First Name"
                id="firstName"
                value={firstName}
                size="small"
                sx={{ m: 1, width: '37ch' }}
                onChange={e => setFirstName(e.target.value)}
                disabled={modoDialogUser == 'consultar' || searchAgresso == true}
              />

            </Grid>

            <Grid item xs={8}>
              <TextField
                label="Last Name"
                id="lastName"
                value={lastName}
                size="small"
                sx={{ m: 1, width: '37ch' }}
                onChange={e => setLastName(e.target.value)}
                disabled={modoDialogUser == 'consultar' || searchAgresso == true}
              />
            </Grid>

            <Grid item xs={8}>
              <TextField
                label="Phone"
                id="phone"
                value={phone}
                size="small"
                sx={{ m: 1, width: '37ch' }}
                onChange={e => setPhone(e.target.value)}
                disabled={modoDialogUser == 'consultar'}
              />
            </Grid>

            <Grid item xs={8}>
              <TextField
                label="Organization"
                id="organization"
                value={organization}
                size="small"
                sx={{ m: 1, width: '37ch' }}
                onChange={e => setOrganization(e.target.value)}
                disabled={modoDialogUser == 'consultar' || searchAgresso == true}
              />

            </Grid>

            <Grid item xs={16}>
              <TextField
                label="Email"
                id="email"
                value={email}
                size="small"
                sx={{ m: 1, width: '37ch' }}
                onChange={e => setEmail(e.target.value)}
                disabled={modoDialogUser == 'consultar' || searchAgresso == true}
              />

            </Grid>
          </Grid>

          <div>
            <Divider style={{ margin: '20px' }} />
          </div>

          <Grid container spacing={2} columns={16}>
            <Grid item xs={8}>
              <FormControl fullWidth>
                <InputLabel id="demo-simple-select-label">Rol</InputLabel>
                <Select
                  labelId="demo-simple-select-label"
                  id="rol"
                  label="Rol"
                  size="small"
                  sx={{ m: 1, width: '37ch' }}
                  disabled={modoDialogUser == 'consultar'}
                  onChange={e => { setRolUser(e.target.value); }}
                  value={rolUser}>


                  <MenuItem value={global.rolN1}>N1 - {global.rolN1}</MenuItem>
                  <MenuItem value={global.rolN2}>N2 - {global.rolN2}</MenuItem>
                  <MenuItem value={global.rolN3}>N3 - {global.rolN3}</MenuItem>
                  <MenuItem value={global.rolN4}>N4 - {global.rolN4}</MenuItem>
                  <MenuItem value={global.rolN5}>N5 - {global.rolN5}</MenuItem>
                  <MenuItem value={global.rolN6}>N6 - {global.rolN6}</MenuItem>
                  <MenuItem value={global.rolN7}>N7 - {global.rolN7}</MenuItem>
                  <MenuItem value={global.rolN8}>N8 - {global.rolN8}</MenuItem>

                </Select>
              </FormControl>
            </Grid>

            {/* INFORMACION ADICIONAL DEPENDE DE SU PERFIL */}

            <Grid item xs={8} style={verSelectorDireccionDepartamental == true ? { display: "block" } : { display: "none" }}>
              <Autocomplete
                id="tags-outlined"
                options={listAllDireccionesDepartamentalesAPI}
                value={direccionDepartamentalSelect != undefined ? direccionDepartamentalSelect : ''}
                inputValue={direccionDepartamentalSelect != null ? direccionDepartamentalSelect.name : ''}
                onChange={(event, value) => setDireccionDepartamentalSelect(value)}
                getOptionLabel={(option) =>
                  option.name != null ? option.name : ''
                }
                disabled={modoDialogUser == 'consultar'}
                filterSelectedOptions
                renderInput={(params) => (
                  <TextField
                    {...params}
                    label="Standard Departmental Directorate"
                    placeholder="Departmental Directorate"
                    size="small"
                    sx={{ m: 1, width: '37ch' }}
                  />
                )}
              />
            </Grid>

            <Grid item xs={8} style={verSelectorWP == true ? { display: "block" } : { display: "none" }}>
              <Autocomplete
                id="defaultWP"
                options={misionPaqueteListAPI}
                getOptionLabel={(option) =>
                  option.name != null ? option.name : ''
                }
                onChange={(event, value1) => setWorkPackageList(value1)}
                fullWidth
                filterSelectedOptions
                value={workPackageList != undefined ? workPackageList : ''}
                disabled={modoDialogUser == 'consultar'}
                renderInput={(params) => (
                  <TextField
                    {...params}
                    label="Standard work package"
                    placeholder="Work package"
                    size="small"
                    sx={{ m: 1, width: '37ch' }}
                  />
                )}
              />
            </Grid>

            <Grid item xs={8} style={verSelectorMision == true ? { display: "block" } : { display: "none" }}>
              <Autocomplete
                id="tags-outlined"
                options={listAllMisionAPI}
                value={misionList != undefined ? misionList : ''}
                inputValue={misionList != null ? misionList.name : ''}
                onChange={(event, value) => setMisionList(value)}
                disabled={modoDialogUser == 'consultar'}
                getOptionLabel={(option) =>
                  option.name != null ? option.name : ''
                }
                filterSelectedOptions
                renderInput={(params) => (
                  <TextField
                    {...params}
                    label="Standard mission"
                    placeholder="Mission"
                    size="small"
                    sx={{ m: 1, width: '37ch' }}
                  />
                )}
              />
            </Grid>

            <Grid item xs={8} style={verSelectorSubMision == true && modoDialogUser != "editar" ? { display: "block" } : { display: "none" }}>
              <Autocomplete
                id="tags-outlined"
                options={listSubMisionAPI}
                value={subMision != undefined ? subMision : ''}
                inputValue={subMision != null ? subMision.name : ''}
                onChange={(event, value) => setSubMision(value)}
                disabled={modoDialogUser == 'consultar'}
                getOptionLabel={(option) =>
                  option.name != null ? option.name : ''
                }
                filterSelectedOptions
                renderInput={(params) => (
                  <TextField
                    {...params}
                    label="Standard Sub Mission"
                    placeholder="Sub Mission"
                    size="small"
                    sx={{ m: 1, width: '37ch' }}
                  />
                )}
              />
            </Grid>

            <Grid item xs={8} style={verSelectorDepartamento == true ? { display: "block" } : { display: "none" }}>
              <Autocomplete
                id="tags-outlined"
                options={listAllDepartamentAPI}
                value={departamentoSelect != undefined ? departamentoSelect : ''}
                inputValue={departamentoSelect != null ? departamentoSelect.name : ''}
                onChange={(event, value) => setDepartamentoSelect(value)}
                disabled={modoDialogUser == 'consultar'}
                getOptionLabel={(option) =>
                  option.name != null ? option.name : ''
                }
                filterSelectedOptions
                renderInput={(params) => (
                  <TextField
                    {...params}
                    label="Standard Departament"
                    placeholder="Departament"
                    size="small"
                    sx={{ m: 1, width: '37ch' }}
                  />
                )}
              />
            </Grid>

            {/*<Grid item xs={8} style={verSelectorSubDivision == true && modoDialogUser == 'nuevo' ? { display: "block" } : { display: "none" }}>
              <Autocomplete
                id="tags-outlined"
                options={subdivisionesListAPI}
                value={subDivisionSelect != undefined ? subDivisionSelect : ''}
                inputValue={subDivisionSelect != null ? subDivisionSelect.name : ''}
                onChange={(event, value) => setSubDivisionSelect(value)}
                getOptionLabel={(option) =>
                  option.name != null ? option.name : ''
                }
                filterSelectedOptions
                renderInput={(params) => (
                  <TextField
                    {...params}
                    label="Sub Division"
                    placeholder="Sub Division"
                    size="small"
                    sx={{ m: 1, width: '37ch' }}
                  />
                )}
              />


                </Grid>*/}

            {/* INFORMACION ADICIONAL DEPENDE DE SU PERFIL */}
          </Grid>

        </DialogContent>
        <DialogActions>
          <Button variant="outlined" onClick={() => { cambiarVisibilidadModalInsertarUser(false, '') }}>Close</Button>
          <Button variant="outlined" disabled={botonControlSave} style={{ display: modoDialogUser == 'consultar' ? 'none' : 'block' }} onClick={() => { createUser() }}> {modoDialogUser == 'editar' ? 'Edit user and assign permissions' : 'Save user and assign permissions'} &nbsp; <ArrowCircleRightIcon /></Button>
          <Button variant="outlined" style={{ display: modoDialogUser != 'nuevo' ? 'block' : 'none' }} onClick={() => { funcionNext() }}> Next &nbsp; <ArrowCircleRightIcon /></Button>
        </DialogActions>
      </Dialog>

    </>
  );
}

