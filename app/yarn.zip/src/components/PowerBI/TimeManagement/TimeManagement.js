//**********************IMPORTACIONES****************************

import { React, useEffect, useState, useRef, useMemo } from 'react'

//DataGrid importaciones

import FusePageCarded from '@fuse/core/FusePageCarded';
import Box from '@mui/material/Box';
import Table from "../../tables/TableModules.js"
import InputLabel from '@mui/material/InputLabel';
import FormControl from '@mui/material/FormControl';
import Select, { SelectChangeEvent } from '@mui/material/Select';
import MenuItem from '@mui/material/MenuItem';

import _ from '@lodash';
import { useNavigate } from "react-router-dom";

//Redux importaciones
import { useDispatch, useSelector } from 'react-redux'
import { mostrarTimeManagementAPIAction } from './store/actions.js'

import TextField from '@mui/material/TextField';
import { Line } from 'react-chartjs-2';
import { Bar } from 'react-chartjs-2';
import { Pie } from 'react-chartjs-2';
import {
    Chart as ChartJS,
    CategoryScale,
    RadialLinearScale,
    LinearScale,
    PointElement,
    BarElement,
    LineElement,
    Title,
    Tooltip as ChartTooltip,
    Legend,
    Filler,
    ArcElement,
    scales
} from "chart.js";


ChartJS.register(
    CategoryScale,
    LinearScale,
    BarElement,
    PointElement,
    LineElement,
    ArcElement,
    RadialLinearScale,
    Title,
    ChartTooltip,
    Legend,
    Filler
);


import "react-tabulator/lib/styles.css"; // default theme
import "react-tabulator/css/bootstrap/tabulator_bootstrap.min.css"; // use Theme(s)

// import Table from "../../tables/Table.jsx";
import dayjs from "dayjs";
import {
    mostrarMisionIncluyendoMisionesHeredadasAPIAction
} from '../../Gestion/Mision/store/actions'
import {
    getEstructuraPersonalAPIAction,
} from '../../TabsExcel/PeopleManagement/store/actions'
import { Filters } from '../Components/Filters.jsx';
import {
    mostrarAllUserAPIAction,
} from '../../Managment/Users/store/actions.js'
import FilterListIcon from '@mui/icons-material/FilterList';
import "../Performance/performance.css"


//**********************END_IMPORTACIONES ***********************/


export default function TimeManagement() {
    const [unallocatedHoursChartLabels, setUnallocatedHoursChartLabels] = useState([])
    const [unallocatedHoursChartData, setUnallocatedHoursChartData] = useState([])



    // * labels
    const soldHoursDataLabels = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August ', 'September ', 'October ', 'November ', 'December'];


    // * Data
    const [soldHoursData, setSoldHoursData] = useState(null);
    const [soldHoursVsWorkingHours, setSoldHoursVsWorkingHours] = useState(null);
    const [unallocatedHoursChart, setUnallocatedHoursChart] = useState(null);
    const [topBestPerformance, setTopBestPerformance] = useState(null);

    const dispatch = useDispatch()
    const navigate = useNavigate();
    //Obtener los states de Redux
    const usersList = useSelector(state => state.fuse.userComponente.usersListAPI);

    const horasExtraSelector = useSelector(state => state.fuse.timeManagementComponent.horasExtra);
    const vacacionesSelector = useSelector(state => state.fuse.timeManagementComponent.vacaciones);
    const listMyGroup = useSelector(state => state.fuse.peopleManagementComponente.listMyGroup)
    const personLogin = useSelector(state => state.fuse.userComponente.person);

    const getEstructuraPersonalAPI = (idMember) => dispatch(getEstructuraPersonalAPIAction(idMember))
    const mostrarMisionIncluyendoMisionesHeredadasAPI = (idPerson) => dispatch(mostrarMisionIncluyendoMisionesHeredadasAPIAction(idPerson))

    const mostrarAllUserAPI = () => dispatch(mostrarAllUserAPIAction());


    // Estados
    const [fechaInicial, setFechaInicial] = useState(dayjs().year());
    const [userSelected, setUserSelected] = useState(null);
    const [misionSelected, setMisionSelected] = useState("")
    const [tableExtraHours, setTableExtraHours] = useState(null);
    const [tableHollydays, settableHollydays] = useState(null);
    const [showFilters, setShowFilters] = useState(false)
    const [fRender, setFRender] = useState(0);
    const [extraHoursGraphic, setextraHoursGraphic] = useState(null);
    const [hollydaysGraphic, sethollydaysGraphic] = useState(null);
    const [extraHoursGraphicPercent, setextraHoursGraphicPercent] = useState(null);
    const [extraHoursTeamGraphicPercent, setextraHoursTeamGraphicPercent] = useState(null);

    useEffect(() => {
        getEstructuraPersonalAPI(personLogin.id);
    }, [listMyGroup]);

    useEffect(() => {
        mostrarAllUserAPI();
    }, []);

    useEffect(() => {

        getEstructuraPersonalAPI(personLogin.id);
        if (!userSelected) {
            mostrarMisionIncluyendoMisionesHeredadasAPI(personLogin.id)
        }
        else {
            mostrarMisionIncluyendoMisionesHeredadasAPI(userSelected)
        }
    }, [userSelected, listMyGroup]);



    //! CHARTS

    // * opciones
    const options = {
        responsive: true,
        plugins: {
            legend: {
                position: 'top',
            },
        },
        scales: {
            x: {
                display: true,
                grid: {
                    display: false,
                },
            },
            y: {
                display: true,
                grid: {
                    display: true,

                    color: function (context) {
                        if (context?.tick?.value === 0) {
                            return 'rgb(224, 224, 224)';
                        }
                    },

                },
            },
        },
        maintainAspectRatio: false,
    };

    //! Peticiones
    // Sold hours / working hours
    useEffect(() => {
        if (userSelected) {
            dispatch(mostrarTimeManagementAPIAction(userSelected, { dateSelect: fechaInicial.toString(), misionSelect: misionSelected }))
        }


    }, [userSelected, misionSelected, fechaInicial]);

    useEffect(() => {



            // Configuracion graficas
            const dataSetMaker = (label, data, color) => {
                return {
                    label: label,
                    data: data,
                    backgroundColor: `${color}, 0.5)`,
                    borderColor: `${color})`,
                    borderWidth: 3,
                    borderRadius: {
                        topLeft: 50,
                        topRight: 50,
                        bottomLeft: 50,
                        bottomRight: 50,
                    },
                    borderSkipped: false,
                };
            }

            const extraerApellidos = (array) => array.map((nombre) => {
                const nombreDividido = nombre.split(","); // Dividir el string en el punto de la coma
                const apellido = nombreDividido[0].trim(); // Obtener el primer elemento y eliminar espacios en blanco
                return apellido;
            });

            //  Horas extra
            // tabla
console.log("horasExtraSelector", horasExtraSelector)
            if(horasExtraSelector.length > 0){

                const rowsHorasExtra = horasExtraSelector.map((obj, objIndex) => {
                    let result = {
                        agresso: obj["EMPLOYEE"],
                        employeeName: obj["EMPLOYEE NAME"],
                        extraHours: obj["HORAS_EXTRAS_TOTALES"],
                    };
                    return result;
                });
    
    
                const columnsExtraHours = [
                    { Header: "Agresso Code", accessor: "agresso", type: 'string'},
                    { Header: "Employee Name", accessor: "employeeName", type: 'string' },
                    {
                        Header: "Total Extra Hours", accessor: "extraHours", type: 'string', Footer: info => {
                            const total = useMemo(
                                () =>
                                    info.rows.reduce((sum, row) => row.values.extraHours + sum, 0).toFixed(2),
                                [info.rows]
                            )
    
                            return <>Total: {total}</>
                        },
                    },
    
                ];
    
    
                setTableExtraHours(<Table rowsProp={rowsHorasExtra} columnsProp={columnsExtraHours}
                    groups={[""]} />);
    
                // Grafica
    

    
    
                //  ! Graficos extraHours
    
                let extraHoursInfo = horasExtraSelector.reduce((acc, entry) => {
                    acc.employeeName.push(entry["EMPLOYEE NAME"]);
                    acc.extraHours.push(entry["HORAS_EXTRAS_TOTALES"]);
                    return acc;
                }, { employeeName: [], extraHours: [] });
    
    
                // Ordenar extraHours de mayor a menor y actualizar employeeName en consecuencia
                const sortedIndexExtraHours = extraHoursInfo.extraHours.map((_, index) => index)
                    .sort((a, b) => extraHoursInfo.extraHours[b] - extraHoursInfo.extraHours[a]);
                extraHoursInfo.extraHours = sortedIndexExtraHours.map(index => extraHoursInfo.extraHours[index]);
                extraHoursInfo.employeeName = sortedIndexExtraHours.map(index => extraHoursInfo.employeeName[index]);
    
    
    
                // Calcular el porcentaje para cada valor de extraHours
                extraHoursInfo.extraHoursPercent = extraHoursInfo.extraHours.map(hours => (hours * 100) / 80);
    
                // Calcular el porcentaje total de extraHours por equipo
                const temaExtraHours = extraHoursInfo.extraHours.reduce((acc, entry) => {
                    return acc + entry
                });
                const temaExtraHoursPercent = [((temaExtraHours * 100) / (80 * extraHoursInfo.employeeName.length)).toFixed(2)];
    

    
    
                setextraHoursGraphic(
                    {
                        labels: extraerApellidos(extraHoursInfo.employeeName),
                        datasets: [dataSetMaker('Extra Hours', extraHoursInfo.extraHours, 'rgb(0, 56, 99')]
                    }
                );
    
                setextraHoursGraphicPercent(
                    {
                        labels: extraerApellidos(extraHoursInfo.employeeName),
                        datasets: [dataSetMaker('Extra Hours Person Percent', extraHoursInfo.extraHoursPercent, 'rgb(0, 56, 99')]
                    }
                );
    
                setextraHoursTeamGraphicPercent(
                    {
                        labels: [" "],
                        datasets: [dataSetMaker('Extra Hours Team Percent', temaExtraHoursPercent, 'rgb(0, 56, 99')]
                    }
                )
            }
            else{

                setTableExtraHours(null);
                setextraHoursGraphic(
                    null
                );
                setextraHoursGraphicPercent(
                    null
                );
    
                setextraHoursTeamGraphicPercent(
                   null
                )

            }

            //  vacaciones
            // tabla


            if(vacacionesSelector.length > 0){
                const rowsVacaciones = vacacionesSelector?.map((obj, objIndex) => {
                    let result = {
                        agresso: obj["EMPLOYEE"],
                        employeeName: obj["EMPLOYEE NAME"],
                        pendingHolidays: obj["VACACIONES_PENDIENTES_HORAS"],
                        consumedHolidays: obj["VACACIONES_DISFRUTADAS_HORAS"],
                    };
                    return result;
                });
    
    
                const columnsVacaciones = [
                    { Header: "Agresso Code", accessor: "agresso", type: 'string' },
                    { Header: "Employee Name", accessor: "employeeName", type: 'string' },
                    {
                        Header: "Pending Holidays", accessor: "pendingHolidays", type: 'string', Footer: info => {
                            const total = useMemo(
                                () =>
                                    info.rows.reduce((sum, row) => row.values.pendingHolidays + sum, 0).toFixed(2),
                                [info.rows]
                            )
    
                            return <>Total: {total}</>
                        },
                    },
                    {
                        Header: "Consumed Holidays", accessor: "consumedHolidays", type: 'string', Footer: info => {
                            const total = useMemo(
                                () =>
                                    info.rows.reduce((sum, row) => row.values.consumedHolidays + sum, 0).toFixed(2),
                                [info.rows]
                            )
    
                            return <>Total: {total}</>
                        },
                    },
    
                ];
    
                settableHollydays(<Table rowsProp={rowsVacaciones} columnsProp={columnsVacaciones}
                    groups={[""]} />)
    
    
    
                //  ! Grafico vacaciones
    
                let holidaysInfo = vacacionesSelector.reduce((acc, entry) => {
    
                    acc.agresso.push(entry["EMPLOYEE"]);
                    acc.names.push(entry["EMPLOYEE NAME"]);
                    acc.pendingDays.push(entry["VACACIONES_PENDIENTES_HORAS"]);
                    acc.consumedHolidays.push(entry["VACACIONES_DISFRUTADAS_HORAS"]);
    
                    return acc;
                }, { agresso: [], pendingDays: [], consumedHolidays: [], names: [] });
    
    
                const sortedIndexHollydays = holidaysInfo.pendingDays.map((_, index) => index)
                    .sort((a, b) => holidaysInfo.pendingDays[b] - holidaysInfo.pendingDays[a]);
    
                holidaysInfo.agresso = sortedIndexHollydays.map(index => holidaysInfo.agresso[index]);
                holidaysInfo.names = sortedIndexHollydays.map(index => holidaysInfo.names[index]);
                holidaysInfo.pendingDays = sortedIndexHollydays.map(index => holidaysInfo.pendingDays[index]);
                holidaysInfo.consumedHolidays = sortedIndexHollydays.map(index => holidaysInfo.pendingDays[index]);
    
    
                sethollydaysGraphic(
                    {
                        labels: extraerApellidos(holidaysInfo.names),
                        datasets: [dataSetMaker('Holidays', holidaysInfo.pendingDays.sort((a, b) => b - a), 'rgb(0, 56, 99')]
                    }
                );

            }
            else{
                settableHollydays(<div>Sin datos</div>)
                sethollydaysGraphic(
                    null
                );
            }



    }, [horasExtraSelector, vacacionesSelector]);

    // const extraHoursViewOptions = ["Table", "Person / Hours", "Person %", "Team %", "graphics"]
    const personPerHoursGraphic = useRef(null)
    const personPercentHoursGraphic = useRef(null)
    const teamPercentHoursGraphic = useRef(null)
    const extraHoursViewOptions = ["Table", "graphics"]
    const [extraHoursViewState, setextraHoursViewState] = useState("Table");
    const labelRef = useRef(null);
    const boxRef = useRef(null);


    const handleLabelClick = (e) => {
        if (e.currentTarget === labelRef.current) {
            e.preventDefault();
            e.stopPropagation();
            setShowFilters(!showFilters);
            setFRender(f => f + 1);
            console.log('Label clicked');
        }
    };

    // useEffect(() => {
    //     function handleClickOutside(event) {
    //       if (labelRef.current && !labelRef.current.contains(event.target)) {
    //         console.log('Clic fuera del elemento');
    //         // Realiza acciones cuando se hace clic fuera del elemento

    //       }
    //     }

    //     document.addEventListener('click', handleClickOutside);

    //     return () => {
    //       document.removeEventListener('click', handleClickOutside);
    //     };
    //   }, []);

    const [selectedGraphic, setSelectedGraphic] = useState(null);
    const graphicsRefs = useRef([
        { ref: useRef(null), className: 'col-4' },
        { ref: useRef(null), className: 'col-4' },
        { ref: useRef(null), className: 'col-4' },
    ]);

    const changeGraphicClass = (index) => {
        const updatedGraphicsRefs = [...graphicsRefs.current];

        if (selectedGraphic === index) {
            updatedGraphicsRefs.forEach((graphic, i) => {
                graphic.className = 'col-4';
            });
            setSelectedGraphic(null);
        } else {
            updatedGraphicsRefs.forEach((graphic, i) => {
                if (i === index) {
                    graphic.className = 'col-12';
                } else {
                    graphic.className = 'd-none';
                }
            });
            setSelectedGraphic(index);
        }

        graphicsRefs.current = updatedGraphicsRefs;
    };


    const [graphicsComponentsHours, setgraphicsComponentsHours] = useState([]);
useEffect(()=>{
    if(extraHoursGraphic &&
        extraHoursGraphicPercent &&
        extraHoursTeamGraphicPercent ){
            setgraphicsComponentsHours([
            <>
                {extraHoursGraphic && <Line options=
                    {{
                        ...options,
                        scales: {
                            y: {
                                ...options.scales.y,
                                max: Math.max(...extraHoursGraphic.datasets[0].data, 100),
    
                                ticks: {
                                    callback: function (value) {
                                        return value + 'h'; // Añade el signo de porcentaje (%)
                                    },
                                },
                                grid: {
                                    color: function (context) {
                                        if (context?.tick?.value === 80) {
                                            return 'rgb(255, 77, 77)';
                                        }
                                    },
                                },
                            },
                            x: {
                                ...options.scales.x,
    
                            }
                        }
                    }} data={extraHoursGraphic} />}
            </>,
            <>
                {extraHoursGraphicPercent && <Bar options=
                    {{
                        ...options,
                        scales: {
                            y: {
                                ...options.scales.y,
                                max: Math.max(...extraHoursGraphicPercent.datasets[0].data, 100),
                                ticks: {
                                    callback: function (value) {
                                        return value + '%'; // Añade el signo de porcentaje (%)
                                    },
                                },
                            },
                            x: { ...options.scales.x }
                        }
                    }}
                    data={extraHoursGraphicPercent} />}
            </>,
            <>
                {extraHoursTeamGraphicPercent && <Bar options=
                    {{
                        ...options, indexAxis: 'y',
                        scales: {
                            x: {
                                max: Math.max(...extraHoursTeamGraphicPercent.datasets[0].data, 100),
                                ticks: {
                                    callback: function (value) {
                                        return value + '%'; // Añade el signo de porcentaje (%)
                                    },
                                },
                                grid: {
                                    color: function (context) {
                                        if (context?.tick?.value === 0) {
                                            return 'rgb(224, 224, 224)';
                                        }
                                    },
                                },
                            },
                            y: { ...options.scales.y, grid: { display: false } }
                        }
                    }}
                    data={extraHoursTeamGraphicPercent} />}
            </>
        ])
    }
    else{
        setgraphicsComponentsHours([])
    }

},[extraHoursGraphic,extraHoursGraphicPercent,extraHoursTeamGraphicPercent])



    return (
        <>
            <FusePageCarded



                content={
                    <Box sx={{ width: '100%' }} ref={boxRef} >


                        <Filters
                            fRender={fRender}
                            showFilters={showFilters}
                            fechaInicial={fechaInicial} setFechaInicial={setFechaInicial} usersList={usersList} userSelected={userSelected} setUserSelected={setUserSelected} misionSelected={misionSelected} setMisionSelected={setMisionSelected} page={"TimeManagement"}
                        />

                        <>

                            <div className="row m-3 p-3 border border-secondary rounded-3 " style={{ minHeight: "60vh" }}>

                                <div className="position-absolute" style={{ zIndex: 500, right: "20px", width: "auto" }} ref={labelRef} onClick={(e) => { handleLabelClick(e) }}>

                                    <FilterListIcon


                                        // onClick={(e)=>handleFilterIconClick(e) }
                                        style={{ fontSize: '50px', cursor: "pointer" }}
                                    />
                                </div>
                                <div className="row">
                                    <div className="col-3 p-3 h-100 overflow-x-scroll">

                                        <h1>Extra Hours</h1>

                                    </div>

                                    <div className="col-3">
                                        <FormControl variant="outlined" style={{ width: '100%' }} size="medium">
                                            <InputLabel id="demo-simple-select-label">Data view</InputLabel>
                                            <Select
                                                labelId="demo-simple-select-label"
                                                id="rol"
                                                label="Aggresso"
                                                value={extraHoursViewState}

                                            >
                                                {extraHoursViewOptions?.map((option) => (
                                                    <MenuItem
                                                        key={option}
                                                        value={option}
                                                        onClick={() => setextraHoursViewState(option)}
                                                    >
                                                        {`${option}`}



                                                    </MenuItem>
                                                ))}

                                            </Select>
                                        </FormControl>
                                    </div>
                                </div>

                                <div className="row p-3 h-100 overflow-x-scroll" style={{ minHeight: "50vh" }}> 

                                    {extraHoursViewState === 'Table' ? (
                                        <div className="col-12">
                                            {tableExtraHours && tableExtraHours}
                                        </div>
                                    )
                                        :
                                        graphicsComponentsHours.length > 0 ?
                                        <>
                                            {graphicsRefs.current.map((graphic, index) => (
                                                <div
                                                    style={{ minHeight: "50vh" }}
                                                    key={index}
                                                    ref={graphic.ref}
                                                    className={`${graphic.className}${selectedGraphic === index ? ' col-12' : ''}`}
                                                    onClick={() => changeGraphicClass(index)}
                                                >
                                                    {graphicsComponentsHours[index]}
                                                </div>
                                            ))}
                                        </>
                                        :
                                        <div> No data</div>
                                    }
                                </div>
                                




                                <div className="row">

                                        <h1>Holidays</h1>

  
                                    {extraHoursViewState === 'Table' ? (
                                        <div className="col-12">
                                            {tableHollydays && tableHollydays}
                                        </div>
                                    )
                                        :
                                        <div style={{ height: "50vh" }}>
                                            {hollydaysGraphic && <Bar options={options} data={hollydaysGraphic} />}

                                        </div>

                                    }
                                </div>


                            </div>
                        </>

                    </Box>
                }
            />
        </>
    )
}

