import {

    MOSTRAR_KPI_TIME_MANAGEMENT,
    MOSTRAR_KPi__TIME_MANAGEMENT,
    MOSTRAR_KPI_TIME_MANAGEMENT_ERROR,


} from './types';


// cada reducer tiene su propio state
const initialState = {
    horasExtra: [],
    vacaciones:[],
    error: null,
    loading: false,
    modoDialogKpi: '',
}


export default function (state = initialState, action) {

    switch (action.type) {

        //********** MOSTRAR KPI API**********************************/ 

        case MOSTRAR_KPI_TIME_MANAGEMENT:
            return {
                ...state,
                loading: action.payload
            }

        case MOSTRAR_KPi__TIME_MANAGEMENT:
            return {
                ...state,
                loading: false,
                error: null,
                horasExtra: action.payload[0],
                vacaciones: action.payload[1],
            }

        case MOSTRAR_KPI_TIME_MANAGEMENT_ERROR:
            return {
                ...state,
                loading: false,
                error: action.payload,
                

            }

        default:
            return state

    }

}