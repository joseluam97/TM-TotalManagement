import {

    MOSTRAR_KPI_TIME_MANAGEMENT,
    MOSTRAR_KPi__TIME_MANAGEMENT,
    MOSTRAR_KPI_TIME_MANAGEMENT_ERROR


} from './types';
import axios from 'axios'
import { showMessage } from 'app/store/fuse/messageSlice'
import { getCookie } from 'app/js/generalFunctions'

//Constantes globales
const urlHoerasExtra = process.env.REACT_APP_URL_DJANGO + "/api/powerBI/horas_bolsa/"
const urlVacaciones = process.env.REACT_APP_URL_DJANGO + "/api/powerBI/vacacionesUserGroup/"


export function mostrarTimeManagementAPIAction(idUser, data) {

    return async (dispatch) => {
        dispatch(mostrarKpiAPI(true));
        // dispatch(mostrarKpiAPIError(false));
        console.log("ACTIONS", idUser,data)
        let result = [];

        const request1 = axios({
            method: "POST",
            url: urlHoerasExtra + idUser,
            data: data,
            headers: {
                'Authorization': `Token ${getCookie('token')}`
            }
        })
        const request2 = axios({
            method: "POST",
            url: urlVacaciones + idUser,
            data: data,
            headers: {
                'Authorization': `Token ${getCookie('token')}`
            }
        })


        Promise.all([request1, request2])
            .then(([response1,response2]) => {
                result = [
                    ...(response1.status === 200 ? [response1.data] : []),
                    ...(response2.status === 200 ? [response2.data] : []),

                ];
                dispatch(mostrarKpiAPIExito(result));
            })
            .catch(error => {
                console.log(error);
                dispatch(mostrarKpiAPIError(true));
            });

    }
}

const mostrarKpiAPI = (estado) => ({
    type: MOSTRAR_KPI_TIME_MANAGEMENT,
    payload: true

})

const mostrarKpiAPIExito = data => ({
    type: MOSTRAR_KPi__TIME_MANAGEMENT,
    payload: data

})

const mostrarKpiAPIError = estado => ({
    type: MOSTRAR_KPI_TIME_MANAGEMENT_ERROR,
    payload: estado
})
