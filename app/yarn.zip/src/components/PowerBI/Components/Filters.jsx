//**********************IMPORTACIONES****************************

import { React, useEffect, useState, useRef, useMemo } from 'react'
import { useDispatch, useSelector } from 'react-redux'

//DataGrid importaciones

import InputLabel from '@mui/material/InputLabel';


import FormControl from '@mui/material/FormControl';
import Select, { SelectChangeEvent } from '@mui/material/Select';
import MenuItem from '@mui/material/MenuItem';


import { AdapterDateFns } from '@mui/x-date-pickers/AdapterDateFns';
import { LocalizationProvider } from '@mui/x-date-pickers/LocalizationProvider';
import { es } from 'date-fns/locale'
import { DatePicker } from '@mui/x-date-pickers/DatePicker';
import TextField from '@mui/material/TextField';
import { makeStyles } from '@mui/styles';



import dayjs from "dayjs";
import UserPermissions from 'components/Managment/Users/modals/UserPermissions/UserPermissions';
import './filters.css'
import { borderRadius } from '@mui/system';

// const dateStyles = makeStyles((theme) => ({
//     select: {
//       color: (value) => (value !== '' ? 'green' : 'gray'),
//     },
//   }));

const pages = {
    performance: "Performance",
    timeManagement: "TimeManagement"
}

const useStyles = makeStyles((theme) => ({
    formControl: {
        '& .MuiInputLabel-root': {
            color: 'white',
            borderColor: 'white',
        },
        '& .MuiInputBase-input': {
            color: 'white',
            borderColor: 'white',
        },
        '& .MuiSvgIcon-root': {
            color: 'white !important',
            borderColor: 'white',
        },
        '& .muiltr-1d3z3hw-MuiOutlinedInput-notchedOutline': {
            borderColor: 'white',
        },
        '& .MuiOutlinedInput-root': {
            '& fieldset': {
              borderColor: 'white',
            },
            '&:hover fieldset': {
              borderColor: 'white',
            },
            '&.Mui-focused fieldset': {
              borderColor: 'white',
            },
          },
    },
    outlinedInput: {
        '& .MuiOutlinedInput-root .MuiOutlinedInput-notchedOutline': {
            borderColor: 'white',
        },

    },
}));






export const Filters = ({ fRender, showFilters, fechaInicial, setFechaInicial, fechaFinal, setFechaFinal, usersList, userSelected, setUserSelected, misionSelected, setMisionSelected, page}) => {

// useEffect(()=>{
//     setHide(hied=>!hied)
// },[showFilters])
    const personLoginPermisos = useSelector(state => state.fuse.userComponente.personPermisos);
    const personLogin = useSelector(state => state.fuse.userComponente.person);
    const listMisionAPI = useSelector(state => state.fuse.misionComponent.listMisionAPI)

    const [canSetPowerBi, setcanSetPowerBi] = useState(null);




    useEffect(() => {
        setUserSelected(personLogin.id)
        personLoginPermisos.find(item => item.name === 'Can add log entry') ? setcanSetPowerBi(true) : () => { setcanSetPowerBi(false); }

    }, [personLoginPermisos])




    const className = () => {
        if (!showFilters && fRender === 0) {
            return "d-none"
        }
        else if (showFilters && fRender >= 1) {

            return "row m-3 slide-in-left"
        }
        else {
            return "row m-3 slide-in-right"

        }
    }

    const filterRef = useRef(null);




    const classes = useStyles();
    // const misionClass = misionStyles(null); // Obtener las clases de estilos directamente



    return (


        <div className={className()} ref={filterRef} style={{
            padding: "15px",
            position: "absolute",
            display: "flex",
            flexDirection: "column",
            background: "rgb(0, 56, 99)",
            gap: "10px",
            zIndex: 1000,
            right: "50px",
            borderRadius:"5%"
            
        }}>
            <div className="col-12">

                <FormControl variant="outlined" fullWidth classes={{ root: classes.formControl }}>
                    {
                        page === pages.timeManagement && (
                            <LocalizationProvider dateAdapter={AdapterDateFns} locale={es}>
                                <DatePicker
                                    label="Start date"
                                    fullWidth
                                    id="fechaInicial"
                                    inputFormat="yyyy"
                                    format="yyyy"
                                    views={['year']} // Mostrar solo el año
                                    value={new Date(fechaInicial, 0, 1)}
                                    // maxDate={fechaFinal}
                                    onChange={(newValue) => setFechaInicial(dayjs(newValue).year())}
                                    renderInput={(params) => (
                                        <TextField {...params} classes={{ root: classes.outlinedInput }} />
                                    )}
                                />
                            </LocalizationProvider>
                        )

                    }
                    {
                        page === pages.performance && (
                            <LocalizationProvider locale={es} dateAdapter={AdapterDateFns}>
                                <DatePicker
                                    label="Start date"
                                    fullWidth
                                    id="fechaInicial"
                                    inputFormat="dd-MM-yyyy"
                                    format="dd-MM-yyyy"
                                    value={fechaInicial}
                                    maxDate={fechaFinal}
                                    onChange={(newValue) => setFechaInicial(dayjs(newValue))}
                                    renderInput={(params) => (
                                        <TextField {...params} classes={{ root: classes.outlinedInput }} />
                                    )}
                                />
                            </LocalizationProvider>
                        )
                    }


                </FormControl>
            </div>

            {
                page !== pages.timeManagement && (
                    <div className="col-12">
                        <FormControl variant="outlined" fullWidth classes={{ root: classes.formControl }}>
                            <LocalizationProvider locale={es} dateAdapter={AdapterDateFns} >
                                <DatePicker
                                    label="End date"
                                    fullWidth
                                    inputFormat="dd-MM-yyyy"
                                    format="dd-MM-yyyy"
                                    value={fechaFinal}
                                    minDate={fechaInicial}
                                    maxDate={dayjs()}
                                    onChange={(newValue) => setFechaFinal(dayjs(newValue))}
                                    renderInput={(params) => (
                                        <TextField {...params} classes={{ root: classes.outlinedInput }} />
                                    )}
                                />
                            </LocalizationProvider>
                        </FormControl>
                    </div>
                )
            }


            {
                canSetPowerBi &&

                <div className="col-12">


                    <FormControl variant="outlined" style={{ width: '100%' }} size="medium" classes={{ root: classes.formControl }}>
                        <InputLabel id="demo-simple-select-label">Agresso</InputLabel>
                        <Select
                            labelId="demo-simple-select-label"
                            id="rol"
                            label="Aggresso"
                            value={userSelected || ''}

                        >
                            {usersList?.map((user) => (
                                <MenuItem

                                    key={user.id}
                                    value={user.id}
                                    onClick={() => setUserSelected(user.id)}
                                >
                                    {`${user.IDRes} - ${user.first_name} ${user.last_name}`}



                                </MenuItem>
                            ))}

                        </Select>
                    </FormControl>

                </div>
            }

            <div className="col-12">
                {
                    listMisionAPI?.length > 0 &&
                    <FormControl variant="outlined" style={{ width: "100%" }} size="medium" classes={{ root: classes.formControl }}>
                        <InputLabel id="demo-simple-select-label">Mision</InputLabel>
                        <Select
                            labelId="demo-simple-select-label"
                            id="rol"
                            label="Mision"
                            value={misionSelected || ""}


                        >
                            {listMisionAPI.map((misionSelected, id) => (
                                <MenuItem key={id} value={misionSelected.id} onClick={() => setMisionSelected(misionSelected.id)} >

                                    {misionSelected.name}
                                </MenuItem>
                            ))}
                        </Select>
                    </FormControl>
                }

            </div>





        </div>
  



    )
}
