import { useEffect, useState, useRef } from 'react'
import * as React from 'react';

//DataGrid importaciones

import OutlinedInput from '@mui/material/OutlinedInput';
import InputLabel from '@mui/material/InputLabel';
import TextField from '@mui/material/TextField';
import Button from '@mui/material/Button';
import MenuItem from '@mui/material/MenuItem';
import Select, { SelectChangeEvent } from '@mui/material/Select';
import { makeStyles } from "@material-ui/core/styles";
import Dialog from '@mui/material/Dialog';
import DialogActions from '@mui/material/DialogActions';
import DialogContent from '@mui/material/DialogContent';
import DialogTitle from '@mui/material/DialogTitle';
import FormControl from '@mui/material/FormControl';
import Box from '@mui/material/Box';
import Grid from '@mui/material/Grid';
import Stepper from '@mui/material/Stepper';
import Step from '@mui/material/Step';
import StepButton from '@mui/material/StepButton';
import Autocomplete from '@mui/material/Autocomplete';
import SearchIcon from '@mui/icons-material/Search';
import Divider from '@mui/material/Divider';
import ArrowCircleRightIcon from '@mui/icons-material/ArrowCircleRight';
import Checkbox from '@mui/material/Checkbox';
import ListItemText from '@mui/material/ListItemText';
import Alert from '@mui/material/Alert';
import AlertTitle from '@mui/material/AlertTitle';

import { useDispatch, useSelector } from 'react-redux'

const useStyles = makeStyles({

    customDialogTitle: {
        backgroundColor: 'rgb(37, 47, 62)',
        color: 'rgb(255, 255, 255)',
        marginBottom: '2em'
    }

});
export default function ModalInsertar() {

    const classes = useStyles();
    const dispatch = useDispatch()

    return (
        <>
            <Dialog open={false} fullWidth maxWidth='lg'>
                <DialogTitle classes={{ root: classes.customDialogTitle }}>
                    titulo
                </DialogTitle>

                <DialogContent>

                    

                </DialogContent>

                <DialogActions>
                    <Button variant="outlined">Close</Button>
                    <Button variant="outlined"> Save</Button>
                </DialogActions>
            </Dialog>
        </>
    );

}

