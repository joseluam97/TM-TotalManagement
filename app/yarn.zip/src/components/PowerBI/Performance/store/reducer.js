import {

    MOSTRAR_KPI_PERFORMANCE,
    MOSTRAR_KPI_PERFORMANCE_EXITO,
    MOSTRAR_KPI_PERFORMANCE_ERROR,
    DATOS_CONSULTA


} from './types';

import dayjs from "dayjs";


// cada reducer tiene su propio state
const initialState = {
    soldHoursBrakeDown: [],
    error: null,
    loading: false,
    modoDialogKpi: '',
    soldVsWorkHours: [],
    bestWorstPerformance: [],
    datosConsulta: {
        user: null,
        yearsSelect: [],
        datesSelect: [dayjs('01-04-2023', 'DD-MM-YYYY'), dayjs()],
        mision: "",
    }
}


export default function (state = initialState, action) {

    switch (action.type) {


        //********** MOSTRAR KPI API**********************************/ 

        case DATOS_CONSULTA:
            return {
                ...state,
                datosConsulta: {
                    user: action.payload.idUser,
                    yearsSelect: action.payload.yearsSelect,
                    datesSelect: action.payload.datesSelect,
                    mision: action.payload.mision
                }
            }

        case MOSTRAR_KPI_PERFORMANCE:
            return {
                ...state,
                loading: action.payload
            }

        case MOSTRAR_KPI_PERFORMANCE_EXITO:
            return {
                ...state,
                loading: false,
                error: null,
                soldVsWorkHours: action.payload[0],
                bestWorstPerformance: action.payload[1],


            }

        case MOSTRAR_KPI_PERFORMANCE_ERROR:
            return {
                ...state,
                loading: false,
                error: action.payload

            }


        default:
            return state

    }

}