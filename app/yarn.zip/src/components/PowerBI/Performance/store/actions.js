import {

    MOSTRAR_KPI_PERFORMANCE,
    MOSTRAR_KPI_PERFORMANCE_EXITO,
    MOSTRAR_KPI_PERFORMANCE_ERROR,
    DATOS_CONSULTA,
} from './types';
import axios from 'axios'
import { showMessage } from 'app/store/fuse/messageSlice'
import { getCookie } from 'app/js/generalFunctions'
import dayjs from "dayjs";


//Constantes globales
const urlSoldVsWork = process.env.REACT_APP_URL_DJANGO + "/api/agresso/performance/chart/workload_user/"
const urlBestWorst = process.env.REACT_APP_URL_DJANGO + "/api/agresso/performance/chart/workload_user_group_by/"


export function guardarDatos(idUser, data) {
    return (dispatch) => {
        dispatch(datosConsulta({
            idUser: idUser,
            datesSelect: data.datesSelect,
            yearsSelect: data.yearsSelect,
            mision: data.misionSelect
        }))
    }
}




export function mostrarPerformanceAPIAction(idUser, data) {
    console.log("ACTIONS", idUser, data)

    
    return async (dispatch) => {
        let result = [[], []];
        dispatch(mostrarKpiAPI(true));

        try {
            const response1 = await axios({
                method: "POST",
                url: urlSoldVsWork + idUser,
                data: data,
                headers: {
                    'Authorization': `Token ${getCookie('token')}`
                }
            });


            result[0] = (response1.status === 200 ? response1.data : null);

        } catch (error) {
            result[0] = null;
            console.log(error);

        }
        try {
            const response2 = await axios({
                method: "POST",
                url: urlBestWorst + idUser,
                data: data,
                headers: {
                    'Authorization': `Token ${getCookie('token')}`
                }
            });

            result[1] = (response2.status === 200 ? response2.data : null);

        } catch (error) {
            result[1] = null;
            console.log(error);
        }
        if (result[0] || result[1]) {
            dispatch(mostrarKpiAPIExito(result));
        }
        else if (!result[0] && !result[1]) {
            dispatch(mostrarKpiAPIError(true));
        }
    }

}


const datosConsulta = (data) => ({
    type: DATOS_CONSULTA,
    payload: data

})

const mostrarKpiAPI = (estado) => ({
    type: MOSTRAR_KPI_PERFORMANCE,
    payload: true

})

const mostrarKpiAPIExito = data => ({
    type: MOSTRAR_KPI_PERFORMANCE_EXITO,
    payload: data

})

const mostrarKpiAPIError = estado => ({
    type: MOSTRAR_KPI_PERFORMANCE_ERROR,
    payload: estado
});


