//**********************IMPORTACIONES****************************

import { React, useEffect, useState, useRef, useMemo } from 'react'

//DataGrid importaciones
import FusePageCarded from '@fuse/core/FusePageCarded';
import Box from '@mui/material/Box';
import _ from '@lodash';
import { useNavigate } from "react-router-dom";

//Redux importaciones
import { useDispatch, useSelector } from 'react-redux'
import { mostrarPerformanceAPIAction, guardarDatos } from './store/actions.js'
import {
  mostrarAllUserAPIAction,
} from '../../Managment/Users/store/actions.js'
import { Line } from 'react-chartjs-2';
import { Bar } from 'react-chartjs-2';
import {
  Chart as ChartJS,
  CategoryScale,
  BarElement,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip as chartTooltip,
  Legend,
} from 'chart.js';

ChartJS.register(
  CategoryScale,
  BarElement,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  chartTooltip,
  Legend
);
import "react-tabulator/lib/styles.css"; // default theme
import "react-tabulator/css/bootstrap/tabulator_bootstrap.min.css"; // use Theme(s)
import Table from "../../tables/Table.jsx";
import dayjs from "dayjs";
import { Filters } from '../Components/Filters.jsx';
import LinearProgress from '@mui/material/LinearProgress';
import Typography from '@mui/material/Typography';
import {
  mostrarMisionIncluyendoMisionesHeredadasAPIAction
} from '../../Gestion/Mision/store/actions'
import {
  getEstructuraPersonalAPIAction,
} from '../../TabsExcel/PeopleManagement/store/actions'
import "./performance.css"


//**********************END_IMPORTACIONES ***********************/


export default function Performance() {

  const dispatch = useDispatch()
  const navigate = useNavigate();

  //Obtener los states de Redux
  const datosConsulta = useSelector(state => state.fuse.performanceComponent.datosConsulta);
  const soldHoursBrakeDown = useSelector(state => state.fuse.performanceComponent.soldHoursBrakeDown);
  const soldVsWorkHours = useSelector(state => state.fuse.performanceComponent.soldVsWorkHours);
  const bestWorstPerformance = useSelector(state => state.fuse.performanceComponent.bestWorstPerformance);
  const loading = useSelector(state => state.fuse.performanceComponent.loading);
  const error = useSelector(state => state.fuse.performanceComponent.error);

  const personLogin = useSelector(state => state.fuse.userComponente.person);
  const personLoginPermisos = useSelector(state => state.fuse.userComponente.personPermisos);
  const usersList = useSelector(state => state.fuse.userComponente.usersListAPI);
  const listMisionAPI = useSelector(state => state.fuse.misionComponent.listMisionAPI);
  const listMyGroup = useSelector(state => state.fuse.peopleManagementComponente.listMyGroup)
  // const personLoginId = useSelector(state => state.fuse.userComponente.person.id)


  const getEstructuraPersonalAPI = (idMember) => dispatch(getEstructuraPersonalAPIAction(idMember))
  // const kpiListApiDispatch = (idUser, dates, mision) => dispatch(mostrarPerformanceAPIAction(idUser, dates, mision));
  const mostrarMisionIncluyendoMisionesHeredadasAPI = (idPerson) => dispatch(mostrarMisionIncluyendoMisionesHeredadasAPIAction(idPerson))

  const mostrarAllUserAPI = () => dispatch(mostrarAllUserAPIAction());

  // Estados

  const [fechaInicial, setFechaInicial] = useState(null);
  const [fechaFinal, setFechaFinal] = useState(null);
  const [intermediateDates, setIntermediateDates] = useState(null);
  const [userSelected, setUserSelected] = useState(null);
  const [tableRows, setTableRows] = useState(null);
  const [tableColumns, setTableColumnss] = useState(null);
  const [table, setTable] = useState(null);
  const [misionSelected, setMisionSelected] = useState("");
  const [showTable, setShowTable] = useState(false);
  const [showFilters, setShowFilters] = useState(false)
  const [fRender, setFRender] = useState(0)




  //! CHARTS

  // * opciones
  const options = {
    responsive: true,
    plugins: {
      legend: {
        position: 'top',
        paddingBelowLegends: true,
      },
    },

    scales: {
      x: {
        display: true,
        grid: {
          display: false,
        },
      },
      y: {
        display: true,
        grid: {
          display: true,

          color: function (context) {
            if (context?.tick?.value === 0) {
              return 'rgb(224, 224, 224)';
            }
          },

        },
      },
    },
    maintainAspectRatio: false,
  };
  // * labels
  const monthsNames = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August ', 'September ', 'October ', 'November ', 'December'];




  // * Data
  const [soldHoursState, setsoldHoursState] = useState(null);
  const [soldVsWorkHoursState, setsoldVsWorkHoursState] = useState(null);
  const [topWorstPerformanceState, settopWorstPerformanceState] = useState(null);
  const [topBestPerformanceState, settopBestPerformanceState] = useState(null);
  const [component, setComponent] = useState(null);

  // Saber personas a cargo de personaLogin
  useEffect(() => {
    getEstructuraPersonalAPI(personLogin.id);
  }, [listMyGroup]);

  useEffect(() => {
    mostrarAllUserAPI();
  }, []);

  useEffect(() => {

    getEstructuraPersonalAPI(personLogin.id);
    if (!userSelected) {
      mostrarMisionIncluyendoMisionesHeredadasAPI(personLogin.id)
    }
    else {
      mostrarMisionIncluyendoMisionesHeredadasAPI(userSelected)
    }
  }, [userSelected, listMyGroup])



  //! Peticiones
  // Sold hours / working hours
  useEffect(() => {
    console.log("🚀 ~ file: Performance.js:197 ~ Performance ~ bestWorstPerformance:", bestWorstPerformance)
    if (userSelected && intermediateDates) {

      if (!datosConsulta.user) {
        dispatch(guardarDatos(userSelected, { datesSelect: [dayjs().subtract(2, 'month'), dayjs()], yearsSelect: intermediateDates, misionSelect: misionSelected }));
        // dispatch(guardarDatos(userSelected, { datesSelect: [dayjs(), dayjs()], yearsSelect: intermediateDates, misionSelect: misionSelected }));
        dispatch(mostrarPerformanceAPIAction(userSelected, { dateSelect: intermediateDates, misionSelect: misionSelected }));

      }
      else if
        ((userSelected !== datosConsulta.user) ||
        (fechaInicial && fechaInicial?.year() < parseInt(datosConsulta.yearsSelect[0]) ) ||
        (fechaFinal && fechaFinal?.year() > parseInt(datosConsulta.yearsSelect[datosConsulta.yearsSelect.length - 1])) ||
        (datosConsulta.mision !== misionSelected) 
 
        ) {
        dispatch(guardarDatos(userSelected, { datesSelect: [fechaInicial, fechaFinal], yearsSelect: intermediateDates, misionSelect: misionSelected }));
        dispatch(mostrarPerformanceAPIAction(userSelected, { dateSelect: intermediateDates, misionSelect: misionSelected }));
      }
    }
  }, [userSelected, intermediateDates, misionSelected, datosConsulta]);



  // ! Establecemos fecha segun la consulta (1º render: fechaFin = hoy, fechaInicio = hoy - 13 meses)
  useEffect(() => {
    datosConsulta && (setFechaInicial(datosConsulta.datesSelect[0]), setFechaFinal(datosConsulta.datesSelect[1]))
  }, [datosConsulta])


  //! Calculo fechas intermedias


  useEffect(() => {

    if (fechaInicial && fechaFinal

    ) {
      function getIntermediateDates(startDate, endDate) {
        const dates = [];
        let currentDate = dayjs(startDate).startOf('year');
        const lastDate = dayjs(endDate).endOf('year');

        while (currentDate.isSame(lastDate, 'year') || currentDate.isBefore(lastDate, 'year')) {
          dates.push(currentDate.format('YYYY'));
          currentDate = currentDate.add(1, 'year');
        }

        return dates;
      }

      setIntermediateDates(getIntermediateDates(fechaInicial, fechaFinal));
    }
    else {
      // setIntermediateDates([`${dayjs().year() - 1}`, `${dayjs().year()}`])
      setIntermediateDates([`${dayjs().year()}`])
    }
  }, [fechaFinal, fechaInicial]);






  // ! Creacion tabla y graficos
  useEffect(() => {
    // console.log("🚀 ~ file: Performance.js:337 ~ solVsWorkInfo ~ fechaInicialMonth:", fechaInicial)
    if (soldVsWorkHours?.length > 0 || bestWorstPerformance?.length > 0 && fechaInicial && fechaFinal) {

      // // ! Tabla
      // const rows = soldHoursBrakeDown.map((obj, objIndex) => {
      //   let result = {
      //     agresso: obj["AGRESSO CODE"],
      //     quoteCode: obj["BUDGET CODE"],
      //     fte: obj["QUANTITY"],
      //     unitHours: parseFloat(obj["RATE"].replace(",", ".")),
      //     status: parseFloat(obj["STATUS"].replace(",", ".")),
      //     totalWorkloadValue: parseFloat(obj["TOTAL WORKLOAD VALUED (h)"].replace(",", ".")),
      //     typeOfWorkload: obj["TYPE OF WORKLOAD"],
      //   };
      //   return result;
      // });


      // const colums = [
      //   { Header: "Agresso Code", accessor: "agresso" },
      //   { Header: "Quote Code", accessor: "quoteCode" },
      //   {
      //     Header: "FTE/QUANTITY", accessor: "fte", Footer: info => {
      //       const total = useMemo(
      //         () =>
      //           info.rows.reduce((sum, row) => row.values.fte + sum, 0),
      //         [info.rows]
      //       )

      //       return <>Total: {total}</>
      //     },
      //   },
      //   {
      //     Header: "Unit Hours", accessor: "unitHours",
      //     Footer: info => {
      //       const total = useMemo(
      //         () =>
      //           info.rows.reduce((sum, row) => row.values.unitHours + sum, 0).toFixed(2),
      //         [info.rows]
      //       )

      //       return <>Total: {total}</>
      //     },
      //   },
      //   {
      //     Header: "Status", accessor: "status",
      //     Footer: info => {
      //       const total = useMemo(
      //         () =>
      //           info.rows.reduce((sum, row) => row.values.status + sum, 0).toFixed(2),
      //         [info.rows]
      //       )

      //       return <>Total: {total}</>
      //     },
      //   },
      //   {
      //     Header: "Total Workload Value", accessor: "totalWorkloadValue",
      //     Footer: info => {
      //       const total = useMemo(
      //         () =>
      //           info.rows.reduce((sum, row) => row.values.totalWorkloadValue + sum, 0).toFixed(2),
      //         [info.rows]
      //       )

      //       return <>Total: {total}</>
      //     },
      //   },
      //   {
      //     Header: "Type of Workload", accessor: "typeOfWorkload",

      //   },
      // ];

      // setTableRows(rows);
      // setTableColumnss(colums);


      // ! Graficos
      const dataSetMaker = (label, data, color) => {
        return {
          label: label,
          data: data,
          backgroundColor: `${color}, 0.5)`,
          borderColor: `${color})`,
          borderWidth: 3,
          borderRadius: {
            topLeft: 50,
            topRight: 50,
            bottomLeft: 50,
            bottomRight: 50,
          },
          borderSkipped: false,
        };
      }


      //  ! Render de graficas
      // SoldvsWork
      let solVsWorkInfo = soldVsWorkHours.reduce((acc, entry) => {
        const entryMonth = parseInt(entry["MONTH"]) - 1;
        const entryYear = parseInt(entry["YEAR"]);

        const currentDate = dayjs().startOf('month');
        const fechaInicialMonth = fechaInicial.month();

        const fechaInicialYear = fechaInicial.year();
        const fechaFinalMonth = fechaFinal.month();
        const fechaFinalYear = fechaFinal.year();

        if (
          (entryYear < currentDate.year() ||
            (entryYear === currentDate.year() && entryMonth < currentDate.month())) &&
          (entryYear > fechaInicialYear ||
            (entryYear === fechaInicialYear && entryMonth >= fechaInicialMonth)) &&
          (entryYear < fechaFinalYear ||
            (entryYear === fechaFinalYear && entryMonth <= fechaFinalMonth))
        ) {
          acc.soldHours.push(entry["TOTAL_SOLD_HOURS"]);
          acc.workHours.push(entry["TOTAL_WORKING_HOURS"]);
          const monthIndex = entryMonth;
          const monthName = `${monthsNames[monthIndex]} - ${entry["YEAR"].substring(2, 4)}`;
          acc.months.push(monthName);
        }
        return acc;
      }, { soldHours: [], workHours: [], months: [] });

      setsoldVsWorkHoursState(
        {
          labels: solVsWorkInfo.months,
          datasets: [dataSetMaker('Sold Hours', solVsWorkInfo.soldHours, 'rgb(0, 56, 99'),
          dataSetMaker('Working Hours', solVsWorkInfo.workHours, 'rgb(155, 205, 101')],
        }
      );

      setsoldHoursState(
        {
          labels: solVsWorkInfo.months,
          datasets: [dataSetMaker('Sold Hours', solVsWorkInfo.soldHours, 'rgb(0, 56, 99')],
        }
      );

      //  topWorstContracts
      let topWorstContracts = [...new Set(bestWorstPerformance?.map(obj => obj["AGRESSO CODE"]))];

      let contractsInfo = topWorstContracts.map(contract => {
        return bestWorstPerformance.reduce((acc, entry) => {
          const entryMonth = parseInt(entry["MONTH"]) - 1;
          const entryYear = parseInt(entry["YEAR"]);
  
          const currentDate = dayjs().startOf('month');
          const fechaInicialMonth = fechaInicial.month();
  
          const fechaInicialYear = fechaInicial.year();
          const fechaFinalMonth = fechaFinal.month();
          const fechaFinalYear = fechaFinal.year();
          if (entry["AGRESSO CODE"] === contract && parseInt(entry["MONTH"]) - 1 < dayjs().month()) {
                    if (
          (entryYear < currentDate.year() ||
            (entryYear === currentDate.year() && entryMonth < currentDate.month())) &&
          (entryYear > fechaInicialYear ||
            (entryYear === fechaInicialYear && entryMonth >= fechaInicialMonth)) &&
          (entryYear < fechaFinalYear ||
            (entryYear === fechaFinalYear && entryMonth <= fechaFinalMonth))
        ) {

              const monthIndex = parseInt(entry["MONTH"]) - 1;
              const monthName = monthsNames[monthIndex];
              acc.month.push(monthName);
              acc.contract.push(entry["AGRESSO CODE"]);
              let soldVsWork = entry["TOTAL_SOLD_HOURS"] / entry["TOTAL_WORKING_HOURS"];
              acc.data.push(isFinite(soldVsWork) ? soldVsWork * 100 : 0);
            }
          }
          return acc;
        }, { month: [], contract: [], data: [] });
      });


      let sumDataWorstBestPerformance = contractsInfo.map(obj => obj.data.reduce((acc, entry) => ({ sum: acc.sum + entry }), { sum: 0 }).sum / obj.data.length);

      const { best, worst } = sumDataWorstBestPerformance.reduce(
        (acc, data, i) => {
          const { best, worst } = acc;
          if (data >= 100) {
            best.data.push(data);
            best.contracts.push(topWorstContracts[i]);
          } else {
            worst.data.push(data);
            worst.contracts.push(topWorstContracts[i]);
          }
          return acc;
        },
        {
          best: { contracts: [], data: [] },
          worst: { contracts: [], data: [] }
        }
      );

      settopWorstPerformanceState({
        labels: worst.contracts,
        datasets: [dataSetMaker('Top Worst Performance (<100%)', worst.data, 'rgb(0, 56, 99')]
      })

      settopBestPerformanceState({
        labels: best.contracts,
        datasets: [dataSetMaker('Top Worst Performance (>100%)', best.data, 'rgb(155, 205, 101')]
      })
    }
  }, [soldHoursBrakeDown, soldVsWorkHours, bestWorstPerformance, fechaInicial, fechaFinal]);


  // ! Vista graficos

  const [chartOpen, setChartOpen] = useState(null);
  const chartOpenObject = {
    soldVsWorkHours: "Sold Hours VS Work Hours",
    topWorst: "Top Worst Performance",
    topBest: "Top Best Performance",
    soldHurs: "Sold Hours"
  }


  // ! Renderizado de tabla
  useEffect(() => {
    if (tableRows && tableColumns) {
      setTable(<Table rowsProp={tableRows} columnsProp={tableColumns}
        groups={["agresso", "quoteCode"]} />)
    }
  }, [tableRows, tableColumns])


  return (
    <>
      <FusePageCarded

        content={
          <Box sx={{ width: '100%' }}>

            <Filters
              fRender={fRender}
              showFilters={showFilters}
              fechaInicial={fechaInicial} setFechaInicial={setFechaInicial} fechaFinal={fechaFinal} setFechaFinal={setFechaFinal} usersList={usersList} userSelected={userSelected} setUserSelected={setUserSelected} misionSelected={misionSelected} setMisionSelected={setMisionSelected} page = {"Performance"}
            />

            <div className="row justify-content-end position-absolute end-0" style={{ zIndex: 200 }}>
              <div className='hamburguer-container w-auto'>
                <input type="checkbox" id="checkbox3" className="checkbox3 visuallyHidden" />
                <label htmlFor="checkbox3" onClick={() => { setShowFilters(filter => !filter); setFRender(f => f + 1) }}>
                  <div className="hamburger hamburger3">
                    <span className="bar bar1"></span>
                    <span className="bar bar2"></span>
                    <span className="bar bar3"></span>
                    <span className="bar bar4"></span>
                  </div>
                </label>
              </div>
            </div>

            {
              !loading ?
                <>
                  <div className="row p-3" style={{ height: "80vh" }}>
                    <div className="col-6 h-50">
                      {
                        soldVsWorkHoursState && (

                          <Bar options={options} data={soldVsWorkHoursState} />
                        )
                      }
                    </div>

                    {
                      soldHoursState && (

                        <div className="col-6 h-50" onClick={() => setShowTable(table => !table)}>
                          {
                            (
                              !showTable ? "Ver Tabla" : "Ver Gráfica"
                            )
                          }
                          {
                            showTable ?
                              <div className="h-100 overflow-x-scroll">
                                {table && table}
                              </div>
                              :
                              <div className="p-3 h-100">
                                {
                                  soldHoursState && (
                                    <Line options={options} data={soldHoursState} />
                                  )

                                }
                              </div>
                          }
                        </div>


                      )
                    }

                    <div className="col-6">
                      {
                        topWorstPerformanceState && (

                          <Bar
                            options={{
                              ...options, indexAxis: 'y',
                              scales: {
                                x: {
                                  ...options.scales.x,
                                  ticks: {
                                    callback: function (value) {
                                      return value + '%'; // Añade el signo de porcentaje (%)
                                    },
                                  },
                                },
                                y: { ...options.scales.y }


                              }
                            }}
                            data={topWorstPerformanceState}
                          />
                        )
                      }
                    </div>
                    <div className="col-6" >
                      {
                        topBestPerformanceState && (
                          <Bar
                            options={{
                              ...options, indexAxis: 'y',
                              scales: {
                                x: {
                                  ...options.scales.x,
                                  ticks: {
                                    callback: function (value) {
                                      return value + '%'; // Añade el signo de porcentaje (%)
                                    },
                                  },
                                },
                                y: { ...options.scales.y }


                              }
                            }}
                            data={topBestPerformanceState} />

                        )
                      }
                    </div>

                  </div>


                </>
                :

                <div style={{
                  display: "flex",
                  flexDirection: "column",
                  alignItems: "center",
                  position: "absolute",
                  top: "50%",
                  width: "100%"
                }}>

                  <Typography className="text-13 sm:text-20 mb-16" color="textSecondary">
                    Loading...
                  </Typography>
                  <LinearProgress className="w-192 sm:w-320 max-w-full rounded-2" color="secondary" />
                </div>

            }

          </Box>
        }
      />
    </>
  )
}

