//**********************IMPORTACIONES****************************

import { React, useEffect, useState, useRef } from 'react'

//DataGrid importaciones
import { DataGrid } from '@mui/x-data-grid';
import DeleteIcon from "@mui/icons-material/Delete";
import EditIcon from '@mui/icons-material/Edit';
import IconButton from "@mui/material/IconButton";
import FusePageCarded from '@fuse/core/FusePageCarded';
import AddCircleIcon from '@mui/icons-material/AddCircle';
import FormatListBulletedIcon from '@mui/icons-material/FormatListBulleted';
import MoreVertIcon from '@mui/icons-material/MoreVert';
import Tooltip from '@mui/material/Tooltip';
import { useNavigate } from "react-router-dom";
import Tabs from '@mui/material/Tabs';
import Tab from '@mui/material/Tab';
import Box from '@mui/material/Box';
import Divider from '@mui/material/Divider';
import Grid from '@mui/material/Grid';
import TextField from '@mui/material/TextField';

import Card from '@mui/material/Card';
import CardContent from '@mui/material/CardContent';
import CardMedia from '@mui/material/CardMedia';
import Typography from '@mui/material/Typography';
import Autocomplete from '@mui/material/Autocomplete';
import SkipPreviousIcon from '@mui/icons-material/SkipPrevious';
import PlayArrowIcon from '@mui/icons-material/PlayArrow';
import SkipNextIcon from '@mui/icons-material/SkipNext';
import Avatar from '@mui/material/Avatar';
import List from '@mui/material/List';
import ListItem from '@mui/material/ListItem';
import ListItemButton from '@mui/material/ListItemButton';
import ListItemIcon from '@mui/material/ListItemIcon';
import ListItemText from '@mui/material/ListItemText';
import StarIcon from '@mui/icons-material/Star';
import Button from '@mui/material/Button';
import ListItemAvatar from '@mui/material/ListItemAvatar';
import FolderIcon from '@mui/icons-material/Folder';
import Select, { SelectChangeEvent } from '@mui/material/Select';
import InputLabel from '@mui/material/InputLabel';

import Menu from '@mui/material/Menu';
import MenuItem from '@mui/material/MenuItem';
import ArchiveIcon from '@mui/icons-material/Archive';
import FileCopyIcon from '@mui/icons-material/FileCopy';
import MoreHorizIcon from '@mui/icons-material/MoreHoriz';
import KeyboardArrowDownIcon from '@mui/icons-material/KeyboardArrowDown';
import SearchIcon from '@mui/icons-material/Search';

import Dialog from '@mui/material/Dialog';
import DialogActions from '@mui/material/DialogActions';
import DialogContent from '@mui/material/DialogContent';
import DialogTitle from '@mui/material/DialogTitle';
import { makeStyles } from "@material-ui/core/styles";
import TabContext from '@mui/lab/TabContext';
import TabList from '@mui/lab/TabList';
import TabPanel from '@mui/lab/TabPanel';
import Alert from '@mui/material/Alert';
import AlertTitle from '@mui/material/AlertTitle';
import { useTheme, styled } from '@mui/material/styles';

import ModalSolicitarPersonal from './modals/solicitudPersonal.js'
import ModalAnadirPersonal from './modals/anadirPersonal'
import { showMessage } from 'app/store/fuse/messageSlice'
import AssignarPersonas from '../../../Gestion/SubMision/modals/assignedPeople.js'


//Redux importaciones
import { useDispatch, useSelector } from 'react-redux'

import { cambiarVisibilidadModalAssignedPeopleAPIAction } from '../../../Gestion/SubMision/store/actions'

import {
    getPermisosSesionActualAPIAction,
    getSesionActualAPIAction,
    mostrarUserAPIAction
} from '../../../Managment/Users/store/actions'

import {
    verModalSolicitudPersonalAPIAction,
    verModalAnadirPersonalAPIAction,
    getResponsablesMisionAsociadaSubMisionAPIAction,
    setMemberSelectAPIAction,
    setSubMisionSelectAPIAction
} from '../store/actions'

import {
    getUserAgressoAPIAction,
    insertarNewUserAPI,
    obtenerContratosUserAPIAction,
    getUsuarioResponsableMisionAPIAction
} from '../../../Managment/Users/store/actions'

import {
    obtenerUserAppAPIAction,
} from '../../../Gestion/ContratoServicio/store/actions'

import {
    getTeamAPIAction,
    deleteContractUserAPIAction,
    putPersonalAsignadoContratoAPIAction
} from '../../../Gestion/SubMision/store/actions'

//Modales importaciones
import { getCookie } from 'app/js/generalFunctions'

const useStyles = makeStyles({

    customDialogTitle: {
        backgroundColor: 'rgb(37, 47, 62)',
        color: 'rgb(255, 255, 255)',
        marginBottom: '2em'
    }

});

//**********************END_IMPORTACIONES ***********************/
import TableModules from '../../../tables/TableModules'

const vectRepeticion = [
    'Item 1',
    'Item 2',
    'Item 3',
    'Item 4'
]

export default function MiPersonal() {

    const columnasDataTable = [
        { Header: "Type", accessor: "aplication_user_type", sortable: true, type: 'list' },
        { Header: "Code", accessor: "aplication_user_id_code", sortable: true, type: 'string' },
        { Header: "Name", accessor: "aplication_user_id_name", sortable: true, type: 'string' }
    ]


    const theme = useTheme();

    const [value, setValue] = useState('1');

    const [viewMiPersonal, setViewDivision] = useState(true)
    const [viewMiMaterial, setViewSubDivision] = useState(true)
    const [userListSelected, setUserListSelected] = useState('')
    const [userExportAgresso, setUserExportAgresso] = useState('');
    const [subMisionSelected, setMisionActual] = useState('');
    const [nameSubmisionSearch, setNameSubmisionSearch] = useState('');
    const [existenDiscrepancias, setExistenDiscrepancias] = useState(false);

    const [disabledNewPeople, setDisabledNewPeople] = useState(true)
    const [disabledEditPeople, setDisabledEditPeople] = useState(true)
    const [disabledRemovePeople, setDisabledRemovePeople] = useState(true)

    const [visibilidadDialogoConfirmacion, setVisibilidadDialogoConfirmacion] = useState(false)

    const [varMenu, setVarMenu] = useState(null);
    const detallesAbierto = Boolean(varMenu);
    const menuClick = (event) => {
        setVarMenu(event.currentTarget);
    };
    const menuClose = () => {
        setVarMenu(null);
    };

    const navigate = useNavigate();
    const classes = useStyles();

    //obtener el state de Redux
    const loading = useSelector(state => state.fuse.peopleManagementComponente.loading)
    const valorTab = useSelector(state => state.fuse.peopleManagementComponente.valorTabPeople)
    const personLoginPermisos = useSelector(state => state.fuse.userComponente.personPermisos)
    const personLogin = useSelector(state => state.fuse.userComponente.person)
    const usersListAPI = useSelector(state => state.fuse.userComponente.usersListAPI)
    const verModalAnadirPersonal = useSelector(state => state.fuse.peopleManagementComponente.verModalAnadirPersonal)
    const userAgresso = useSelector(state => state.fuse.userComponente.userAgresso)
    const listTeams = useSelector(state => state.fuse.subMisionComponent.listTeams)
    const listUserApp = useSelector(state => state.fuse.contratoComponente.listUserApp)
    const contractUserList = useSelector(state => state.fuse.userComponente.contractUserListAPI)
    const visibilidadModalAssignedPeople = useSelector(state => state.fuse.subMisionComponent.visibilidadModalAssignedPeople)
    const contractUserListAPIRespaldo = useSelector(state => state.fuse.userComponente.contractUserListAPIRespaldo)
    const deleteUserSubMision = useSelector(state => state.fuse.subMisionComponent.deleteUserSubMision)

    const listResponsablesSubMision = useSelector(state => state.fuse.peopleManagementComponente.listResponsablesSubMision)


    //creamos una función para hacer uso de Actions
    const dispatch = useDispatch()
    const cambiarValorTab = (valorTab) => dispatch(cambiarValorTabPeopleAction(valorTab))
    const mostrarUserAPI = () => dispatch(mostrarUserAPIAction())
    const verModalSolicitudPersonalAPI = (arg) => dispatch(verModalSolicitudPersonalAPIAction(arg))
    const verModalAnadirPersonalAPI = (arg) => dispatch(verModalAnadirPersonalAPIAction(arg))
    const getTeamAPI = (arg) => dispatch(getTeamAPIAction(arg))
    const deleteContractUserAPI = (arg) => dispatch(deleteContractUserAPIAction(arg))
    const getUserAgressoAPI = (nAgresso) => dispatch(getUserAgressoAPIAction(nAgresso))
    const obtenerUserAppAPI = (datos) => dispatch(obtenerUserAppAPIAction(datos))
    const obtenerContratosUserAPI = (datos, modo) => dispatch(obtenerContratosUserAPIAction(datos, modo))
    const cambiarVisibilidadModalAssignedPeopleAPI = (arg, modoApertura) => dispatch(cambiarVisibilidadModalAssignedPeopleAPIAction(arg, modoApertura))
    const putPersonalAsignadoContratoAPI = (id, datos) => dispatch(putPersonalAsignadoContratoAPIAction(id, datos))
    const getUsuarioResponsableMisionAPI = (datos) => dispatch(getUsuarioResponsableMisionAPIAction(datos))
    const getResponsablesMisionAsociadaSubMisionAPI = (idSubMision) => dispatch(getResponsablesMisionAsociadaSubMisionAPIAction(idSubMision))
    const setMemberSelectAPI = (idMember) => dispatch(setMemberSelectAPIAction(idMember))
    const setSubMisionSelectAPI = (subMision) => dispatch(setSubMisionSelectAPIAction(subMision))

    const [anchorEl, setAnchorEl] = useState(null);
    const open = Boolean(anchorEl);
    const handleClick = (event) => {
        setAnchorEl(event.currentTarget);
    };
    const handleClose = () => {
        setAnchorEl(null);
    };

    useEffect(() => {
        //PRIMERO DEBEMOS OBTENER SI EL USUARIO ES RESPONSABLE DE ALGUNA MISION
        getUsuarioResponsableMisionAPI(personLogin.id)
        //SI NO ES RESPONSABLE LANZAMOS ESTA SOLICITUD
        //obtenerContratosUserAPI(personLogin.id, "1")
    }, [personLogin])

    useEffect(() => {

        if (personLoginPermisos.length > 0) {

            if (personLoginPermisos.find((item) => item['name'] == "Can view sub mision") == undefined) {
                navigate('/')
            }

            if (personLoginPermisos.find((item) => item['name'] == "Can add sub mision") == undefined) {
                setDisabledNewPeople(false)
            }

            if (personLoginPermisos.find((item) => item['name'] == "Can change sub mision") == undefined) {
                setDisabledEditPeople(false)
            }

            if (personLoginPermisos.find((item) => item['name'] == "Can delete sub mision") == undefined) {
                setDisabledRemovePeople(false)
            }

        }

    }, [personLoginPermisos])

    //funcion para buscar el personal en una sub mision
    function searchNewMision() {

        if (subMisionSelected != '') {
            setSubMisionSelectAPI(subMisionSelected)
            setNameSubmisionSearch(subMisionSelected.code)
            getTeamAPI(subMisionSelected.id)
            getResponsablesMisionAsociadaSubMisionAPI(subMisionSelected.id)
        }

    }

    //use effect que actua cuando se elimina un miembro de una submision
    useEffect(() => {

        if (deleteUserSubMision != '') {
            getTeamAPI(deleteUserSubMision)
        }

    }, [deleteUserSubMision])

    useEffect(() => {

        if (contractUserList != undefined && contractUserList.length != 0) {
            if (nameSubmisionSearch != contractUserList[0].name) {
                setSubMisionSelectAPI(contractUserList[0])
                setNameSubmisionSearch(contractUserList[0].code)
                setMisionActual(contractUserList[0])
                getTeamAPI(contractUserList[0].id)
                getResponsablesMisionAsociadaSubMisionAPI(contractUserList[0].id)
            }
            else {
                setMisionActual(contractUserList[0])
            }

        }

    }, [contractUserList])

    useEffect(() => {

        if (visibilidadModalAssignedPeople == false) {
            searchNewMision()
        }

    }, [visibilidadModalAssignedPeople])

    useEffect(() => {

        if (listTeams != undefined) {
            if (listTeams.length != 0) {
                setUserListSelected(listTeams[0])
                obtenerUserAppAPI(listTeams[0].id)
                getUserAgressoAPI(listTeams[0]['IDRes'])
            }
            else {
                setUserListSelected({})
            }
        }

    }, [listTeams])

    /*useEffect(() => {
        setExistenDiscrepancias(false)
        let existenDiscrepanciasLet = false
        if (listTeams != null && listResponsablesSubMision != null && listTeams != undefined && listResponsablesSubMision != undefined && listTeams.length != 0 && listResponsablesSubMision.length != 0) {
            //COMPARACION DE AMBOS GRUPOS DE PERSONAS
            for(let itemTeams in listTeams){
                for(let itemResponsables in listResponsablesSubMision){
                    if(listTeams[itemTeams]['id'] == listResponsablesSubMision[itemResponsables]['id']){
                        existenDiscrepanciasLet = true
                    }
                }
            }
        }

        setExistenDiscrepancias(existenDiscrepanciasLet)

    }, [listTeams, listResponsablesSubMision])*/

    useEffect(() => {

        if (userAgresso.length != undefined) {
            //setUserExportAgresso(JSON.parse(userAgresso)['data'][0])
        }

    }, [userAgresso])


    function selectUser(user) {
        setUserListSelected(user)
        getUserAgressoAPI(user['IDRes'])
        obtenerUserAppAPI(user['id'])
        obtenerContratosUserAPI(user.id, "2")

        setMemberSelectAPI(user['id'])
    }

    function funcionEliminaPersonaTeam() {
        deleteContractUserAPI({
            user_id: userListSelected.id,
            subMision_id: subMisionSelected.id
        })
    }

    function cambiarRolEmpleadoGrupo() {

        menuClose()

        if (userListSelected.rol_employee == "temporary") {

            let estadoContrato = contractUserListAPIRespaldo.filter(registro => registro.rol_employee == "permanent" && registro.id != subMisionSelected.id)

            if (estadoContrato.length != 0) {
                dispatch(
                    showMessage({
                        message: "The user is already added in another sub mission as permanent.",
                        variant: "error"
                    })
                )
            }
            else {
                let idItem = contractUserListAPIRespaldo.filter(registro => registro.user_id == userListSelected.id && registro.id == subMisionSelected.id)[0]
                putPersonalAsignadoContratoAPI(idItem.id, {
                    user_id: userListSelected.id,
                    subMision_id: subMisionSelected.id,
                    rol_employee: "permanent"
                })
            }
        }
        else {
            //consulta
            let idItem2 = contractUserListAPIRespaldo.filter(registro => registro.user_id == userListSelected.id && registro.id == subMisionSelected.id)[0]
            putPersonalAsignadoContratoAPI(idItem2.id, {
                user_id: userListSelected.id,
                subMision_id: subMisionSelected.id,
                rol_employee: "temporary"
            })
        }
    }

    const handleChange = (event, newValue) => {
        setValue(newValue);
    };

    return (
        <>
            <div style={valorTab == 'miPersonal' ? { display: "block" } : { display: "none" }} >

                {/*OPCIONES*/}

                <Grid
                    container
                    direction="row"
                    justifyContent="space-between"
                    alignItems="center"
                >
                    <Grid item justifyContent="flex-start">
                        <div style={{ display: "inline", float: "left", position: "relative", marginLeft: "20px" }} >

                            <InputLabel id="demo-simple-select-label">Sub Mission</InputLabel>
                            <Select
                                labelId="label-select-subdivision"
                                id="subMision"
                                label="Sub Mission"
                                sx={{ width: '37ch' }}
                                onChange={e => setMisionActual(e.target.value)}
                                value={subMisionSelected}

                            >

                                {contractUserList.map((elemento) => (

                                    <MenuItem value={elemento}> {elemento.code} {elemento.name} </MenuItem>
                                ))}

                            </Select>

                            <Button style={{ marginLeft: "20px" }} variant="contained" onClick={() => { searchNewMision(); }}> <SearchIcon /> </Button>

                            {/*<div className="radialbar" style={existenDiscrepancias == false ? {display: "none" } : { display: "inline" }}>
                                <Alert severity="error">
                                <AlertTitle>There are employees who are added to this submission as managers and as members.</AlertTitle>
                                </Alert>
                            </div>*/}


                        </div>


                    </Grid>

                    <Grid item justifyContent="flex-end">
                        <div style={{ display: "inline", float: "right", position: "relative", marginRight: "20px" }} >
                            <Button variant="contained" style={disabledNewPeople == true ? { display: "inline" } : { display: "none" }} onClick={() => { verModalSolicitudPersonalAPI(true); }}>Request Staff</Button>
                            <Button variant="contained" style={disabledNewPeople == true ? { display: "inline" } : { display: "none" }} onClick={() => { verModalAnadirPersonalAPI(true); }}>Offer Staff</Button>
                            <Button variant="contained" style={disabledNewPeople == true ? { display: "inline" } : { display: "none" }} onClick={() => { cambiarVisibilidadModalAssignedPeopleAPI(true, 'miEquipo'); }}>Add person to my mision</Button>
                        </div>

                    </Grid>

                </Grid>

                <Grid container spacing={2} columns={16}>
                    <Grid item xs={5} style={{ margin: '0px' }}>
                        <div style={{ width: '100%', textAlign: 'center' }}>
                            <h2>{nameSubmisionSearch}:</h2>
                            <Divider style={{ width: '100%' }} />
                        </div>

                        {/*TARJETA*/}

                        <Box sx={{ width: '100%', typography: 'body1' }}>
                            <TabContext value={value}>
                                <Box sx={{ width: '100%', bgcolor: 'background.paper' }}>
                                    <TabList onChange={handleChange} centered>
                                        <Tab label="Members" value="1" />
                                        <Tab label="Manager" value="2" />
                                    </TabList>
                                </Box>
                                <TabPanel value="1">
                                    {/*MOSTRAR LA LISTA DE INTEGRANTES DE LA SUB MISION */}
                                    {listTeams.map((user) => {
                                        return (
                                            <>
                                                <Card sx={{ marginTop: '5px' }} onClick={() => selectUser(user)}>

                                                    <Box style={user['rol_employee'] == "permanent" ? userListSelected['id'] == user['id'] ? { backgroundColor: theme.palette.text.primary, border: "3px solid #000000", borderRadius: "20px" } : { backgroundColor: theme.palette.text.primary } : userListSelected['id'] == user['id'] ? { backgroundColor: theme.palette.secondary.main, border: "3px solid #000000", borderRadius: "20px" } : { backgroundColor: theme.palette.secondary.main }}>
                                                        <CardContent>

                                                            <Grid container spacing={2} columns={11}>
                                                                <Grid item xs={8}>
                                                                    <Typography component="div" variant="subtitle1" color="#FFFFFF">
                                                                        {user['first_name'] + " " + user['last_name']}
                                                                    </Typography>
                                                                    <Typography component="div" variant="caption" color="#FFFFFF">
                                                                        {user['job_employee']}
                                                                    </Typography>
                                                                </Grid>
                                                                <Grid item xs={1}>
                                                                    <Tooltip title="Edit" placement="top" style={disabledEditPeople == true && disabledRemovePeople == true ? { display: "block" } : { display: "none" }}>
                                                                        <Button
                                                                            id="basic-button"
                                                                            aria-controls={detallesAbierto ? 'basic-menu' : undefined}
                                                                            aria-haspopup="true"
                                                                            aria-expanded={detallesAbierto ? 'true' : undefined}
                                                                            onClick={menuClick}
                                                                        >
                                                                            {/*ICONO DEL BOTON */}
                                                                            <MoreVertIcon />
                                                                            {/*ICONO DEL BOTON */}
                                                                        </Button>
                                                                    </Tooltip>
                                                                </Grid>
                                                            </Grid>
                                                        </CardContent>
                                                    </Box>
                                                </Card>
                                                <Menu
                                                    id="basic-menu"
                                                    anchorEl={varMenu}
                                                    open={detallesAbierto}
                                                    onClose={menuClose}
                                                    MenuListProps={{
                                                        'aria-labelledby': 'basic-button',
                                                    }}
                                                >
                                                    <MenuItem
                                                        onClick={() => {
                                                            menuClose()
                                                            cambiarVisibilidadModalAssignedPeopleAPI(true, 'miEquipoEdit');

                                                        }}>Edit User</MenuItem>
                                                    <MenuItem style={disabledRemovePeople == true ? { display: "block" } : { display: "none" }}
                                                        onClick={() => {
                                                            menuClose()
                                                            if (personLogin.id == userListSelected.id) {
                                                                dispatch(
                                                                    showMessage({
                                                                        message: "It is not possible to unsubscribe your profile",
                                                                        variant: "error"
                                                                    })
                                                                )
                                                            }
                                                            else {
                                                                setVisibilidadDialogoConfirmacion(true)
                                                            }


                                                        }}>Remove from group</MenuItem>
                                                </Menu>
                                            </>
                                        );
                                    })}

                                    {/*FIN MOSTRAR LA LISTA DE INTEGRANTES DE LA SUB MISION */}
                                </TabPanel>
                                <TabPanel value="2">
                                    {/*MOSTRAR LA LISTA DE RESPONSABLES DE LA SUB MISION */}
                                    {listResponsablesSubMision.map((user) => {
                                        return (
                                            <>
                                                <Card sx={{ marginTop: '5px' }} onClick={() => selectUser(user)}>
                                                    <Box style={userListSelected['id'] == user['id'] ? { border: "3px solid #003EFF", backgroundColor: "#000000", borderRadius: "20px" } : { backgroundColor: "#000000" }}>
                                                        <CardContent>
                                                            <Grid container spacing={2} columns={11}>
                                                                <Grid item xs={9}>
                                                                    <Typography component="div" variant="subtitle1" color="#FFFFFF">
                                                                        {user['first_name'] + " " + user['last_name']}
                                                                    </Typography>
                                                                </Grid>
                                                            </Grid>
                                                        </CardContent>
                                                    </Box>
                                                </Card>
                                            </>
                                        );
                                    })}
                                    {/*FIN MOSTRAR LA LISTA DE RESPONSABLES DE LA SUB MISION */}
                                </TabPanel>
                            </TabContext>
                        </Box>

                    </Grid>

                    <Grid item xs={10} rowSpacing={20} alignItems="center">
                        {/*DETALLES EMPLEADO*/}
                        <h3 style={{ fontWeight: '600' }}>Employee details:</h3>
                        <Grid container spacing={2} columns={16} style={{ marginTop: '3px' }}>
                            <Grid item xs={8}>
                                <p>Name: {userListSelected != '' && userListSelected['first_name'] != undefined ? userListSelected['first_name'] + " " + userListSelected['last_name'] : ""}</p>
                            </Grid>

                            <Grid item xs={8}>
                                <p>Role: {userListSelected != undefined ? userListSelected['rolUser'] : ""}</p>
                            </Grid>

                            <Grid item xs={8}>
                                <p>Email: {userListSelected != undefined ? userListSelected['email'] : ""}</p>
                            </Grid>

                            <Grid item xs={8}>
                                <p>Phone: {userListSelected != undefined ? userListSelected['phone'] : ""}</p>
                            </Grid>
                            {/*</Grid>
                        FIN DETALLES EMPLEADO*/}
                            {/*DETALLES EMPLEADO
                        <Grid container spacing={2} columns={16} style={{ marginTop: '3px' }}>*/}
                            <Grid item xs={8}>
                                <p>Level1_VT: {userExportAgresso != undefined && userExportAgresso['Nivel1_VT'] != undefined ? userExportAgresso['Nivel1_VT'] : ""}</p>
                            </Grid>

                            <Grid item xs={8}>
                                <p>Level2_VT: {userExportAgresso != undefined && userExportAgresso['Nivel2_VT'] != undefined ? userExportAgresso['Nivel2_VT'] : ""}</p>
                            </Grid>

                            <Grid item xs={8}>
                                <p>Company: {userExportAgresso != undefined && userExportAgresso['Empresa'] != undefined ? userExportAgresso['Empresa'] : ""}</p>
                            </Grid>

                            <Grid item xs={8}>
                                <p>Operations Zone: {userExportAgresso != undefined && userExportAgresso['Zona_Operaciones'] != undefined ? userExportAgresso['Zona_Operaciones'] : ""}</p>
                            </Grid>
                        </Grid>
                        {/*FIN DETALLES EMPLEADO*/}
                        {/*VISUALTIME EMPLEADO*/}
                        {/*<h3 style={{  marginTop: '20px' }}>VisualTime details:</h3>
                        <Grid container spacing={2} columns={16} style={{ marginTop: '3px' }}>
                            <Grid item xs={8}>
                                <p>Pending Vacations: 192 hours</p>
                            </Grid>

                            <Grid item xs={8}>
                                <p>Next vacation day: 01/09/2022</p>
                            </Grid>

                            <Grid item xs={8}>
                                <p>Vacations enjoyed: 33 hours</p>
                            </Grid>

                            <Grid item xs={8}>
                                <p>Last signing made: 24/08/2022</p>
                            </Grid>
                        </Grid>*/}
                        {/*FIN VISUALTIME EMPLEADO*/}
                        <Grid container spacing={2} columns={16} style={{ marginTop: '10px' }}>
                            {/*APLICACIONES EMPLEADO*/}
                            {/*<Grid item xs={16}>
                                <h3 style={listUserApp.length == 0 ? { display: "none" } : { display: "block", fontWeight: '600' }}>Employee requeriments:</h3>
                                <List
                                    sx={{ width: '100%', maxWidth: 360, bgcolor: 'background.paper' }}
                                    aria-label="contacts"
                                >
                                    {listUserApp.map((textItem) => {
                                        return (
                                            <>
                                                <ListItem disablePadding>
                                                    <ListItemText primary={textItem['aplication_user_type']} />
                                                    <ListItemText primary={textItem['aplication_user_id_code']} />
                                                    <ListItemText primary={textItem['aplication_user_id_name']} />
                                                </ListItem>
                                            </>
                                        );
                                    })}
                                </List>
                                </Grid>*/}
                            <Grid item xs={16}>
                                <h3 style={listUserApp.length == 0 ? { display: "none" } : { display: "block", fontWeight: '600' }}>Employee requeriments:</h3>
                                <TableModules rowsProp={listUserApp} columnsProp={columnasDataTable} loading={loading} />
                            </Grid>
                            {/*HERRAMIENTAS EMPLEADO*/}
                            {/*<Grid item xs={8}>
                                <h3 style={{ fontWeight: '600' }}>Employee tools:</h3>
                                <List
                                    sx={{ width: '100%', maxWidth: 360, bgcolor: 'background.paper' }}
                                    aria-label="contacts"
                                >
                                    {vectRepeticion.map((textItem) => {
                                        return (
                                            <>
                                                <ListItem disablePadding>
                                                    <ListItemText primary={textItem} />
                                                    <ListItemText primary={textItem} />
                                                </ListItem>
                                            </>
                                        );
                                    })}
                                </List>
                            </Grid>*/}
                        </Grid>
                    </Grid>
                </Grid>
            </div>
            <ModalSolicitarPersonal />
            <ModalAnadirPersonal />
            <AssignarPersonas />

            <Dialog open={visibilidadDialogoConfirmacion} fullWidth maxWidth='xs'>

                <DialogTitle classes={{ root: classes.customDialogTitle }} >
                    Confirmation
                </DialogTitle>
                <DialogContent>
                    Are you sure you want to remove the user from this team?
                </DialogContent>
                <DialogActions>

                    <Button variant="outlined" onClick={() => setVisibilidadDialogoConfirmacion(false)}>Decline</Button>
                    <Button variant="outlined" onClick={() => { funcionEliminaPersonaTeam(), setVisibilidadDialogoConfirmacion(false), getTeamAPI(subMisionSelected.id) }}> Confirm</Button>

                </DialogActions>

            </Dialog>
        </>
    )
}

