//**********************IMPORTACIONES****************************

import { React, useEffect, useState, useRef } from 'react'
//import * as React from 'react';

//DataGrid importaciones
import { DataGrid } from '@mui/x-data-grid';
import DeleteIcon from "@mui/icons-material/Delete";
import EditIcon from '@mui/icons-material/Edit';
import IconButton from "@mui/material/IconButton";
import FusePageCarded from '@fuse/core/FusePageCarded';
import AddCircleIcon from '@mui/icons-material/AddCircle';
import FormatListBulletedIcon from '@mui/icons-material/FormatListBulleted';
import Tooltip from '@mui/material/Tooltip';
import { useNavigate } from "react-router-dom";
import Tabs from '@mui/material/Tabs';
import Tab from '@mui/material/Tab';
import Box from '@mui/material/Box';
import CheckIcon from '@mui/icons-material/Check';
import CheckCircleIcon from '@mui/icons-material/CheckCircle';
import CancelIcon from '@mui/icons-material/Cancel';
import CloseIcon from '@mui/icons-material/Close';
import FormControl from '@mui/material/FormControl';
import Select, { SelectChangeEvent } from '@mui/material/Select';
import MenuItem from '@mui/material/MenuItem';
import {
  gridPageCountSelector,
  gridPageSelector,
  useGridApiContext,
  useGridSelector,
  GridToolbarExport,
  GridToolbarDensitySelector,
  GridToolbarFilterButton,
  GridToolbarColumnsButton,
  GridToolbarContainer
} from '@mui/x-data-grid';
import Pagination from '@mui/material/Pagination';
import Divider from '@mui/material/Divider';

//Redux importaciones
import { useDispatch, useSelector } from 'react-redux'

import {
  getPermisosSesionActualAPIAction,
  getSesionActualAPIAction
} from '../../../Managment/Users/store/actions'

import {
  mostrarRiskManagementAPIAction
} from '../../RiskManagement/store/actions'

import {
  getInventoryPcsAPIAction,
  getNotificationAPIAction,
  getSolicitudAPIAction,
  cambiarValorSeleccionAPIAction,
  verModalInsertarObservacionesAPIAction
} from '../../PeopleManagement/store/actions'

import ModalObservacionesSolicitudes from './modals/observacionesSolicitudes'

//Modales importaciones
import { getCookie } from 'app/js/generalFunctions'
import TableModules from '../../../tables/TableModules'

//**********************END_IMPORTACIONES ***********************/

export default function Request() {

  const navigate = useNavigate();

  const [numPagination, setNumPagination] = useState(10)

  //obtener el state de Redux
  const loading = useSelector(state => state.fuse.peopleManagementComponente.loading)
  const riskManagementListAPI = useSelector(state => state.fuse.riskManagementComponente.riskManagementListAPI)
  const valorTab = useSelector(state => state.fuse.peopleManagementComponente.valorTabPeople)
  const personLoginPermisos = useSelector(state => state.fuse.userComponente.personPermisos)
  const InventoryPcsListAPI = useSelector(state => state.fuse.peopleManagementComponente.listInventoryPcs)
  const personLogin = useSelector(state => state.fuse.userComponente.person)
  const listSolicitudes = useSelector(state => state.fuse.peopleManagementComponente.listSolicitudes)
  const filaSeleccionadaGridSolicitudes = useSelector(state => state.fuse.peopleManagementComponente.filaSeleccionadaGridSolicitudes)
  const verModalInsertarObservaciones = useSelector(state => state.fuse.peopleManagementComponente.verModalInsertarObservaciones)
  const modoModalInsertarObservaciones = useSelector(state => state.fuse.peopleManagementComponente.modoModalInsertarObservaciones)

  //creamos una función para hacer uso de Actions
  const dispatch = useDispatch()
  const cambiarValorTab = (valorTab) => dispatch(cambiarValorTabPeopleAction(valorTab))
  const mostrarRiskManagementAPI = () => dispatch(mostrarRiskManagementAPIAction())
  const getSolicitudAPI = (idPerson) => dispatch(getSolicitudAPIAction(idPerson));
  const cambiarValorSeleccionAPI = (idPerson) => dispatch(cambiarValorSeleccionAPIAction(idPerson));
  const verModalInsertarObservacionesAPI = (modo, valor) => dispatch(verModalInsertarObservacionesAPIAction(modo, valor))


  const columnasDataTable = [
    { Header: "ID", accessor: "id", sortable: true, type: 'string' },
    { Header: "Applicant", accessor: "origen_notification_email", sortable: true, type: 'list' },
    { Header: "Date", accessor: "fecha", sortable: true, type: 'date' },
    { Header: "Details", accessor: "observations", sortable: true, type: 'string' }
  ]



  useEffect(() => {

  }, [])

  useEffect(() => {

    if (personLogin.id != undefined && personLogin.id != "" && valorTab == 'solicitudes') {
      getSolicitudAPI(personLogin.id);
    }

  }, [personLogin, valorTab])


  function botonesSuperiores() {
    return (
      <>

        <Tooltip title="Accept" placement="top">
          <IconButton style={{ display: "inline" }} disabled={filaSeleccionadaGridSolicitudes != '' ? false : true}
            onClick={() => {
              verModalInsertarObservacionesAPI('aceptada', true)
            }}
          >
            <CheckIcon />
          </IconButton>
        </Tooltip>

        <Tooltip title="Decline" placement="top">
          <IconButton style={{ display: "inline" }} disabled={filaSeleccionadaGridSolicitudes != '' ? false : true}
            onClick={() => {
              verModalInsertarObservacionesAPI('denegada', true)
            }}
          >
            <CloseIcon />
          </IconButton>
        </Tooltip>

        <Divider />
      </>
    );
  }

  return (
    <>
      <div style={valorTab == 'solicitudes' ? { display: "block" } : { display: "none" }} >
        <Box sx={{ width: '100%' }}>

          <div style={{ width: '100%' }}>

            {botonesSuperiores()}
            <TableModules rowsProp={listSolicitudes} columnsProp={columnasDataTable} loading={loading} funcionSetValue={cambiarValorSeleccionAPI} />
          </div>
        </Box>
      </div>
      <ModalObservacionesSolicitudes />
    </>
  )
}

