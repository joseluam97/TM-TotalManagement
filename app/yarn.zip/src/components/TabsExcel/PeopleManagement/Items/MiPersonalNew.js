//**********************IMPORTACIONES****************************

import { React, useEffect, useState, useRef } from 'react'
import * as global from 'global.js';
//DataGrid importaciones
import { DataGrid } from '@mui/x-data-grid';
import DeleteIcon from "@mui/icons-material/Delete";
import EditIcon from '@mui/icons-material/Edit';
import IconButton from "@mui/material/IconButton";
import FusePageCarded from '@fuse/core/FusePageCarded';
import AddCircleIcon from '@mui/icons-material/AddCircle';
import FormatListBulletedIcon from '@mui/icons-material/FormatListBulleted';
import MoreVertIcon from '@mui/icons-material/MoreVert';
import Tooltip from '@mui/material/Tooltip';
import { useNavigate } from "react-router-dom";
import Tabs from '@mui/material/Tabs';
import Tab from '@mui/material/Tab';
import Box from '@mui/material/Box';
import Divider from '@mui/material/Divider';
import Grid from '@mui/material/Grid';
import TextField from '@mui/material/TextField';

import Card from '@mui/material/Card';
import CardContent from '@mui/material/CardContent';
import CardMedia from '@mui/material/CardMedia';
import Typography from '@mui/material/Typography';
import Autocomplete from '@mui/material/Autocomplete';
import SkipPreviousIcon from '@mui/icons-material/SkipPrevious';
import PlayArrowIcon from '@mui/icons-material/PlayArrow';
import SkipNextIcon from '@mui/icons-material/SkipNext';
import Avatar from '@mui/material/Avatar';
import List from '@mui/material/List';
import ListItem from '@mui/material/ListItem';
import ListItemButton from '@mui/material/ListItemButton';
import ListItemIcon from '@mui/material/ListItemIcon';
import ListItemText from '@mui/material/ListItemText';
import StarIcon from '@mui/icons-material/Star';
import Button from '@mui/material/Button';
import ListItemAvatar from '@mui/material/ListItemAvatar';
import FolderIcon from '@mui/icons-material/Folder';
import Select, { SelectChangeEvent } from '@mui/material/Select';
import InputLabel from '@mui/material/InputLabel';

import Menu from '@mui/material/Menu';
import MenuItem from '@mui/material/MenuItem';
import ArchiveIcon from '@mui/icons-material/Archive';
import FileCopyIcon from '@mui/icons-material/FileCopy';
import MoreHorizIcon from '@mui/icons-material/MoreHoriz';
import KeyboardArrowDownIcon from '@mui/icons-material/KeyboardArrowDown';
import SearchIcon from '@mui/icons-material/Search';

import Dialog from '@mui/material/Dialog';
import DialogActions from '@mui/material/DialogActions';
import DialogContent from '@mui/material/DialogContent';
import DialogTitle from '@mui/material/DialogTitle';
import { makeStyles } from "@material-ui/core/styles";
import TabContext from '@mui/lab/TabContext';
import TabList from '@mui/lab/TabList';
import TabPanel from '@mui/lab/TabPanel';
import Alert from '@mui/material/Alert';
import AlertTitle from '@mui/material/AlertTitle';
import { useTheme, styled } from '@mui/material/styles';

import ModalSolicitarPersonal from './modals/solicitudPersonal.js'
import ModalAnadirPersonal from './modals/anadirPersonal'
import { showMessage } from 'app/store/fuse/messageSlice'
import AssignarPersonas from '../../../Gestion/SubMision/modals/assignedPeople.js'
import TableModules from '../../../tables/TableModules'

//Redux importaciones
import { useDispatch, useSelector } from 'react-redux'

import { cambiarVisibilidadModalAssignedPeopleAPIAction } from '../../../Gestion/SubMision/store/actions'

import {
    getPermisosSesionActualAPIAction,
    getSesionActualAPIAction,
    mostrarUserAPIAction
} from '../../../Managment/Users/store/actions'

import {
    verModalSolicitudPersonalAPIAction,
    verModalAnadirPersonalAPIAction,
    getResponsablesMisionAsociadaSubMisionAPIAction,
    setMemberSelectAPIAction,
    setSubMisionSelectAPIAction,
    getMyGroupsAPIAction,
    getMyManagersAPIAction
} from '../store/actions'

import {
    getUserAgressoAPIAction,
    insertarNewUserAPI,
    obtenerContratosUserAPIAction,
    getUsuarioResponsableMisionAPIAction
} from '../../../Managment/Users/store/actions'

import {
    obtenerUserAppAPIAction,
} from '../../../Gestion/ContratoServicio/store/actions'

import {
    getTeamAPIAction,
    deleteContractUserAPIAction,
    putPersonalAsignadoContratoAPIAction
} from '../../../Gestion/SubMision/store/actions'

//Modales importaciones
import { getCookie } from 'app/js/generalFunctions'

const useStyles = makeStyles({

    customDialogTitle: {
        backgroundColor: 'rgb(37, 47, 62)',
        color: 'rgb(255, 255, 255)',
        marginBottom: '2em'
    }

});

//**********************END_IMPORTACIONES ***********************/


const vectRepeticion = [
    'Item 1',
    'Item 2',
    'Item 3',
    'Item 4'
]

export default function MiPersonal() {

    const columnasDataTable = [
        { Header: "Type", accessor: "aplication_user_type", sortable: true, type: 'list' },
        { Header: "Code", accessor: "aplication_user_id_code", sortable: true, type: 'string' },
        { Header: "Name", accessor: "aplication_user_id_name", sortable: true, type: 'string' }
    ]

    const theme = useTheme();

    const [value, setValue] = useState('1');

    const [viewMiPersonal, setViewDivision] = useState(true)
    const [viewMiMaterial, setViewSubDivision] = useState(true)
    const [userListSelected, setUserListSelected] = useState('')
    const [userExportAgresso, setUserExportAgresso] = useState('');
    const [subMisionSelected, setMisionActual] = useState('');
    const [nameSubmisionSearch, setNameSubmisionSearch] = useState('');
    const [existenDiscrepancias, setExistenDiscrepancias] = useState(false);

    const [disabledNewPeople, setDisabledNewPeople] = useState(true)
    const [disabledEditPeople, setDisabledEditPeople] = useState(true)
    const [disabledRemovePeople, setDisabledRemovePeople] = useState(true)

    const [visibilidadDialogoConfirmacion, setVisibilidadDialogoConfirmacion] = useState(false)

    const [varMenu, setVarMenu] = useState(null);
    const detallesAbierto = Boolean(varMenu);
    const menuClick = (event) => {
        setVarMenu(event.currentTarget);
    };
    const menuClose = () => {
        setVarMenu(null);
    };

    const navigate = useNavigate();
    const classes = useStyles();

    //NUEVA
    const listMyGroup = useSelector(state => state.fuse.peopleManagementComponente.listMyGroup)
    const listMyManager = useSelector(state => state.fuse.peopleManagementComponente.listMyManager)

    //obtener el state de Redux
    const loading = useSelector(state => state.fuse.peopleManagementComponente.loading)
    const valorTab = useSelector(state => state.fuse.peopleManagementComponente.valorTabPeople)
    const personLoginPermisos = useSelector(state => state.fuse.userComponente.personPermisos)
    const personLogin = useSelector(state => state.fuse.userComponente.person)
    const usersListAPI = useSelector(state => state.fuse.userComponente.usersListAPI)
    const verModalAnadirPersonal = useSelector(state => state.fuse.peopleManagementComponente.verModalAnadirPersonal)
    const userAgresso = useSelector(state => state.fuse.userComponente.userAgresso)
    const listTeams = useSelector(state => state.fuse.subMisionComponent.listTeams)
    const listUserApp = useSelector(state => state.fuse.contratoComponente.listUserApp)
    const contractUserList = useSelector(state => state.fuse.userComponente.contractUserListAPI)
    const visibilidadModalAssignedPeople = useSelector(state => state.fuse.subMisionComponent.visibilidadModalAssignedPeople)
    const contractUserListAPIRespaldo = useSelector(state => state.fuse.userComponente.contractUserListAPIRespaldo)
    const deleteUserSubMision = useSelector(state => state.fuse.subMisionComponent.deleteUserSubMision)

    const listResponsablesSubMision = useSelector(state => state.fuse.peopleManagementComponente.listResponsablesSubMision)


    //creamos una función para hacer uso de Actions
    const dispatch = useDispatch()
    const cambiarValorTab = (valorTab) => dispatch(cambiarValorTabPeopleAction(valorTab))
    const mostrarUserAPI = () => dispatch(mostrarUserAPIAction())
    const verModalSolicitudPersonalAPI = (arg) => dispatch(verModalSolicitudPersonalAPIAction(arg))
    const verModalAnadirPersonalAPI = (arg) => dispatch(verModalAnadirPersonalAPIAction(arg))
    const getTeamAPI = (arg) => dispatch(getTeamAPIAction(arg))
    const deleteContractUserAPI = (arg) => dispatch(deleteContractUserAPIAction(arg))
    const getUserAgressoAPI = (nAgresso) => dispatch(getUserAgressoAPIAction(nAgresso))
    const obtenerUserAppAPI = (datos) => dispatch(obtenerUserAppAPIAction(datos))
    const obtenerContratosUserAPI = (datos, modo) => dispatch(obtenerContratosUserAPIAction(datos, modo))
    const cambiarVisibilidadModalAssignedPeopleAPI = (arg, modoApertura) => dispatch(cambiarVisibilidadModalAssignedPeopleAPIAction(arg, modoApertura))
    const putPersonalAsignadoContratoAPI = (id, datos) => dispatch(putPersonalAsignadoContratoAPIAction(id, datos))
    const getUsuarioResponsableMisionAPI = (datos) => dispatch(getUsuarioResponsableMisionAPIAction(datos))
    const getResponsablesMisionAsociadaSubMisionAPI = (idSubMision) => dispatch(getResponsablesMisionAsociadaSubMisionAPIAction(idSubMision))
    const setMemberSelectAPI = (idMember) => dispatch(setMemberSelectAPIAction(idMember))
    const setSubMisionSelectAPI = (subMision) => dispatch(setSubMisionSelectAPIAction(subMision))

    //NUEVAS
    const getMyGroupsAPI = (idMember) => dispatch(getMyGroupsAPIAction(idMember))
    const getMyManagersAPI = (idMember) => dispatch(getMyManagersAPIAction(idMember))

    const [anchorEl, setAnchorEl] = useState(null);
    const open = Boolean(anchorEl);
    const handleClick = (event) => {
        setAnchorEl(event.currentTarget);
    };
    const handleClose = () => {
        setAnchorEl(null);
    };

    useEffect(() => {
        getMyGroupsAPI(personLogin.id)
        getMyManagersAPI(personLogin.id)
    }, [personLogin])

    useEffect(() => {

        if (personLoginPermisos.length > 0) {

            if (personLoginPermisos.find((item) => item['name'] == "Can view sub mision") == undefined) {
                navigate('/')
            }

            if (personLoginPermisos.find((item) => item['name'] == "Can add sub mision") == undefined) {
                setDisabledNewPeople(false)
            }

            if (personLoginPermisos.find((item) => item['name'] == "Can change sub mision") == undefined) {
                setDisabledEditPeople(false)
            }

            if (personLoginPermisos.find((item) => item['name'] == "Can delete sub mision") == undefined) {
                setDisabledRemovePeople(false)
            }

        }

    }, [personLoginPermisos])

    useEffect(() => {

        if (listMyGroup != undefined && listMyGroup.length != 0) {
            setNameSubmisionSearch(listMyGroup[0].code)
            setMisionActual(listMyGroup[0])
            selectUser(listMyGroup[0])
        }

    }, [listMyGroup])

    useEffect(() => {

        if (userAgresso.length != undefined) {
            if (userAgresso[0] != undefined) {
                setUserExportAgresso(userAgresso[0])
            }
            else {
                setUserExportAgresso(JSON.parse(userAgresso)['data'][0])
            }
        }

    }, [userAgresso])


    function selectUser(user) {
        setUserListSelected(user)
        getUserAgressoAPI(user['IDRes'])
        obtenerUserAppAPI(user['id'])
        //obtenerContratosUserAPI(user.id, "2")
        setMemberSelectAPI(user['id'])
    }

    const handleChange = (event, newValue) => {
        setValue(newValue);

        if (newValue == "1") {
            if (listMyGroup.length > 0) {
                selectUser(listMyGroup[0])
            }
        }
        if (newValue == "2") {
            if (listMyManager.length > 0) {
                selectUser(listMyManager[0])
            }
        }
    };

    return (
        <>
            <div style={valorTab == 'miPersonalNew' ? { display: "block" } : { display: "none" }} >

                <Grid container spacing={2} columns={16}>
                    <Grid item xs={5} style={{ margin: '0px' }}>
                        {/*TARJETA*/}

                        <Box sx={{ width: '100%', typography: 'body1' }}>
                            <TabContext value={value}>
                                <Box sx={{ width: '100%', bgcolor: 'background.paper' }}>
                                    <TabList onChange={handleChange} centered>
                                        <Tab label="Dependants" value="1" />
                                        {personLogin['rolUser'] != global.rolN1 ? <Tab label="Your managers" value="2" /> : ""}
                                    </TabList>
                                </Box>
                                <TabPanel value="1">
                                    {/*MOSTRAR LA LISTA DE INTEGRANTES DE LA SUB MISION */}
                                    {listMyGroup.map((user) => {
                                        return (
                                            <>
                                                <Card sx={{ marginTop: '5px' }} onClick={() => selectUser(user)}>

                                                    <Box style={user['rol_employee'] == "permanent" ? userListSelected['id'] == user['id'] ? { backgroundColor: theme.palette.text.primary, border: "3px solid #000000", borderRadius: "20px" } : { backgroundColor: theme.palette.text.primary } : userListSelected['id'] == user['id'] ? { backgroundColor: theme.palette.secondary.main, border: "3px solid #000000", borderRadius: "20px" } : { backgroundColor: theme.palette.secondary.main }}>
                                                        <CardContent>
                                                            <div>
                                                                <Typography component="div" variant="subtitle1" color="#FFFFFF">
                                                                    {user['first_name'] + " " + user['last_name']}
                                                                </Typography>

                                                                <Typography component="div" variant="caption" color="#FFFFFF">
                                                                    {user['rolUser']} {user['nameBloquePredef'] != null ? " in " + user['nameBloquePredef'] : ''}
                                                                </Typography>
                                                            </div>
                                                        </CardContent>
                                                    </Box>
                                                </Card>
                                            </>
                                        );
                                    })}

                                    {/*FIN MOSTRAR LA LISTA DE INTEGRANTES DE LA SUB MISION */}
                                </TabPanel>
                                <TabPanel value="2">
                                    {/*MOSTRAR LA LISTA DE RESPONSABLES DE LA SUB MISION */}
                                    {listMyManager.map((user) => {
                                        return (
                                            <>
                                                <Card sx={{ marginTop: '5px' }} onClick={() => selectUser(user)}>
                                                    <Box style={userListSelected['id'] == user['id'] ? { border: "3px solid #003EFF", backgroundColor: "#000000", borderRadius: "20px" } : { backgroundColor: "#000000" }}>
                                                        <CardContent>
                                                            <div>
                                                                <Typography component="div" variant="subtitle1" color="#FFFFFF">
                                                                    {user['first_name'] + " " + user['last_name']}
                                                                </Typography>

                                                                <Typography component="div" variant="caption" color="#FFFFFF">
                                                                    {user['rolUser']} {user['nameBloquePredef'] != null ? " in " + user['nameBloquePredef'] : ''}
                                                                </Typography>
                                                            </div>
                                                        </CardContent>
                                                    </Box>
                                                </Card>
                                            </>
                                        );
                                    })}
                                    {/*FIN MOSTRAR LA LISTA DE RESPONSABLES DE LA SUB MISION */}
                                </TabPanel>
                            </TabContext>
                        </Box>

                    </Grid>

                    <Grid item xs={10} rowSpacing={20} alignItems="center">
                        {/*DETALLES EMPLEADO*/}
                        <h3 style={{ fontWeight: '600' }}>Employee details:</h3>
                        <Grid container spacing={2} columns={16} style={{ marginTop: '3px' }}>
                            <Grid item xs={8}>
                                <p>Name: {userListSelected != '' && userListSelected['first_name'] != undefined ? userListSelected['first_name'] + " " + userListSelected['last_name'] : ""}</p>
                            </Grid>

                            <Grid item xs={8}>
                                <p>Role: {userListSelected != undefined ? userListSelected['rolUser'] : ""} {userListSelected['nameBloquePredef'] != null ? " in " + userListSelected['nameBloquePredef'] : ''}</p>
                            </Grid>

                            <Grid item xs={8}>
                                <p>Email: {userListSelected != undefined ? userListSelected['email'] : ""}</p>
                            </Grid>

                            <Grid item xs={8}>
                                <p>Phone: {userListSelected != undefined ? userListSelected['phone'] : ""}</p>
                            </Grid>
                            {/*</Grid>
                        FIN DETALLES EMPLEADO*/}
                            {/*DETALLES EMPLEADO
                        <Grid container spacing={2} columns={16} style={{ marginTop: '3px' }}>*/}
                            <Grid item xs={8}>
                                <p>Level1_VT: {userExportAgresso != undefined && userExportAgresso['Nivel1_VT'] != undefined ? userExportAgresso['Nivel1_VT'] : ""}</p>
                            </Grid>

                            <Grid item xs={8}>
                                <p>Level2_VT: {userExportAgresso != undefined && userExportAgresso['Nivel2_VT'] != undefined ? userExportAgresso['Nivel2_VT'] : ""}</p>
                            </Grid>

                            <Grid item xs={8}>
                                <p>Company: {userExportAgresso != undefined && userExportAgresso['Empresa'] != undefined ? userExportAgresso['Empresa'] : ""}</p>
                            </Grid>

                            <Grid item xs={8}>
                                <p>Operations Zone: {userExportAgresso != undefined && userExportAgresso['Zona_Operaciones'] != undefined ? userExportAgresso['Zona_Operaciones'] : ""}</p>
                            </Grid>
                        </Grid>
                        {/*FIN DETALLES EMPLEADO*/}
                        {/*VISUALTIME EMPLEADO*/}
                        {/*<h3 style={{  marginTop: '20px' }}>VisualTime details:</h3>
                        <Grid container spacing={2} columns={16} style={{ marginTop: '3px' }}>
                            <Grid item xs={8}>
                                <p>Pending Vacations: 192 hours</p>
                            </Grid>

                            <Grid item xs={8}>
                                <p>Next vacation day: 01/09/2022</p>
                            </Grid>

                            <Grid item xs={8}>
                                <p>Vacations enjoyed: 33 hours</p>
                            </Grid>

                            <Grid item xs={8}>
                                <p>Last signing made: 24/08/2022</p>
                            </Grid>
                        </Grid>*/}
                        {/*FIN VISUALTIME EMPLEADO*/}
                        <Grid container spacing={2} columns={16} style={{ marginTop: '10px' }}>
                            {/*APLICACIONES EMPLEADO*/}
                            {/*<Grid item xs={16}>
                                <h3 style={listUserApp.length == 0 ? { display: "none" } : { display: "block", fontWeight: '600' }}>Employee requeriments:</h3>
                                <List
                                    sx={{ width: '100%', maxWidth: 360, bgcolor: 'background.paper' }}
                                    aria-label="contacts"
                                >
                                    {listUserApp.map((textItem) => {
                                        return (
                                            <>
                                                <ListItem disablePadding>
                                                    <ListItemText primary={textItem['aplication_user_type']} />
                                                    <ListItemText primary={textItem['aplication_user_id_code']} />
                                                    <ListItemText primary={textItem['aplication_user_id_name']} />
                                                </ListItem>
                                            </>
                                        );
                                    })}
                                </List>
                                </Grid>*/}
                            <Grid item xs={16}>
                                <h3 style={listUserApp.length == 0 ? { display: "none" } : { display: "block", fontWeight: '600' }}>Employee requeriments:</h3>
                                <div style={{ width: '100%', textAlign: 'center' }}>
                                    <Alert severity="info" style={listUserApp.length != 0 ? {} : { display: "none" }}>
                                        <AlertTitle>The following list shows all the requirements that are available to the employee</AlertTitle>
                                    </Alert>
                                </div>
                                <TableModules rowsProp={listUserApp} columnsProp={columnasDataTable} loading={loading} />
                            </Grid>
                            {/*HERRAMIENTAS EMPLEADO*/}
                            {/*<Grid item xs={8}>
                                <h3 style={{ fontWeight: '600' }}>Employee tools:</h3>
                                <List
                                    sx={{ width: '100%', maxWidth: 360, bgcolor: 'background.paper' }}
                                    aria-label="contacts"
                                >
                                    {vectRepeticion.map((textItem) => {
                                        return (
                                            <>
                                                <ListItem disablePadding>
                                                    <ListItemText primary={textItem} />
                                                    <ListItemText primary={textItem} />
                                                </ListItem>
                                            </>
                                        );
                                    })}
                                </List>
                            </Grid>*/}
                        </Grid>
                    </Grid>
                </Grid>
            </div>
            <ModalSolicitarPersonal />
            <ModalAnadirPersonal />
            <AssignarPersonas />
        </>
    )
}

