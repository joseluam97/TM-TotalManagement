//**********************IMPORTACIONES****************************
import * as global from 'global.js';
import { useEffect, useState, useRef } from 'react'
import * as React from 'react';
//DataGrid importaciones
import PropTypes from 'prop-types';
//CAMBIO
import SvgIcon from '@mui/material/SvgIcon';
import { alpha, styled } from '@mui/material/styles';
import TreeView from '@mui/lab/TreeView';
import TreeItem, { treeItemClasses } from '@mui/lab/TreeItem';
import Collapse from '@mui/material/Collapse';
import { useSpring, animated } from '@react-spring/web';
//FIN CAMBIO
import { DataGrid } from '@mui/x-data-grid';
import EditIcon from '@mui/icons-material/Edit';
import IconButton from "@mui/material/IconButton";
import FusePageCarded from '@fuse/core/FusePageCarded';
import AddCircleIcon from '@mui/icons-material/AddCircle';
import FormatListBulletedIcon from '@mui/icons-material/FormatListBulleted';
import MoreVertIcon from '@mui/icons-material/MoreVert';
import Tooltip from '@mui/material/Tooltip';
import { useNavigate } from "react-router-dom";
import Tabs from '@mui/material/Tabs';
import Tab from '@mui/material/Tab';
import Box from '@mui/material/Box';
import Divider from '@mui/material/Divider';
import Grid from '@mui/material/Grid';
import CardActions from '@mui/material/CardActions';
import TextField from '@mui/material/TextField';

import Card from '@mui/material/Card';
import CardContent from '@mui/material/CardContent';
import CardMedia from '@mui/material/CardMedia';
import Typography from '@mui/material/Typography';
import Autocomplete from '@mui/material/Autocomplete';
import SkipPreviousIcon from '@mui/icons-material/SkipPrevious';
import PlayArrowIcon from '@mui/icons-material/PlayArrow';
import SkipNextIcon from '@mui/icons-material/SkipNext';
import Avatar from '@mui/material/Avatar';
import List from '@mui/material/List';
import ListItem from '@mui/material/ListItem';
import ListItemButton from '@mui/material/ListItemButton';
import ListItemIcon from '@mui/material/ListItemIcon';
import ListItemText from '@mui/material/ListItemText';
import StarIcon from '@mui/icons-material/Star';
import Button from '@mui/material/Button';
import ListItemAvatar from '@mui/material/ListItemAvatar';
import FolderIcon from '@mui/icons-material/Folder';
import Select, { SelectChangeEvent } from '@mui/material/Select';
import InputLabel from '@mui/material/InputLabel';
import ButtonGroup from '@mui/material/ButtonGroup';
import Menu from '@mui/material/Menu';
import MenuItem from '@mui/material/MenuItem';
import ArchiveIcon from '@mui/icons-material/Archive';
import FileCopyIcon from '@mui/icons-material/FileCopy';
import MoreHorizIcon from '@mui/icons-material/MoreHoriz';
import KeyboardArrowDownIcon from '@mui/icons-material/KeyboardArrowDown';
import SearchIcon from '@mui/icons-material/Search';

import Dialog from '@mui/material/Dialog';
import DialogActions from '@mui/material/DialogActions';
import DialogContent from '@mui/material/DialogContent';
import DialogTitle from '@mui/material/DialogTitle';
import { makeStyles } from "@material-ui/core/styles";
import TabContext from '@mui/lab/TabContext';
import TabList from '@mui/lab/TabList';
import TabPanel from '@mui/lab/TabPanel';
import Alert from '@mui/material/Alert';
import AlertTitle from '@mui/material/AlertTitle';
import { useTheme } from '@mui/material/styles';

import ModalSolicitarPersonal from './modals/solicitudPersonal.js'
import ModalAnadirPersonal from './modals/anadirPersonal'
import { showMessage } from 'app/store/fuse/messageSlice'
import AssignarPersonas from '../../../Gestion/SubMision/modals/assignedPeople.js'

import {
    gridPageCountSelector,
    gridPageSelector,
    useGridApiContext,
    useGridSelector,
    GridToolbarExport,
    GridToolbarDensitySelector,
    GridToolbarFilterButton,
    GridToolbarColumnsButton,
    GridToolbarContainer
} from '@mui/x-data-grid';
import FormControl from '@mui/material/FormControl';
import Pagination from '@mui/material/Pagination';
import TableModules from '../../../tables/TableModules'

//Redux importaciones
import { useDispatch, useSelector } from 'react-redux'

import {
    getPermisosSesionActualAPIAction,
    getSesionActualAPIAction,
    mostrarUserAPIAction
} from '../../../Managment/Users/store/actions'

import {
    verModalSolicitudPersonalAPIAction,
    verModalAnadirPersonalAPIAction,
    getResponsablesMisionAsociadaSubMisionAPIAction,
    setMemberSelectAPIAction,
    setSubMisionSelectAPIAction,
    getMyGroupsAPIAction,
    getMyManagersAPIAction,
    getEstructuraPersonalAPIAction,
    getEstructuraPersonalSecundariaAPIAction,
    getUserEstructuraPersonalAPIAction,
    setSubMisionEstructuraSeleccionadaAPIAction
} from '../store/actions'

import {
    getUserAgressoAPIAction,
    insertarNewUserAPI,
    obtenerContratosUserAPIAction,
    getUsuarioResponsableMisionAPIAction
} from '../../../Managment/Users/store/actions'

import {
    obtenerUserAppAPIAction,
} from '../../../Gestion/ContratoServicio/store/actions'

import {
    getTeamAPIAction,
    deleteContractUserAPIAction,
    putPersonalAsignadoContratoAPIAction
} from '../../../Gestion/SubMision/store/actions'

import {
    putDepartamentoAPIAction,
    putDireccionDepartamentalAPIAction
} from '../../../Gestion/Departamentos/store/actions'

import {
    updateMisionPaqueteActionAPIAction
} from '../../../Gestion/PaqueteTrabajo/store/actions'

import {
    putMisionAPIAction,
    mostrarAllMisionAPIAction
} from '../../../Gestion/Mision/store/actions'

import {
    cambiarVisibilidadModalAssignedPeopleAPIAction
} from '../../../Gestion/SubMision/store/actions'


import {
    insertarLogPersonaAPIAction
} from '../../../Managment/LogCambiosPersonas/store/actions'

import {
    setValueUserSeleccionadoAPIAction,
    cambiarVisibilidadModalInsertarUserAPI
} from '../../../Managment/Users/modals/NewUser copy/store/actions'

//Modales importaciones
import { getCookie } from 'app/js/generalFunctions'

import ArrowDropDownIcon from '@mui/icons-material/ArrowDropDown';
import ArrowRightIcon from '@mui/icons-material/ArrowRight';

import DetailsUser from '../../../Managment/Users/modals/NewUser copy/DetailsUser.js'

const useStyles = makeStyles({

    customDialogTitle: {
        backgroundColor: 'rgb(37, 47, 62)',
        color: 'rgb(255, 255, 255)',
        marginBottom: '2em'
    },

    root: {
        height: 264,
        flexGrow: 1,
        maxWidth: 400,
    },

});

//**********************END_IMPORTACIONES ***********************/
function MinusSquare(props) {
    return (
        <SvgIcon fontSize="inherit" style={{ width: 14, height: 14 }} {...props}>
            {/* tslint:disable-next-line: max-line-length */}
            <path d="M22.047 22.074v0 0-20.147 0h-20.12v0 20.147 0h20.12zM22.047 24h-20.12q-.803 0-1.365-.562t-.562-1.365v-20.147q0-.776.562-1.351t1.365-.575h20.147q.776 0 1.351.575t.575 1.351v20.147q0 .803-.575 1.365t-1.378.562v0zM17.873 11.023h-11.826q-.375 0-.669.281t-.294.682v0q0 .401.294 .682t.669.281h11.826q.375 0 .669-.281t.294-.682v0q0-.401-.294-.682t-.669-.281z" />
        </SvgIcon>
    );
}

function PlusSquare(props) {
    return (
        <SvgIcon fontSize="inherit" style={{ width: 14, height: 14 }} {...props}>
            {/* tslint:disable-next-line: max-line-length */}
            <path d="M22.047 22.074v0 0-20.147 0h-20.12v0 20.147 0h20.12zM22.047 24h-20.12q-.803 0-1.365-.562t-.562-1.365v-20.147q0-.776.562-1.351t1.365-.575h20.147q.776 0 1.351.575t.575 1.351v20.147q0 .803-.575 1.365t-1.378.562v0zM17.873 12.977h-4.923v4.896q0 .401-.281.682t-.682.281v0q-.375 0-.669-.281t-.294-.682v-4.896h-4.923q-.401 0-.682-.294t-.281-.669v0q0-.401.281-.682t.682-.281h4.923v-4.896q0-.401.294-.682t.669-.281v0q.401 0 .682.281t.281.682v4.896h4.923q.401 0 .682.281t.281.682v0q0 .375-.281.669t-.682.294z" />
        </SvgIcon>
    );
}

function CloseSquare(props) {
    return (
        <SvgIcon
            className="close"
            fontSize="inherit"
            style={{ width: 14, height: 14 }}
            {...props}
        >
            {/* tslint:disable-next-line: max-line-length */}
            <path d="M17.485 17.512q-.281.281-.682.281t-.696-.268l-4.12-4.147-4.12 4.147q-.294.268-.696.268t-.682-.281-.281-.682.294-.669l4.12-4.147-4.12-4.147q-.294-.268-.294-.669t.281-.682.682-.281.696 .268l4.12 4.147 4.12-4.147q.294-.268.696-.268t.682.281 .281.669-.294.682l-4.12 4.147 4.12 4.147q.294.268 .294.669t-.281.682zM22.047 22.074v0 0-20.147 0h-20.12v0 20.147 0h20.12zM22.047 24h-20.12q-.803 0-1.365-.562t-.562-1.365v-20.147q0-.776.562-1.351t1.365-.575h20.147q.776 0 1.351.575t.575 1.351v20.147q0 .803-.575 1.365t-1.378.562v0z" />
        </SvgIcon>
    );
}

function TransitionComponent(props) {
    const style = useSpring({
        from: {
            opacity: 0,
            transform: 'translate3d(20px,0,0)',
        },
        to: {
            opacity: props.in ? 1 : 0,
            transform: `translate3d(${props.in ? 0 : 20}px,0,0)`,
        },
    });

    return (
        <animated.div style={style}>
            <Collapse {...props} />
        </animated.div>
    );
}

TransitionComponent.propTypes = {
    /**
     * Show the component; triggers the enter or exit states
     */
    in: PropTypes.bool,
};

const StyledTreeItem = styled((props) => (
    <TreeItem {...props} TransitionComponent={TransitionComponent} />
))(({ theme }) => ({
    [`& .${treeItemClasses.iconContainer}`]: {
        '& .close': {
            opacity: 0.3,
        },
    },
    [`& .${treeItemClasses.group}`]: {
        marginLeft: 15,
        paddingLeft: 18,
        borderLeft: `1px dashed ${alpha(theme.palette.text.primary, 0.4)}`,
    },
}));

export default function EstructuraPersonal() {

    const [botonAddPeopleGroup, setBotonAddPeopleGroup] = useState(true)
    const [objetoSeleccionadoGrupo, setObjetoSeleccionadoGrupo] = useState('')
    const [userAddGroup, setUserAddGroup] = useState('')
    const [tipoRolGroupMision, setTipoRolGroupMision] = useState('')
    const [vectorUserPersonalFilter, setVectorUserPersonalFilter] = useState([])
    const [numPagination, setNumPagination] = useState(10)
    const [grupoSeleccionado, setGrupoSeleccionado] = useState('')
    const [visibilidadDialogoConfirmacion, setVisibilidadDialogoConfirmacion] = useState(false)
    const [usuarioSeleccionado, setUsuarioSeleccionado] = useState('')
    const [userExportAgresso, setUserExportAgresso] = useState('');
    const [anadirPersonGroup, setAnadirPersonGroup] = useState(false)
    const [valueTab, setValueTab] = useState('1');
    const [busquedaUsuarios, setBusquedaUsuarios] = useState('');
    const [valorFilter, setValorFilter] = useState('all');

    const [disabledNewCU, setDisabledNewCU] = useState(true)
    const [disabledEditMision, setDisabledEditMision] = useState(true)
    const [disabledEditWP, setDisabledEditWP] = useState(true)
    const [disabledEditDepartamento, setDisabledEditDepartamento] = useState(true)
    const [disabledEditDireccionDepartamental, setDisabledEditDireccionDepartamental] = useState(true)

    const theme = useTheme();

    const navigate = useNavigate();
    const classes = useStyles();

    //NUEVA
    const userSeleccionado = useSelector(state => state.fuse.detallerUserComponente.userSeleccionado)
    const loading = useSelector(state => state.fuse.peopleManagementComponente.loading)
    const listMyGroup = useSelector(state => state.fuse.peopleManagementComponente.listMyGroup)
    const listMyManager = useSelector(state => state.fuse.peopleManagementComponente.listMyManager)
    const listArbolPersonal = useSelector(state => state.fuse.peopleManagementComponente.listArbolPersonal)
    const listArbolPersonalSecundario = useSelector(state => state.fuse.peopleManagementComponente.listArbolPersonalSecundario)
    const listUserEstructuraPersonal = useSelector(state => state.fuse.peopleManagementComponente.listUserEstructuraPersonal)

    //obtener el state de Redux
    const valorTab = useSelector(state => state.fuse.peopleManagementComponente.valorTabPeople)
    const personLoginPermisos = useSelector(state => state.fuse.userComponente.personPermisos)
    const personLogin = useSelector(state => state.fuse.userComponente.person)
    const usersListAPI = useSelector(state => state.fuse.userComponente.usersListAPI)
    const userAgresso = useSelector(state => state.fuse.userComponente.userAgresso)
    const listUserApp = useSelector(state => state.fuse.contratoComponente.listUserApp)

    //creamos una función para hacer uso de Actions
    const dispatch = useDispatch()
    const getMyGroupsAPI = (idMember) => dispatch(getMyGroupsAPIAction(idMember))
    const getMyManagersAPI = (idMember) => dispatch(getMyManagersAPIAction(idMember))
    const getEstructuraPersonalAPI = (idMember) => dispatch(getEstructuraPersonalAPIAction(idMember))
    const getEstructuraPersonalSecundariaAPI = (idMember) => dispatch(getEstructuraPersonalSecundariaAPIAction(idMember))
    const getUserEstructuraPersonalAPI = (idBloque, tipoBloque) => dispatch(getUserEstructuraPersonalAPIAction(idBloque, tipoBloque))
    const getUserAgressoAPI = (nAgresso) => dispatch(getUserAgressoAPIAction(nAgresso))
    const obtenerUserAppAPI = (datos) => dispatch(obtenerUserAppAPIAction(datos))
    const mostrarUserAPI = () => dispatch(mostrarUserAPIAction())

    const putDepartamentoAPI = (id, json) => dispatch(putDepartamentoAPIAction(id, json))
    const putDireccionDepartamentalAPI = (id, json) => dispatch(putDireccionDepartamentalAPIAction(id, json))
    const updateMisionPaqueteActionAPI = (id, json) => dispatch(updateMisionPaqueteActionAPIAction(id, json))
    const putMisionAPI = (id, json) => dispatch(putMisionAPIAction(id, json))
    const cambiarVisibilidadModalAssignedPeopleAPI = (valorNuevo, modoApertura) => dispatch(cambiarVisibilidadModalAssignedPeopleAPIAction(valorNuevo, modoApertura))
    const setSubMisionSelectAPI = (subMision) => dispatch(setSubMisionSelectAPIAction(subMision))
    const setSubMisionEstructuraSeleccionadaAPI = (subMision) => dispatch(setSubMisionEstructuraSeleccionadaAPIAction(subMision))
    const mostrarAllMisionAPI = (subMision) => dispatch(mostrarAllMisionAPIAction())
    const insertarLogPersonaAPI = (logAdd) => dispatch(insertarLogPersonaAPIAction(logAdd))

    const setValueUserSeleccionadoAPI = (user) => dispatch(setValueUserSeleccionadoAPIAction(user))
    const cambiarVisibilidadModalInsertarUser = (value) => dispatch(cambiarVisibilidadModalInsertarUserAPI(value))

    const [anchorEl, setAnchorEl] = useState(null);
    const open = Boolean(anchorEl);
    const handleClick = (event) => {
        setAnchorEl(event.currentTarget);
    };
    const handleClose = () => {
        setAnchorEl(null);
    };

    const columnasDataTable = [
        { Header: "Nº Agresso", accessor: "IDRes", sortable: true, type: 'string' },
        { Header: "First Name", accessor: "first_name", sortable: true, type: 'string' },
        { Header: "Last Name", accessor: "last_name", sortable: true, type: 'string' },
        { Header: "Email", accessor: "email", sortable: true, type: 'list' },
        { Header: "Rol in group", accessor: "ubicacion", sortable: true, type: 'list' }
    ]

    useEffect(() => {

        if (userAddGroup != '' && userAddGroup != null && userAddGroup.id != undefined) {
            if (grupoSeleccionado == "Mission" && tipoRolGroupMision != '') {
                setBotonAddPeopleGroup(false)
            }
            else if (grupoSeleccionado != "Mission") {
                setBotonAddPeopleGroup(false)
            }
            else {
                setBotonAddPeopleGroup(true)
            }
        }
        else {
            setBotonAddPeopleGroup(true)
        }

    })

    useEffect(() => {
        mostrarUserAPI()
        mostrarAllMisionAPI()
    }, [])

    useEffect(() => {
        //FUNCION PARA RESETEAR LOS VALORES DEL FORMULARIO
        if (anadirPersonGroup == false) {
            setUserAddGroup('')
            setTipoRolGroupMision('')
        }
    }, [anadirPersonGroup])

    useEffect(() => {
        /*getMyGroupsAPI(personLogin.id)
        getMyManagersAPI(personLogin.id)*/
        getEstructuraPersonalAPI(personLogin.id)
        getEstructuraPersonalSecundariaAPI(personLogin.id)
    }, [personLogin])

    useEffect(() => {

        if (userAgresso.length != undefined) {
            if (userAgresso[0] != undefined) {
                setUserExportAgresso(userAgresso[0])
            }
            else {
                setUserExportAgresso(JSON.parse(userAgresso)['data'][0])
            }
        }

    }, [userAgresso])

    useEffect(() => {

        if (personLoginPermisos.length > 0) {

            if (personLoginPermisos.find((item) => item['name'] == "Can change contractuser") == undefined) {
                setDisabledNewCU(false)
            }

            if (personLoginPermisos.find((item) => item['name'] == "Can change mision") == undefined) {
                setDisabledEditMision(false)
            }

            if (personLoginPermisos.find((item) => item['name'] == "Can change work package") == undefined) {
                setDisabledEditWP(false)
            }

            if (personLoginPermisos.find((item) => item['name'] == "Can change departamento") == undefined) {
                setDisabledEditDepartamento(false)
            }

            if (personLoginPermisos.find((item) => item['name'] == "Can change direccion departamental") == undefined) {
                setDisabledEditDireccionDepartamental(false)
            }

        }

    }, [personLoginPermisos])

    function selectUser(user) {
        /*setUserListSelected(user)
        getUserAgressoAPI(user['IDRes'])
        obtenerUserAppAPI(user['id'])
        setMemberSelectAPI(user['id'])*/
    }

    var groupBy = function (xs, key) {
        return xs.reduce(function (rv, x) {
            (rv[x[key]] = rv[x[key]] || []).push(x);
            return rv;
        }, {});
    };

    useEffect(() => {

        if (listUserEstructuraPersonal != undefined && listUserEstructuraPersonal.length != 0) {
            //GESTION TABLA
            setVectorUserPersonalFilter(listUserEstructuraPersonal)
        }

    }, [listUserEstructuraPersonal])

    const verPersonalAsignadoDireccionDepartamental = (direccionDepartamental) => {
        getUserEstructuraPersonalAPI(direccionDepartamental, "DireccionDepartamental")
        setGrupoSeleccionado("DireccionDepartamental")
        setObjetoSeleccionadoGrupo(direccionDepartamental)
    };

    const verPersonalAsignadoDepartamento = (departamento) => {
        getUserEstructuraPersonalAPI(departamento.id, "Departamento")
        setGrupoSeleccionado("Departamento")
        setObjetoSeleccionadoGrupo(departamento)
    };

    const verPersonalAsignadoWP = (wp) => {
        getUserEstructuraPersonalAPI(wp.id, "WP")
        setGrupoSeleccionado("WP")
        setObjetoSeleccionadoGrupo(wp)
    };

    const verPersonalAsignadoMision = (mision) => {
        getUserEstructuraPersonalAPI(mision.id, "Mission")
        setGrupoSeleccionado("Mission")
        setObjetoSeleccionadoGrupo(mision)
    };

    const verPersonalAsignadoSubMision = (subMision) => {
        getUserEstructuraPersonalAPI(subMision.id, "SubMision")
        setGrupoSeleccionado("SubMision")
        setObjetoSeleccionadoGrupo(subMision)
        //SET SUB MISION SELECCIONADA PARA LA APERTURA DE ADD PERSON TO AssignedPeople.js
        setSubMisionEstructuraSeleccionadaAPI(subMision)
    };

    function botonesSuperiores() {
        return (
            <>
                <Box sx={{ width: '100%' }}>
                    <Tooltip title="New" placement="top">
                        <IconButton>
                            <FormatListBulletedIcon variant="outlined" onClick={
                                () => {
                                    cambiarVisibilidadModalInsertarUser(true)
                                }
                            }
                                disabled={userSeleccionado != '' ? false : true}>
                            </FormatListBulletedIcon>
                        </IconButton>
                    </Tooltip>

                    <Divider />
                </Box>
            </>
        );
    }


    useEffect(() => {
        if (busquedaUsuarios != null) {

            let vectorAll = []
            if (valorFilter != "all") {
                vectorAll = listUserEstructuraPersonal.filter(elemento => elemento.ubicacion == valorFilter)
            }
            else {
                vectorAll = listUserEstructuraPersonal
            }

            if (busquedaUsuarios == "") {
                setVectorUserPersonalFilter(vectorAll)
            }
            else {
                let vectorResultados = vectorAll.filter(elemento =>
                    elemento.IDRes.includes(busquedaUsuarios) ||
                    elemento.first_name.toLowerCase().replace(" ", "").includes(busquedaUsuarios.toLowerCase().replace(" ", "")) ||
                    elemento.last_name.toLowerCase().replace(" ", "").includes(busquedaUsuarios.toLowerCase().replace(" ", "")) ||
                    elemento.email.toLowerCase().includes(busquedaUsuarios.toLowerCase()) ||
                    elemento.ubicacion.toLowerCase().replace(" ", "").includes(busquedaUsuarios.toLowerCase().replace(" ", ""))
                )
                setVectorUserPersonalFilter(vectorResultados)
            }
        }


    }, [busquedaUsuarios])

    function filterListUser(tipoFilter) {
        setValorFilter(tipoFilter)
        setBusquedaUsuarios(null)
        if (tipoFilter == "all") {
            setVectorUserPersonalFilter(listUserEstructuraPersonal)
        }
        else {
            let vectorResultados = listUserEstructuraPersonal.filter(elemento => elemento.ubicacion == tipoFilter)
            setVectorUserPersonalFilter(vectorResultados)
        }
    };

    function funcionAperturaDialog() {

        if (grupoSeleccionado == "SubMision") {
            cambiarVisibilidadModalAssignedPeopleAPI(true, 'miEquipoEstructura');
        }
        else {
            setAnadirPersonGroup(true);
        }
    }

    function anadirPersona() {
        if (grupoSeleccionado == "DireccionDepartamental") {
            let vectorResponsables = objetoSeleccionadoGrupo.responsablesDD
            vectorResponsables.push(userAddGroup.id)
            putDireccionDepartamentalAPI(objetoSeleccionadoGrupo.id, {
                id_subdivision: objetoSeleccionadoGrupo.id_subdivision,
                name: objetoSeleccionadoGrupo.name,
                code: objetoSeleccionadoGrupo.code,
                responsablesDD: vectorResponsables,
                description: objetoSeleccionadoGrupo.description
            })

            insertarLogPersonaAPI({
                persona: userAddGroup.id,
                fecha_accion: new Date().toISOString().split("T")[0],
                hora_accion: new Date().toLocaleTimeString(),
                accion: "Add",
                direccionDepartamental_relacionado: objetoSeleccionadoGrupo.id,
                descripcion: "User with IDRes:" + userAddGroup.IDRes + " added to Department " + objetoSeleccionadoGrupo.name
            })
        }

        if (grupoSeleccionado == "Departamento") {
            let vectorResponsables = objetoSeleccionadoGrupo.responsableDepartamento
            vectorResponsables.push(userAddGroup.id)
            putDepartamentoAPI(objetoSeleccionadoGrupo.id, {
                id_direccion_departamental: objetoSeleccionadoGrupo.id_direccion_departamental,
                name: objetoSeleccionadoGrupo.name,
                code: objetoSeleccionadoGrupo.code,
                responsableDepartamento: vectorResponsables,
                description: objetoSeleccionadoGrupo.description
            })

            insertarLogPersonaAPI({
                persona: userAddGroup.id,
                fecha_accion: new Date().toISOString().split("T")[0],
                hora_accion: new Date().toLocaleTimeString(),
                accion: "Add",
                departamento_relacionado: objetoSeleccionadoGrupo.id,
                descripcion: "User with IDRes:" + userAddGroup.IDRes + " added to Funcion Departamental: " + objetoSeleccionadoGrupo.name
            })
        }

        if (grupoSeleccionado == "WP") {
            let vectorResponsables = objetoSeleccionadoGrupo.responsableWP
            vectorResponsables.push(userAddGroup.id)
            updateMisionPaqueteActionAPI(objetoSeleccionadoGrupo.id, {
                id_service: objetoSeleccionadoGrupo.id_service,
                id_departamento: objetoSeleccionadoGrupo.id_departamento,
                responsableWP: vectorResponsables,
                name: objetoSeleccionadoGrupo.name,
                description: objetoSeleccionadoGrupo.description,
                code: objetoSeleccionadoGrupo.code,
                esDepartamento: objetoSeleccionadoGrupo.esDepartamento
            })

            insertarLogPersonaAPI({
                persona: userAddGroup.id,
                fecha_accion: new Date().toISOString().split("T")[0],
                hora_accion: new Date().toLocaleTimeString(),
                accion: "Add",
                wp_relacionado: objetoSeleccionadoGrupo.id,
                descripcion: "User with IDRes:" + userAddGroup.IDRes + " added to Work Package: " + objetoSeleccionadoGrupo.name
            })
        }

        if (grupoSeleccionado == "Mission") {
            if (tipoRolGroupMision == "manager") {
                let vectorResponsables = objetoSeleccionadoGrupo.responsables
                vectorResponsables.push(userAddGroup.id)
                putMisionAPI(objetoSeleccionadoGrupo.id, {
                    id_workPackage: objetoSeleccionadoGrupo.id_workPackage,
                    name: objetoSeleccionadoGrupo.name,
                    code: objetoSeleccionadoGrupo.code,
                    responsables: vectorResponsables,
                    description: objetoSeleccionadoGrupo.description,
                    site: objetoSeleccionadoGrupo.site,
                    esDepartamento: objetoSeleccionadoGrupo.esDepartamento,
                    empleados: objetoSeleccionadoGrupo.empleados,
                })

                insertarLogPersonaAPI({
                    persona: userAddGroup.id,
                    fecha_accion: new Date().toISOString().split("T")[0],
                    hora_accion: new Date().toLocaleTimeString(),
                    accion: "Add",
                    mision_relacionada: objetoSeleccionadoGrupo.id,
                    descripcion: "User with IDRes:" + userAddGroup.IDRes + " added to Mission: " + objetoSeleccionadoGrupo.name + " as Manager"
                })
            }
            else {
                let vectorEmpleados = objetoSeleccionadoGrupo.empleados
                vectorEmpleados.push(userAddGroup.id)
                putMisionAPI(objetoSeleccionadoGrupo.id, {
                    id_workPackage: objetoSeleccionadoGrupo.id_workPackage,
                    name: objetoSeleccionadoGrupo.name,
                    code: objetoSeleccionadoGrupo.code,
                    responsables: objetoSeleccionadoGrupo.responsables,
                    description: objetoSeleccionadoGrupo.description,
                    site: objetoSeleccionadoGrupo.site,
                    esDepartamento: objetoSeleccionadoGrupo.esDepartamento,
                    empleados: vectorEmpleados
                })

                insertarLogPersonaAPI({
                    persona: userAddGroup.id,
                    fecha_accion: new Date().toISOString().split("T")[0],
                    hora_accion: new Date().toLocaleTimeString(),
                    accion: "Add",
                    mision_relacionada: objetoSeleccionadoGrupo.id,
                    descripcion: "User with IDRes:" + userAddGroup.IDRes + " added to Mission: " + objetoSeleccionadoGrupo.name + " as Employee"
                })
            }

        }

    }

    const handleChange = (event, newValue) => {
        setValorFilter('all')
        setValueTab(newValue);
    };

    return (
        <>
            <div style={valorTab == 'estructuraPersonal' ? { display: "block" } : { display: "none" }} >
                <Grid container spacing={0} columns={30}>
                    <Grid item xs={10} style={{ margin: '0px' }}>
                        {/*TARJETA*/}

                        <Box sx={{ width: '100%', typography: 'body1' }}>
                            <TabContext value={valueTab}>
                                <Box sx={{ width: '100%', bgcolor: 'background.paper' }}>
                                    <TabList onChange={handleChange} centered>
                                        <Tab label="Your access structures" value="1" />
                                        {personLogin['rolUser'] != global.rolN1 ? <Tab label="Extra structures" value="2" /> : ""}
                                    </TabList>
                                </Box>
                                <TabPanel value="1">
                                    {/*ARBOL ESTRUCTURA */}
                                    <TreeView
                                        aria-label="customized"
                                        defaultExpanded={['1']}
                                        //defaultCollapseIcon={<MinusSquare />}
                                        //defaultExpandIcon={<PlusSquare />}
                                        //defaultEndIcon={<CloseSquare />}

                                        defaultCollapseIcon={<ArrowDropDownIcon />}
                                        defaultExpandIcon={<ArrowRightIcon />}
                                        defaultEndIcon={<div style={{ width: 24 }} />}

                                        sx={{ height: 264, flexGrow: 1, maxWidth: 400, overflowY: 'auto' }}
                                    >
                                        {/*MANAGER DE AREAS*/}
                                        {personLogin['rolUser'] == global.rolN4 ?
                                            listArbolPersonal.map((elemento) => (

                                                <StyledTreeItem onClick={() => { verPersonalAsignadoWP(elemento['wp']['id']); }} nodeId={"wp-" + elemento['wp']['id']} label={elemento['wp']['name']}>
                                                    {elemento['mision'].map((mision) => (
                                                        <StyledTreeItem onClick={() => { verPersonalAsignadoMision(mision); }} nodeId={"mision-" + mision['id']} label={mision['name']}>
                                                            {mision['subMisiones'].map((subMision) => (
                                                                <StyledTreeItem onClick={() => { verPersonalAsignadoSubMision(subMision); }} nodeId={"subMision-" + subMision['id']} label={subMision['name']}>
                                                                </StyledTreeItem>
                                                            ))}
                                                        </StyledTreeItem>
                                                    ))}
                                                </StyledTreeItem>


                                            )) : ''}

                                        {/*COORDINADOR DE AREA y COORDINADOR DE EQUIPO*/}
                                        {personLogin['rolUser'] == global.rolN5 || personLogin['rolUser'] == global.rolN6 ?
                                            listArbolPersonal.map((elemento) => (

                                                <StyledTreeItem onClick={() => { verPersonalAsignadoMision(elemento['mision']['id']); }} nodeId={"mision-" + elemento['mision']['id']} label={elemento['mision']['name']}>
                                                    {elemento['subMision'].map((subMision) => (
                                                        <StyledTreeItem onClick={() => { verPersonalAsignadoSubMision(subMision); }} nodeId={"subMision-" + subMision['id']} label={subMision['name']}>
                                                        </StyledTreeItem>
                                                    ))}
                                                </StyledTreeItem>


                                            )) : ''}

                                        {/*TEAM LEADER y TECNICO*/}
                                        {personLogin['rolUser'] == global.rolN8 || personLogin['rolUser'] == global.rolN7 ?
                                            listArbolPersonal.map((elemento) => (

                                                <StyledTreeItem onClick={() => { verPersonalAsignadoSubMision(elemento['subMision']['id']); }} nodeId={"subMision-" + elemento['subMision']['id']} label={elemento['subMision']['name']}>
                                                </StyledTreeItem>


                                            )) : ''}


                                        {/*RESPONSABLE FUNCION DEPARTAMENTAL*/}
                                        {personLogin['rolUser'] == global.rolN3 ?
                                            listArbolPersonal.map((elemento) => (

                                                <StyledTreeItem onClick={() => { verPersonalAsignadoDepartamento(elemento['departamento']['id']); }} nodeId={"departamento-" + elemento['departamento']['id']} label={elemento['departamento']['name']}>
                                                    {elemento['wp'].map((wp) => (
                                                        <StyledTreeItem onClick={() => { verPersonalAsignadoWP(wp); }} nodeId={"wp-" + wp['id']} label={wp['name']}>
                                                            {wp['misiones'].map((mision) => (
                                                                <StyledTreeItem onClick={() => { verPersonalAsignadoMision(mision); }} nodeId={"mision-" + mision['id']} label={mision['name']}>
                                                                    {mision['subMisiones'].map((subMision) => (
                                                                        <StyledTreeItem onClick={() => { verPersonalAsignadoSubMision(subMision); }} nodeId={"subMision-" + subMision['id']} label={subMision['name']}>
                                                                        </StyledTreeItem>
                                                                    ))}
                                                                </StyledTreeItem>
                                                            ))}
                                                        </StyledTreeItem>
                                                    ))}
                                                </StyledTreeItem>





                                            )) : ''}

                                        {/*DIRECCION DEPARTAMENTAL*/}
                                        {personLogin['rolUser'] == global.rolN2 ?
                                            listArbolPersonal.map((elemento) => (

                                                <StyledTreeItem onClick={() => { verPersonalAsignadoDireccionDepartamental(elemento['direccionDepartamental']['id']); }} nodeId={"direccionDepartamental-" + elemento['direccionDepartamental']['id']} label={elemento['direccionDepartamental']['name']}>
                                                    {elemento['departamento'].map((departamento) => (
                                                        <StyledTreeItem onClick={() => { verPersonalAsignadoDepartamento(departamento); }} nodeId={"departamento-" + departamento['id']} label={departamento['name']}>
                                                            {departamento['wp'].map((wp) => (
                                                                <StyledTreeItem onClick={() => { verPersonalAsignadoWP(wp); }} nodeId={"wp-" + wp['id']} label={wp['name']}>
                                                                    {wp['misiones'].map((mision) => (
                                                                        <StyledTreeItem onClick={() => { verPersonalAsignadoMision(mision); }} nodeId={"mision-" + mision['id']} label={mision['name']}>
                                                                            {mision['subMisiones'].map((subMision) => (
                                                                                <StyledTreeItem onClick={() => { verPersonalAsignadoSubMision(subMision); }} nodeId={"subMision-" + subMision['id']} label={subMision['name']}>
                                                                                </StyledTreeItem>
                                                                            ))}
                                                                        </StyledTreeItem>
                                                                    ))}
                                                                </StyledTreeItem>
                                                            ))}
                                                        </StyledTreeItem>
                                                    ))}
                                                </StyledTreeItem>

                                            )) : ''}


                                        {personLogin['rolUser'] == global.rolN1 ?
                                            listArbolPersonal.map((elemento) => (
                                                <StyledTreeItem nodeId={"subDivision-" + elemento['subDivision']['id']} label={elemento['subDivision']['name']}>
                                                    {elemento['direccionDepartamental'].map((direccionDepartamental) => (
                                                        <StyledTreeItem onClick={() => { verPersonalAsignadoDireccionDepartamental(direccionDepartamental['id']); }} nodeId={"direccionDepartamental-" + direccionDepartamental['id']} label={direccionDepartamental['name']}>
                                                            {direccionDepartamental['departamento'].map((departamento) => (
                                                                <StyledTreeItem onClick={() => { verPersonalAsignadoDepartamento(departamento); }} nodeId={"departamento-" + departamento['id']} label={departamento['name']}>
                                                                    {departamento['wp'].map((wp) => (
                                                                        <StyledTreeItem onClick={() => { verPersonalAsignadoWP(wp); }} nodeId={"wp-" + wp['id']} label={wp['name']}>
                                                                            {wp['misiones'].map((mision) => (
                                                                                <StyledTreeItem onClick={() => { verPersonalAsignadoMision(mision); }} nodeId={"mision-" + mision['id']} label={mision['name']}>
                                                                                    {mision['subMisiones'].map((subMision) => (
                                                                                        <StyledTreeItem onClick={() => { verPersonalAsignadoSubMision(subMision); }} nodeId={"subMision-" + subMision['id']} label={subMision['name']}>
                                                                                        </StyledTreeItem>
                                                                                    ))}
                                                                                </StyledTreeItem>
                                                                            ))}
                                                                        </StyledTreeItem>
                                                                    ))}
                                                                </StyledTreeItem>
                                                            ))}
                                                        </StyledTreeItem>
                                                    ))}
                                                </StyledTreeItem>

                                            )) : ''}


                                    </TreeView>
                                </TabPanel>
                                {/*ARBOL ADICIONALES */}
                                <TabPanel value="2">
                                    <TreeView
                                        aria-label="customized"
                                        defaultExpanded={['1']}
                                        //defaultCollapseIcon={<MinusSquare />}
                                        //defaultExpandIcon={<PlusSquare />}
                                        //defaultEndIcon={<CloseSquare />}

                                        defaultCollapseIcon={<ArrowDropDownIcon />}
                                        defaultExpandIcon={<ArrowRightIcon />}
                                        defaultEndIcon={<div style={{ width: 24 }} />}

                                        sx={{ height: 264, flexGrow: 1, maxWidth: 400, overflowY: 'auto' }}
                                    >
                                        {/*SUB MISIONES EXTRAS */}
                                        {listArbolPersonalSecundario['subMision'] != undefined ?
                                            listArbolPersonalSecundario['subMision'].map((elemento) => (
                                                <StyledTreeItem onClick={() => { verPersonalAsignadoSubMision(elemento); }} nodeId={"subMisionSecundaria-" + elemento['id']} label={elemento['name']}>
                                                </StyledTreeItem>

                                            )) : ''}

                                        {/*MISIONES EXTRAS */}
                                        {listArbolPersonalSecundario['mision'] != undefined ?
                                            listArbolPersonalSecundario['mision'].map((elemento) => (

                                                <StyledTreeItem onClick={() => { verPersonalAsignadoMision(elemento); }} nodeId={"misionSecundaria-" + elemento['id']} label={elemento['name']}>
                                                    {elemento['subMisiones'].map((subMision) => (
                                                        <StyledTreeItem onClick={() => { verPersonalAsignadoSubMision(subMision); }} nodeId={"subMisionSecundaria-" + subMision['id']} label={subMision['name']}>
                                                        </StyledTreeItem>
                                                    ))}
                                                </StyledTreeItem>


                                            )) : ''}

                                        {/*WP EXTRAS */}
                                        {listArbolPersonalSecundario['wp'] != undefined ?
                                            listArbolPersonalSecundario['wp'].map((elemento) => (
                                                <StyledTreeItem onClick={() => { verPersonalAsignadoWP(elemento); }} nodeId={"wpSecundaria-" + elemento['id']} label={elemento['name']}>
                                                    {elemento['misiones'].map((mision) => (
                                                        <StyledTreeItem onClick={() => { verPersonalAsignadoMision(mision); }} nodeId={"misionSecundaria-" + mision['id']} label={mision['name']}>
                                                            {mision['subMisiones'].map((subMision) => (
                                                                <StyledTreeItem onClick={() => { verPersonalAsignadoSubMision(subMision); }} nodeId={"subMisionSecundaria-" + subMision['id']} label={subMision['name']}>
                                                                </StyledTreeItem>
                                                            ))}
                                                        </StyledTreeItem>
                                                    ))}
                                                </StyledTreeItem>
                                            )) : ''}


                                    </TreeView>
                                </TabPanel>
                            </TabContext>
                        </Box>


                    </Grid>

                    <Grid item xs={19} alignItems="center">
                        {/*{listUserEstructuraPersonal.map((elemento) => (
                            <h2>{elemento['IDRes']} - {elemento['first_name']} {elemento['last_name']}</h2>
                        ))}*/}
                        <Box sx={{ width: '100%' }}>
                            <div style={{ width: '100%' }}>

                                {(grupoSeleccionado == "DireccionDepartamental" && disabledEditDireccionDepartamental == true) ||
                                    (grupoSeleccionado == "Departamento" && disabledEditDepartamento == true) ||
                                    (grupoSeleccionado == "WP" && disabledEditWP == true) ||
                                    (grupoSeleccionado == "Mission" && disabledEditMision == true) ||
                                    (grupoSeleccionado == "SubMision" && disabledNewCU == true) ?
                                    <Box
                                        sx={{
                                            display: 'flex',
                                            flexDirection: 'column',
                                            alignItems: 'center',
                                            '& > *': {
                                                m: 1,
                                            },
                                        }}
                                    >
                                        <Button variant="contained" onClick={() => { funcionAperturaDialog() }}>Add user in {grupoSeleccionado}</Button>
                                    </Box> : ''}

                            </div>

                            <div style={listUserEstructuraPersonal.length == 0 ? { display: "none", width: '100%' } : { display: "block", width: '100%' }}>
                                <Box
                                    sx={{
                                        display: 'flex',
                                        flexDirection: 'column',
                                        alignItems: 'center',
                                        '& > *': {
                                            m: 1,
                                        },
                                    }}

                                >

                                    <ButtonGroup size="small" aria-label="small button group">
                                        {grupoSeleccionado == "DireccionDepartamental" ? <Button style={valorFilter == "direccionDepartamental" ? { color: '#FFFFFF', backgroundColor: theme.palette.text.primary } : {}} onClick={() => { filterListUser('direccionDepartamental') }}>{global.rolN2}</Button> : ''}
                                        {grupoSeleccionado == "Departamento" || grupoSeleccionado == "DireccionDepartamental" ? <Button style={valorFilter == "departamento" ? { color: '#FFFFFF', backgroundColor: theme.palette.text.primary } : {}} onClick={() => { filterListUser('departamento') }}>{global.rolN3}</Button> : ''}
                                        {grupoSeleccionado == "WP" || grupoSeleccionado == "Departamento" || grupoSeleccionado == "DireccionDepartamental" ? <Button style={valorFilter == "wp" ? { color: '#FFFFFF', backgroundColor: theme.palette.text.primary } : {}} onClick={() => { filterListUser('wp') }}>{global.rolN4}</Button> : ''}
                                        {grupoSeleccionado == "Mission" || grupoSeleccionado == "WP" || grupoSeleccionado == "Departamento" || grupoSeleccionado == "DireccionDepartamental" ? <Button style={valorFilter == "responsableMision" ? { color: '#FFFFFF', backgroundColor: theme.palette.text.primary } : {}} onClick={() => { filterListUser('responsableMision') }}>{global.rolN5}</Button> : ''}
                                        {grupoSeleccionado == "Mission" || grupoSeleccionado == "WP" || grupoSeleccionado == "Departamento" || grupoSeleccionado == "DireccionDepartamental" ? <Button style={valorFilter == "empleadoMision" ? { color: '#FFFFFF', backgroundColor: theme.palette.text.primary } : {}} onClick={() => { filterListUser('empleadoMision') }}>{global.rolN6}</Button> : ''}
                                        {grupoSeleccionado == "SubMision" || grupoSeleccionado == "Mission" || grupoSeleccionado == "WP" || grupoSeleccionado == "Departamento" || grupoSeleccionado == "DireccionDepartamental" ? <Button style={valorFilter == "teamLeader" ? { color: '#FFFFFF', backgroundColor: theme.palette.text.primary } : {}} onClick={() => { filterListUser('teamLeader') }}>{global.rolN7}</Button> : ''}
                                        {grupoSeleccionado == "SubMision" || grupoSeleccionado == "Mission" || grupoSeleccionado == "WP" || grupoSeleccionado == "Departamento" || grupoSeleccionado == "DireccionDepartamental" ? <Button style={valorFilter == "tecnico" ? { color: '#FFFFFF', backgroundColor: theme.palette.text.primary } : {}} onClick={() => { filterListUser('tecnico') }}>{global.rolN8}</Button> : ''}
                                        <Button style={valorFilter == "all" ? { color: '#FFFFFF', backgroundColor: theme.palette.text.primary } : {}} onClick={() => { filterListUser('all') }}>All</Button>
                                    </ButtonGroup>

                                    <div style={{ width: '100%' }}>
                                        <TextField
                                            id="observaciones"
                                            label="Search"
                                            value={busquedaUsuarios != null ? busquedaUsuarios : ''}
                                            size="small"
                                            fullWidth
                                            onChange={e => setBusquedaUsuarios(e.target.value)}
                                        />
                                    </div>
                                </Box>

                                {botonesSuperiores()}
                                <TableModules rowsProp={vectorUserPersonalFilter} columnsProp={columnasDataTable} loading={loading} funcionSetValue={setValueUserSeleccionadoAPI} />

                            </div>

                        </Box>
                    </Grid>
                </Grid>
            </div>

            <Dialog open={anadirPersonGroup} fullWidth maxWidth='xs'>

                <DialogTitle classes={{ root: classes.customDialogTitle }} >
                    Add user in {grupoSeleccionado} - {objetoSeleccionadoGrupo.name}
                </DialogTitle>
                <DialogContent>
                    <Box>

                        <Grid container spacing={2} columns={8} style={{ marginTop: '3px' }}>
                            <Grid item xs={8}>

                                <Autocomplete
                                    id="tags-outlined"
                                    options={usersListAPI}
                                    getOptionLabel={(option) => option.first_name + " " + option.last_name}
                                    onChange={(event, value) => setUserAddGroup(value)}
                                    filterSelectedOptions
                                    renderInput={(params) => (
                                        <TextField
                                            {...params}
                                            label="User"
                                            placeholder="User"
                                            size="small"
                                            fullWidth
                                            onChange={e => { setUserAddGroup(e.target.value); }}
                                        />
                                    )}
                                />
                            </Grid>
                            <Grid style={grupoSeleccionado == "Mission" ? { display: "block" } : { display: "none" }} item xs={8}>
                                <FormControl fullWidth>
                                    <InputLabel id="demo-simple-select-label">Type rol</InputLabel>
                                    <Select
                                        labelId="demo-simple-select-label"
                                        id="rol"
                                        label="Type rol"
                                        size="small"
                                        fullWidth
                                        onChange={e => { setTipoRolGroupMision(e.target.value); }}
                                    >


                                        <MenuItem value={"manager"}>Manager</MenuItem>
                                        <MenuItem value={"empleado"}>Employee</MenuItem>

                                    </Select>
                                </FormControl>
                            </Grid>
                        </Grid>
                    </Box>
                </DialogContent>
                <DialogActions>
                    <Button variant="outlined" onClick={() => setAnadirPersonGroup(false)}>Close</Button>
                    <Button variant="outlined" disabled={botonAddPeopleGroup} onClick={() => { anadirPersona(), setAnadirPersonGroup(false) }}>Add</Button>
                </DialogActions>

            </Dialog>
            <DetailsUser />
        </>
    )
}

/*

*/
