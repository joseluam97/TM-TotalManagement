import {

    // COMPONENTE PRINCIPAL ------------------

    CAMBIAR_VALOR_TAB_PEOPLE,
    CAMBIAR_VALOR_TAB_PEOPLE_EXITO,
    CAMBIAR_VALOR_TAB_PEOPLE_ERROR,


} from './types';
import axios from 'axios'
import { showMessage } from 'app/store/fuse/messageSlice'
import {getCookie} from 'app/js/generalFunctions'

//Constantes globales
const urlRiskManagementApi = process.env.REACT_APP_URL_DJANGO + "/api/risk_management/"
const urlRiskManagementByContractApi = process.env.REACT_APP_URL_DJANGO + "/api/risk_management/persona/"
const urlSubdivisionApi = process.env.REACT_APP_URL_DJANGO + "/api/subdivision/"
const urlNotificacionesApi  = process.env.REACT_APP_URL_DJANGO + "/api/notifications/"
const urlPostCorreo  = process.env.REACT_APP_URL_DJANGO + "/api/sendEmail/"
const urlInventoryPcs = process.env.REACT_APP_URL_DJANGO + "/api/external_data/"
const urlTeamAPI = process.env.REACT_APP_URL_DJANGO + "/api/team/"

//************************ CAMBIAR SELECCION GRID ACTION**********************************************

export function cambiarValorTabPeopleAction(valorNuevo) {

    return (dispatch) => {
        dispatch (cambiarValorTabPeople())

        try {
            dispatch (cambiarValorTabPeopleExito(valorNuevo))
            

        } catch (error) {

            dispatch (cambiarValorTabPeopleError(true))
        }

    }

}

const cambiarValorTabPeople = () => ({
    type: CAMBIAR_VALOR_TAB_PEOPLE,
    payload: true

})

const cambiarValorTabPeopleExito = valorNuevo => ({
    type: CAMBIAR_VALOR_TAB_PEOPLE_EXITO,
    payload: valorNuevo

})

const cambiarValorTabPeopleError = estado => ({
  type: CAMBIAR_VALOR_TAB_PEOPLE_ERROR,
  payload: estado
})