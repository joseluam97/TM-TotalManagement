//**********************IMPORTACIONES****************************

import { React, useEffect, useState, useRef } from 'react'
import Button from '@mui/material/Button';
import TextField from '@mui/material/TextField';
import Dialog from '@mui/material/Dialog';
import DialogActions from '@mui/material/DialogActions';
import DialogContent from '@mui/material/DialogContent';
import DialogTitle from '@mui/material/DialogTitle';
import { makeStyles } from "@material-ui/core/styles";
import Autocomplete from '@mui/material/Autocomplete';
import Stepper from '@mui/material/Stepper';
import Step from '@mui/material/Step';
import StepLabel from '@mui/material/StepLabel';
import ArrowCircleRightIcon from '@mui/icons-material/ArrowCircleRight';
import Divider from '@mui/material/Divider';
import store from "app/store/index"
import List from '@mui/material/List';
import InputLabel from '@mui/material/InputLabel';
import Select from '@mui/material/Select';
import MenuItem from '@mui/material/MenuItem';
import OutlinedInput from '@mui/material/OutlinedInput';
import FormControl from '@mui/material/FormControl';
import SearchIcon from '@mui/icons-material/Search';
import Checkbox from '@mui/material/Checkbox';
import FormControlLabel from '@mui/material/FormControlLabel';

import { showMessage } from 'app/store/fuse/messageSlice'

//Grid importaciones
import Box from '@mui/material/Box';
import Grid from '@mui/material/Grid';

import { getCookie } from 'app/js/generalFunctions'

import {
    verModalInsertarObservacionesAPIAction,
    postCorreoSolicitudPersonalAPIAction,
    insertarNewNotificationAPIAction,
    putNotificationAPIAction
} from '../../store/actions'

import {
    getSesionActualAPIAction,
    mostrarUserAPIAction
} from '../../../../Managment/Users/store/actions'

//Redux importaciones
import { useDispatch, useSelector } from 'react-redux'

const useStyles = makeStyles({

    customDialogTitle: {
        backgroundColor: 'rgb(37, 47, 62)',
        color: 'rgb(255, 255, 255)',
        marginBottom: '2em'
    }

});

export default function ModalObservacionesSolicitudes(props) {

    const classes = useStyles();
    const dispatch = useDispatch();

    const verModalInsertarObservaciones = useSelector(state => state.fuse.peopleManagementComponente.verModalInsertarObservaciones)
    const modoModalInsertarObservaciones = useSelector(state => state.fuse.peopleManagementComponente.modoModalInsertarObservaciones)
    const personLogin = useSelector(state => state.fuse.userComponente.person)
    const listSolicitudes = useSelector(state => state.fuse.peopleManagementComponente.listSolicitudes)
    const filaSeleccionadaGridSolicitudes = useSelector(state => state.fuse.peopleManagementComponente.filaSeleccionadaGridSolicitudes)

    const [observaciones, setObservaciones] = useState('');

    const verModalInsertarObservacionesAPI = (modo, valor) => dispatch(verModalInsertarObservacionesAPIAction(modo, valor))
    const postCorreoSolicitudPersonalAPI = (cuerpoMensaje) => dispatch(postCorreoSolicitudPersonalAPIAction(cuerpoMensaje));
    const putNotificationAPI = (id, notif, personLoginID) => dispatch(putNotificationAPIAction(id, notif, personLoginID));
    const insertarNewNotificationAPI = (notificacion) => dispatch(insertarNewNotificationAPIAction(notificacion));

    useEffect(() => {
        setObservaciones('')
    }, [verModalInsertarObservaciones])

    function responderSolicitud() {

        let solicitudTramita = listSolicitudes.filter(registro => registro.id == filaSeleccionadaGridSolicitudes)[0];
        if (solicitudTramita != null) {
            //ENVIO DE EMAIL INFORMATIVO
            postCorreoSolicitudPersonalAPI({
                emailEnvio: solicitudTramita.origen_notification_email,
                subject: "REQUEST ANSWERED",
                body: "User  " + personLogin.first_name + " " + personLogin.last_name + " has replied to your staff request. \n Status of the request: "+ modoModalInsertarObservaciones + "\n Remarks: "+observaciones 
            })

            //PUT NOTIFICACION
            putNotificationAPI(solicitudTramita.id, {
                origen_notification_id: solicitudTramita.origen_notification_id,
                destino_notification_id: solicitudTramita.destino_notification_id,
                fecha: solicitudTramita.fecha,
                typeNotification: solicitudTramita.typeNotification,
                active: false
            }, personLogin.id)

            //POST NOTIFICACION DE APLICACION INFORMATIVA A EL EMISOR
            let fechaActual = new Date()
            let fechaseleccionada = fechaActual.toISOString()
            let arrayFecha = fechaseleccionada.split("T")
            insertarNewNotificationAPI({
                origen_notification_id: solicitudTramita.destino_notification_id,
                destino_notification_id: solicitudTramita.origen_notification_id,
                fecha: arrayFecha[0],
                observations: "Application for personnel request "+ modoModalInsertarObservaciones +", by "+ personLogin.first_name + " " + personLogin.last_name,
                typeNotification: "informacion",
                active: true
            })
        }

        

    }

    return (
        <>

            <Dialog open={verModalInsertarObservaciones} fullWidth maxWidth='md' onClose={() => { verModalInsertarObservacionesAPI('', false) }}>

                <DialogTitle classes={{ root: classes.customDialogTitle }} >
                    {modoModalInsertarObservaciones == "aceptada" ?
                        'Indicate the details of the acceptance' :
                        'Indicates the details of the rejection'}
                </DialogTitle>
                <DialogContent>
                    <div style={{ width: "100%" }}>
                        <TextField
                            label="Observations"
                            id="observations"
                            value={observaciones}
                            size="small"
                            sx={{ m: 1, width: '100%' }}
                            rows={4}
                            multiline
                            onChange={e => setObservaciones(e.target.value)}
                        />
                    </div>
                </DialogContent>
                <DialogActions>
                    <Button variant="outlined" onClick={() => verModalInsertarObservacionesAPI('', false)}>Close</Button>
                    <Button variant="outlined" disabled={observaciones == ""} onClick={() => { responderSolicitud(), verModalInsertarObservacionesAPI('', false) }}>Send</Button>
                </DialogActions>

            </Dialog>
        </>
    );
}

