//**********************IMPORTACIONES****************************

import { React, useEffect, useState, useRef } from 'react'
import Button from '@mui/material/Button';
import TextField from '@mui/material/TextField';
import Dialog from '@mui/material/Dialog';
import DialogActions from '@mui/material/DialogActions';
import DialogContent from '@mui/material/DialogContent';
import DialogTitle from '@mui/material/DialogTitle';
import { makeStyles } from "@material-ui/core/styles";
import Autocomplete from '@mui/material/Autocomplete';
import Stepper from '@mui/material/Stepper';
import Step from '@mui/material/Step';
import StepLabel from '@mui/material/StepLabel';
import ArrowCircleRightIcon from '@mui/icons-material/ArrowCircleRight';
import Divider from '@mui/material/Divider';
import store from "app/store/index"
import List from '@mui/material/List';
import InputLabel from '@mui/material/InputLabel';
import Select from '@mui/material/Select';
import MenuItem from '@mui/material/MenuItem';
import OutlinedInput from '@mui/material/OutlinedInput';
import FormControl from '@mui/material/FormControl';
import SearchIcon from '@mui/icons-material/Search';
import Checkbox from '@mui/material/Checkbox';
import FormControlLabel from '@mui/material/FormControlLabel';

import { showMessage } from 'app/store/fuse/messageSlice'

//Grid importaciones
import Box from '@mui/material/Box';
import Grid from '@mui/material/Grid';

import { getCookie } from 'app/js/generalFunctions'

import {
        verModalAnadirPersonalAPIAction,
        postCorreoSolicitudPersonalAPIAction,
        insertarNewNotificationAPIAction,
        getUserPeopleManagmentAPIAction
} from '../../store/actions'

import {
        getSesionActualAPIAction,
        mostrarUserAPIAction
} from '../../../../Managment/Users/store/actions'

//Redux importaciones
import { useDispatch, useSelector } from 'react-redux'

const useStyles = makeStyles({

        customDialogTitle: {
                backgroundColor: 'rgb(37, 47, 62)',
                color: 'rgb(255, 255, 255)',
                marginBottom: '0.5em'
        }

});

export default function ModalSolicitarPersonal(props) {

        const classes = useStyles();
        const dispatch = useDispatch();

        const personLogin = useSelector(state => state.fuse.userComponente.person)

        const [destinatariosOferta, setDestinatariosOferta] = useState('')
        const [observacionesActual, setObservacionesActual] = useState('')
        const [checked, setChecked] = useState(true);

        const verModalAnadirPersonal = useSelector(state => state.fuse.peopleManagementComponente.verModalAnadirPersonal)
        const listUserAccesoPeopleManagment = useSelector(state => state.fuse.peopleManagementComponente.listUserAccesoPeopleManagment)
        const usersListAPI = useSelector(state => state.fuse.userComponente.usersListAPI)

        const mostrarUserAPI = () => dispatch(mostrarUserAPIAction())
        const verModalAnadirPersonalAPI = (arg) => dispatch(verModalAnadirPersonalAPIAction(arg))
        const postCorreoSolicitudPersonalAPI = (cuerpoMensaje) => dispatch(postCorreoSolicitudPersonalAPIAction(cuerpoMensaje));
        const insertarNewNotificationAPI = (notificacion) => dispatch(insertarNewNotificationAPIAction(notificacion));
        const getUserPeopleManagmentAPI = () => dispatch(getUserPeopleManagmentAPIAction());

        useEffect(() => {
                getUserPeopleManagmentAPI()
        }, [])

        useEffect(() => {
                let destinatarios = ""
                for (let elemento in listUserAccesoPeopleManagment) {
                        if(personLogin.id != listUserAccesoPeopleManagment[elemento].id){
                                destinatarios = destinatarios + listUserAccesoPeopleManagment[elemento].email + "; "
                        }
                }

                setDestinatariosOferta(destinatarios)

        }, [listUserAccesoPeopleManagment])

        const handleChange = (event) => {
                setChecked(event.target.checked);
        };

        function ofrecerPersona() {

                if (checked == true) {
                        postCorreoSolicitudPersonalAPI({
                                emailEnvio: destinatariosOferta,
                                subject: "OFERTA DE PERSONAL",
                                body: "El usuario " + personLogin.first_name + " " + personLogin.last_name + " acaba de ofertar personal, con la siguiente descripcion: \n Descripcion: " + observacionesActual
                        })
                }

                //CREACION DE NOTIFICACION AL USUARIO
                let fechaActual = new Date()
                let fechaseleccionada = fechaActual.toISOString()
                let arrayFecha = fechaseleccionada.split("T")
                let tipoNotificacion = 'ofertaPersonal'

                for (let elemento in listUserAccesoPeopleManagment) {
                        if(personLogin.id != listUserAccesoPeopleManagment[elemento].id){
                                insertarNewNotificationAPI({
                                        origen_notification_id: personLogin.id,
                                        destino_notification_id: listUserAccesoPeopleManagment[elemento].id,
                                        fecha: arrayFecha[0],
                                        observations: "OFERTA DE PERSONAL: " + observacionesActual + " ",
                                        typeNotification: tipoNotificacion,
                                        active: true
                                })
                        }
                }

        }


        return (
                <>

                        <Dialog open={verModalAnadirPersonal} fullWidth maxWidth='md' onClose={() => { verModalAnadirPersonalAPI(false) }}>

                                <DialogTitle classes={{ root: classes.customDialogTitle }} >
                                        Offer Staff
                                </DialogTitle>
                                <DialogContent>
                                        <Grid container spacing={2} columns={16}>
                                                <Grid item xs={8}>

                                                        <TextField
                                                                id="observaciones"
                                                                label="Observations"
                                                                multiline
                                                                rows={5}
                                                                value={observacionesActual}
                                                                size="small"
                                                                sx={{ m: 1, width: '40ch' }}
                                                                onChange={e => setObservacionesActual(e.target.value)}
                                                        />

                                                </Grid>
                                                <Grid item xs={8}>
                                                        <FormControl component="fieldset">
                                                                <FormControlLabel
                                                                        value="end"
                                                                        control={<Checkbox />}
                                                                        checked={checked}
                                                                        onChange={handleChange}
                                                                        label="Notify the employee by email"
                                                                        labelPlacement="end"
                                                                />
                                                        </FormControl>
                                                </Grid>
                                        </Grid>


                                </DialogContent>
                                <DialogActions>
                                        <Button variant="outlined" onClick={() => verModalAnadirPersonalAPI(false)}>Close</Button>
                                        <Button variant="outlined" disabled={observacionesActual == ""} onClick={() => { ofrecerPersona(), verModalAnadirPersonalAPI(false) }}>Send</Button>
                                        {/*<Button variant="outlined" disabled={botonSolicitar} style={{display: crearNuevoUser == true ? 'block' : 'none' }} onClick={() => { solicitarNewUser(), verModalAnadirPersonalAPI(false) }}>Request</Button>
                                                        */}
                                </DialogActions>

                        </Dialog>
                </>
        );
}

