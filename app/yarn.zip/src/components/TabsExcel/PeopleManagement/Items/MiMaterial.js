//**********************IMPORTACIONES****************************

import { React, useEffect, useState, useRef } from 'react'
//import * as React from 'react';

//DataGrid importaciones
import { DataGrid } from '@mui/x-data-grid';
import DeleteIcon from "@mui/icons-material/Delete";
import EditIcon from '@mui/icons-material/Edit';
import IconButton from "@mui/material/IconButton";
import FusePageCarded from '@fuse/core/FusePageCarded';
import AddCircleIcon from '@mui/icons-material/AddCircle';
import FormatListBulletedIcon from '@mui/icons-material/FormatListBulleted';
import Tooltip from '@mui/material/Tooltip';
import { useNavigate } from "react-router-dom";
import Tabs from '@mui/material/Tabs';
import Tab from '@mui/material/Tab';
import Box from '@mui/material/Box';

//Redux importaciones
import { useDispatch, useSelector } from 'react-redux'

import {
  getPermisosSesionActualAPIAction
} from '../../../Managment/Users/store/actions'

import {
  mostrarRiskManagementAPIAction
} from '../../RiskManagement/store/actions'

import {
  getInventoryPcsAPIAction
} from '../../PeopleManagement/store/actions'

import TableModules from '../../../tables/TableModules'
//Modales importaciones
import { getCookie } from 'app/js/generalFunctions'

//**********************END_IMPORTACIONES ***********************/

export default function MiMaterial() {

  const navigate = useNavigate();

  //obtener el state de Redux
  const loading = useSelector(state => state.fuse.peopleManagementComponente.loading)
  const riskManagementListAPI = useSelector(state => state.fuse.riskManagementComponente.riskManagementListAPI)
  const valorTab = useSelector(state => state.fuse.peopleManagementComponente.valorTabPeople)
  const personLoginPermisos = useSelector(state => state.fuse.userComponente.personPermisos)
  const InventoryPcsListAPI = useSelector(state => state.fuse.peopleManagementComponente.listInventoryPcs)

  //creamos una función para hacer uso de Actions
  const dispatch = useDispatch()
  const cambiarValorTab = (valorTab) => dispatch(cambiarValorTabPeopleAction(valorTab))
  const mostrarRiskManagementAPI = () => dispatch(mostrarRiskManagementAPIAction())

  const [usersPcs, setusersPcs] = useState('');

  const columnasDataTable = [

    { accessor: 'id', Header: 'ID', sortable: true, type: 'string' },
    { accessor: 'PC', Header: 'PC', sortable: true, type: 'string' },
    { accessor: 'Estado', Header: 'Status', sortable: true, type: 'string' },
    { accessor: 'Agresso', Header: 'Code', sortable: true, type: 'string' },
    { accessor: 'Nombre', Header: 'Manager', sortable: true, type: 'string' },
    { accessor: 'fecha de asignacion', Header: 'Member', sortable: true, type: 'string' },
    { accessor: 'Nº Serie', Header: 'Customer', sortable: true, type: 'string' },
    { accessor: 'PN', Header: 'Site', sortable: true, type: 'string' },
    { accessor: 'Modelo', Header: 'Program', sortable: true, type: 'string' },
    { accessor: 'Tipo', Header: 'Work specification', sortable: true, type: 'string' },
    { accessor: 'Fecha Compra', Header: 'Service', sortable: true, type: 'string' },
    { accessor: 'componentes', Header: 'Number of Risks', sortable: true, type: 'string' },
    { accessor: 'observaciones', Header: 'Number of Risks', sortable: true, type: 'string' },
    { accessor: 'ITN', Header: 'Number of Risks', sortable: true, type: 'string' }

  ]


  useEffect(() => {

    var users = ['7365', '8261', '8184'] //, '8261', '8184'
    dispatch(getInventoryPcsAPIAction(users))

    //setusersPcs(JSON.parse(InventoryPcsListAPI)) //['data']
    // console.log(userPcs)

    mostrarRiskManagementAPI()

  }, [])


  return (
    <>
      <div style={valorTab == 'miMaterial' ? { display: "block" } : { display: "none" }} >
        <Box sx={{ width: '100%' }}>

          <div style={{ width: '100%' }}>
            <TableModules rowsProp={InventoryPcsListAPI.length > 0 ? JSON.parse(InventoryPcsListAPI) : null} columnsProp={columnasDataTable} loading={loading} />
          </div>
        </Box>
      </div>
    </>
  )
}

