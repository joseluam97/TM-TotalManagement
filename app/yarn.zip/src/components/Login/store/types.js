//******************** COMPONENTE PRINCIPAL *****************************************************


//OBTENER TOKEN
export const OBTENER_TOKEN = 'OBTENER_TOKEN'
export const OBTENER_TOKEN_EXITO = 'OBTENER_TOKEN_EXITO'
export const OBTENER_TOKEN_ERROR = 'OBTENER_TOKEN_ERROR'

//CHECK TOKEN
export const CHECK_TOKEN = 'OBTENER_TOKEN'
export const CHECK_TOKEN_EXITO = 'CHECK_TOKEN_EXITO'
export const CHECK_TOKEN_ERROR = 'CHECK_TOKEN_ERROR'
