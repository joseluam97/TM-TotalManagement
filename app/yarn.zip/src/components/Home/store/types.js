//******************** COMPONENTE PRINCIPAL *****************************************************


//OBTENER TOKEN
export const OBTENER_PHOTO = 'OBTENER_PHOTO'
export const OBTENER_PHOTO_EXITO = 'OBTENER_PHOTO_EXITO'
export const OBTENER_PHOTO_ERROR = 'OBTENER_PHOTO_ERROR'

