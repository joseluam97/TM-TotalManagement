import { motion } from 'framer-motion';
import SummaryWidget from './widgets/SummaryWidget.js';
import OverdueWidget from './widgets/OverdueWidget.js';
import IssuesWidget from './widgets/IssuesWidget.js';
import FeaturesWidget from './widgets/FeaturesWidget.js';
import DetallesRisk from './widgets/DetallesRisk.js';
import TaskDistributionWidget from './widgets/TaskDistributionWidget.js';
import ScheduleWidget from './widgets/ScheduleWidget.js';
import DetallesPersonas from './widgets/DetallesPersonas.js';
import DetallesMejoras from './widgets/DetallesMejoras.js';
import Avatar from '@mui/material/Avatar';
import Typography from '@mui/material/Typography';
import Button from '@mui/material/Button';
import NotificationsIcon from '@mui/icons-material/Notifications';
import { React, useEffect, useState } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import store from "app/store/index"
import { getCookie } from 'app/js/generalFunctions'
import {
  getPermisosSesionActualAPIAction,
  obtenerContratosUserAPIAction,
  getSesionActualAPIAction,
  mostrarUserAPIAction
} from '../Managment/Users/store/actions'

import {
  mostrarRiskManagementAPIAction,
  mostrarRiskManagementByContractAPIAction
} from '../TabsExcel/RiskManagement/store/actions'

import {
  consultaRmRegistrosByPersonaAction,
  mostrarRmAccionByPersonAPIAction,
  consultaRmRegistrosAction,
  mostrarRmAccionAPIAction,
  mostrarMyActionsRmAccionAPIAction,
  consultaRmRegistrosHomeAction
} from '../../components/TabsExcel/RiskManagement/modals/RmAccion/store/actions'

import{
  getImagenAPIAction
} from './store/actions'


import {
  mostrarUserAppAPIAction,
  verModalAnadirAppPersonaAPIAction
} from '../TabsExcel/PeopleManagement/Items/Aplications/store/actions'

import {
  getSolicitudAPIAction
} from '../TabsExcel/PeopleManagement/store/actions'

import {
  mostrarImprovementProposalsByContractAPIAction
} from '../TabsExcel/ImprovementProposals/store/actions'

import {
  getNotificationAPIAction
} from '../../components/TabsExcel/PeopleManagement/store/actions'

import navigationSlice from '../../app/store/fuse/navigationSlice'

export default function Home() {

  const dispatch = useDispatch()

  const [urlImage, setUrlImage] = useState('')
  const [viewRisk, setViewRisk] = useState(true)
  const [viewPeople, setViewPeople] = useState(true)
  const [viewImprovement, setViewImprovement] = useState(true)
  const [esAdministrador, setEsAdministrador] = useState(false)

  const imagenUser = useSelector(state => state.fuse.homeComponente.dataImage)
  const riskManagementListAPI = useSelector(state => state.fuse.riskManagementComponente.riskManagementListAPI)
  const contractUserList = useSelector(state => state.fuse.userComponente.contractUserListAPI)
  const contratosUserListAPI = useSelector(state => state.fuse.userComponente.contractUserListAPI)
  const rmRegistrosListAPI = useSelector(state => state.fuse.rmAccionComponente.rmRegistrosListAPI)
  const personLoginPermisos = useSelector(state => state.fuse.userComponente.personPermisos)
  const personLogin = useSelector(state => state.fuse.userComponente.person)
  const usersListAPI = useSelector(state => state.fuse.userComponente.usersListAPI)
  const listNotificactions = useSelector(state => state.fuse.peopleManagementComponente.listNotificactions)


  const mostrarRiskManagementAPI = () => dispatch(mostrarRiskManagementAPIAction())
  const mostrarRiskManagementByContractAPI = (idPersona) => dispatch(mostrarRiskManagementByContractAPIAction(idPersona))
  const mostrarRmAccionByPersonAPI = (idPersona) => dispatch(mostrarRmAccionByPersonAPIAction(idPersona))
  const obtenerContratosUserAPI = (idPersona, modo) => dispatch(obtenerContratosUserAPIAction(idPersona, modo))
  const mostrarUserAPI = () => dispatch(mostrarUserAPIAction())
  const consultaRmRegistrosByPersona = (idPerson) => dispatch(consultaRmRegistrosByPersonaAction(idPerson))
  const getImagenAPI = (valor) => dispatch(getImagenAPIAction(valor))
  const mostrarUserAppAPI = (idPerson) => dispatch(mostrarUserAppAPIAction(idPerson))
  const getSolicitudAPI = (idPerson) => dispatch(getSolicitudAPIAction(idPerson));
  const mostrarImprovementProposalsByContractAPI = (idPersona) => dispatch(mostrarImprovementProposalsByContractAPIAction(idPersona))
  const getNotificationAPI = (idPerson) => dispatch(getNotificationAPIAction(idPerson));
  const consultaRmRegistrosHome= () => dispatch(consultaRmRegistrosHomeAction())
  const mostrarRmAccionAPI = () => dispatch(mostrarRmAccionAPIAction())
  const mostrarMyActionsRmAccionAPI = (idPerson) => dispatch(mostrarMyActionsRmAccionAPIAction(idPerson));

  const container = {
    show: {
      transition: {
        staggerChildren: 0.1,
      },
    },
  };

  const item = {
    hidden: { opacity: 0, y: 20 },
    show: { opacity: 1, y: 0 },
  };

  useEffect(() => {

    if (personLogin.id != undefined && personLoginPermisos.length > 0) {

      //OBTENER LAS ACCIONES EN LAS QUE ESTOY COMO MANAGER
      mostrarMyActionsRmAccionAPI(personLogin.id)

      if (personLoginPermisos.find((item) => item['name'] == "Can See All Risk") != undefined) {
        mostrarRiskManagementAPI()
        consultaRmRegistrosHome()
        mostrarRmAccionAPI()
      }
      else {
        mostrarRiskManagementByContractAPI(personLogin.id)
        consultaRmRegistrosByPersona(personLogin.id)
        mostrarRmAccionByPersonAPI(personLogin.id)
      }


      if (personLoginPermisos.find((item) => item['name'] == "Can view risk management") == undefined) {
        setViewRisk(false)
      }

      if (personLoginPermisos.find((item) => item['name'] == "Can view sub mision") == undefined) {
        setViewPeople(false)
      }

      if (personLoginPermisos.find((item) => item['name'] == "Can view improvement") == undefined) {
        setViewImprovement(false)
      }

      if(personLogin.is_superuser == true){
        setEsAdministrador(true)
      }

      obtenerContratosUserAPI(personLogin.id, "1")
      mostrarUserAPI()
      

      //OBTENER LAS APLICACIONES DE MI EQUIPO
      mostrarUserAppAPI(personLogin.id)

      //OBTENER MIS REQUEST
      getSolicitudAPI(personLogin.id);

      //OBTENER PROPUESTAS DE MEJORA
      mostrarImprovementProposalsByContractAPI(personLogin.id)

      //GET NOTIFICACIONES
      getNotificationAPI(personLogin.id)

    }

  }, [personLogin, personLoginPermisos])

  useEffect(() => {

    getImagenAPI(getCookie('tokenAzure'))

    //GET USER
    dispatch(getSesionActualAPIAction({
      token: getCookie('token')
    }))
    //FIN GET USER

    //GET USER
    dispatch(getPermisosSesionActualAPIAction({
      token: getCookie('token')
    }))
    //FIN GET USER

  }, [])


  return (
    <>
                                           
      <div className="flex flex-col w-full px-24 sm:px-32">
        <div className="flex flex-col sm:flex-row flex-auto sm:items-center min-w-0 my-32 sm:my-48">
          <div className="flex flex-auto items-center min-w-0">
            {/*<Avatar className="flex-0 w-64 h-64" alt="user photo" src="">
              Nombre
            </Avatar>*/}
            <div className="flex flex-col min-w-0 mx-16">
              <Typography className="text-2xl md:text-5xl font-semibold tracking-tight leading-7 md:leading-snug truncate">
                Welcome to CSI!!
              </Typography>

              <div className="flex items-center">
                <NotificationsIcon />
                <Typography className="mx-6 leading-6 truncate" color="text.secondary">
                  You have {listNotificactions.length} new notifications.
                </Typography>
              </div>
            </div>
          </div>
        </div>
      </div>

      <motion.div
        className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-24 w-full min-w-0 p-24"
        variants={container}
        initial="hidden"
        animate="show"
      >
        {/*<motion.div variants={item} style={viewRisk == true ? { display: "block" } : { display: "none" }}>
          <SummaryWidget />
        </motion.div>
        <motion.div variants={item} style={viewRisk == true ? { display: "block" } : { display: "none" }}>
          <OverdueWidget />
        </motion.div>
        <motion.div variants={item}>
          <IssuesWidget />
        </motion.div>
        <motion.div variants={item} style={esAdministrador == true ? { display: "block" } : { display: "none" }}>
          <FeaturesWidget />
          </motion.div>*/}
        <motion.div variants={item} className="sm:col-span-2 md:col-span-4 lg:col-span-2" style={viewRisk == true ? { display: "block" } : { display: "none" }}>
          <DetallesRisk />
        </motion.div>
        <motion.div variants={item} className="sm:col-span-2 md:col-span-4 lg:col-span-2" style={viewPeople == true ? { display: "block" } : { display: "none" }}>
          <DetallesPersonas />
        </motion.div>
        <motion.div variants={item} className="sm:col-span-2 md:col-span-4 lg:col-span-2" style={viewImprovement == true ? { display: "block" } : { display: "none" }}>
          <DetallesMejoras />
        </motion.div>
        {/*<motion.div variants={item} className="sm:col-span-2 md:col-span-4 lg:col-span-2">
          <ScheduleWidget />
        </motion.div>*/}
      </motion.div>
    </>
  );
}


