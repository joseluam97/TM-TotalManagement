import React, { useEffect, useState } from "react";
import { useDispatch, useSelector } from 'react-redux'
import { lighten, useTheme } from '@mui/material/styles';
import { ThemeProvider } from '@mui/styles';
import { DataGrid } from '@mui/x-data-grid';
import { CustomPagination } from '../../../src/functions.js';
import { topButtonsComponent } from '../../../src/functions.js';
import { makeStyles } from "@material-ui/core/styles";
import store from "app/store/index"


export const MUITable = ({ rows, columns, numPagination, setNumPagination, changeVisibilityInsertModalDispatch,
  sectionName,
  consultaSubdivisiones,
  addSection,
  changeSection,
  deleteSectionState,
  visibilidadDialogoConfirmacion,
  setVisibilidadDialogoConfirmacion,
  showSectionAPIDispatch,
  selectedGridRowSelector,
  changeSelectionValue,
  visibilidad,
  ModalInsertarComponent

}) => {


  const buttonsType = () => {
    return (
      changeVisibilityInsertModalDispatch ?
        () => topButtonsComponent(true, changeVisibilityInsertModalDispatch, sectionName, consultaSubdivisiones, addSection, changeSection, deleteSectionState, visibilidadDialogoConfirmacion, setVisibilidadDialogoConfirmacion, showSectionAPIDispatch, selectedGridRowSelector)
        :
        topButtonsComponent
    )
  }

  const dispatch = useDispatch();
  const theme = useTheme();
  const cambiarValorSeleccion = (valor) => dispatch(changeSelectionValue(valor.row.id));


  

  const [component, setComponent] = useState(null);
  useEffect(() => {

    if(visibilidad){


      setComponent(

  
        <div style={visibilidad == sectionName ? { display: "block" } : { display: "none" }} >
          <div style={{ width: '100%' }}>

            <DataGrid
              autoHeight

              rows={rows}
              columns={columns}
              pageSize={numPagination}
              rowsPerPageOptions={[5, 10, 20]}
              disableSelectionOnClick
              localeText={{
                toolbarExport: "",
                toolbarColumns: "",
                toolbarFilters: "",
                toolbarDensity: "",
              }}
              components={{
                Toolbar: buttonsType(),
                Pagination: () => CustomPagination(numPagination, setNumPagination),
              }}
            disableMultipleSelection={true}

            onCellClick={cambiarValorSeleccion}
            />

  
  
          </div>
  
          {ModalInsertarComponent}
  
        </div>
  
      )
    }
    else{
      setComponent(
        <ThemeProvider theme={theme}>

          <DataGrid
            rows={rows}
            columns={columns}
            pageSize={numPagination}
            rowsPerPageOptions={[5, 10, 20]}
            autoHeight
            disableSelectionOnClick
            localeText={{
              toolbarExport: "",
              toolbarColumns: "",
              toolbarFilters: "",
              toolbarDensity: "",
            }}
  
            components={{
              Toolbar: buttonsType(),
              Pagination: () => CustomPagination(numPagination, setNumPagination)
  
            }}
  
            disableMultipleSelection={true}

            // checkboxSelection
            // selectionModel={selectedRows}
            // onSelectionModelChange={handleSelectionModelChange}

          />
        </ThemeProvider>

      )
        
    }

  }, [rows, numPagination, selectedGridRowSelector, sectionName, visibilidad,changeVisibilityInsertModalDispatch])



  return component;
}