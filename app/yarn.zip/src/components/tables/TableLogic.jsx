import { React, useEffect, useState } from 'react'

//DataGrid importaciones
import { DataGrid } from '@mui/x-data-grid';
import store from "app/store/index"
import { getCookie } from 'app/js/generalFunctions'
import { useDispatch, useSelector } from 'react-redux'
import Dialog from '@mui/material/Dialog';
import DialogActions from '@mui/material/DialogActions';
import DialogContent from '@mui/material/DialogContent';
import DialogTitle from '@mui/material/DialogTitle';
import Button from '@mui/material/Button';
import { makeStyles } from "@material-ui/core/styles";
import {
    consultaSubdivisionesAction,
} from '../Gestion/Programa/store/actions.js';
import {
    getPermisosSesionActualAPIAction
} from '../Managment/Users/store/actions.js'
import { insertarLogAPIAction } from '../Managment/Log/store/actions'
import { topButtonsComponent } from '../../../src/functions.js';
import { CustomPagination } from '../../../src/functions.js';


// !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
import {
    mostrarContratoServicioAPIAction,

  } from '../Gestion/ContratoServicio/store/actions.js';

  import {
    mostrarSubDivisionsAPIAction
  } from '../Gestion/SubDivision/store/actions'
// !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

// C:\Users\JesusRoblesMendoza\Desktop\CSI\csi\app\src\components\Gestion\ContratoServicio


import { MUITable } from "../../../src/components/tables/MUITable.jsx"

const useStyles = makeStyles({
    customButtom: {
        margin: '1em'
    }
});


//END_ENTORNO_GLOBAL ************************************************

export default function TableLogic({
    visibilidad,
    changeVisibilityRequerimentsModalAsignedPeopleAPI,
    ModalInsertarComponent,
    listApiSelector,
    selectedGridRowSelector,
    showSectionAPIDispatch,
    changeSelectionValue,
    changeVisibilityInsertModalDispatch,
    updateSectionAPIDispatch,
    columDataTableProp,
    updateObject,
    sectionName,
    moduleName,
    canAdd,
}) {



    const [numPagination, setNumPagination] = useState(10)
    const [addSection, setaddSection] = useState(true);
    const [changeSection, setchangeSection] = useState(true);
    const [deleteSectionState, setdeleteSectionState] = useState(true);
    const [visibilidadDialogoConfirmacion, setVisibilidadDialogoConfirmacion] = useState(false);

    // const visibilidad = useSelector(state => state.fuse.divisionViewComponente.valorTabDivision);

    const personLoginPermisos = useSelector(state => state.fuse.userComponente.personPermisos);
    const personLogin = useSelector(state => state.fuse.userComponente.person);

    //   !!!!!!!!

    const mostrarSubDivisionesAPI = () => dispatch(mostrarSubDivisionsAPIAction());
    const mostrarContratosAPI = () => dispatch(mostrarContratoServicioAPIAction())


    //   !!!!!!!!


    const cambiarValorSeleccion = (valor) => dispatch(changeSelectionValue(valor));

    const consultaSubdivisiones = () => dispatch(consultaSubdivisionesAction())

    const classes = useStyles();
    const dispatch = useDispatch();

    function deleteSection() {
        let sectionSelected = listApiSelector.filter(registro => registro.id == selectedGridRowSelector)[0]

        const obj = {};
        for (let key in updateObject) {
            obj[updateObject[key]] = sectionSelected[updateObject[key]]
        }
        obj.active = false;
        updateSectionAPIDispatch(selectedGridRowSelector, obj)
    };



    // ! CONTRATO !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

    useEffect(() => {
        if(moduleName === "contrato"){
            mostrarSubDivisionesAPI()
            mostrarContratosAPI()
        }
    }, [])
    // ! CONTRATO !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!




    useEffect(() => {
        showSectionAPIDispatch()

        //GET USER
        store.dispatch(getPermisosSesionActualAPIAction({

            token: getCookie('token')

        }))
        //FIN GET USER

        if (moduleName === "Assembly") {
            store.dispatch(insertarLogAPIAction({
                persona: personLogin['id'],
                fecha_accion: new Date().toISOString().split("T")[0],
                hora_accion: new Date().toLocaleTimeString(),
                modulo: "Asembly",
                descripcion: "Entrance to Assembly module"
            }))
        }
    }, [])

    useEffect(() => {
        if (visibilidad == sectionName) {

            store.dispatch(insertarLogAPIAction({
                persona: personLogin['id'],
                fecha_accion: new Date().toISOString().split("T")[0],
                hora_accion: new Date().toLocaleTimeString(),
                modulo: moduleName,
                descripcion: `Entrance to ${moduleName} module`
            }))
        }
    }, [visibilidad, sectionName])

    useEffect(() => {

        if (personLoginPermisos.find((item) => item['name'] == `Can add ${canAdd}`) != undefined) {
            setaddSection(false)
        }
        if (personLoginPermisos.find((item) => item['name'] == `Can change ${canAdd}`) != undefined) {
            setchangeSection(false)
        }
        if (personLoginPermisos.find((item) => item['name'] == `Can delete ${canAdd}`) != undefined) {
            setdeleteSectionState(false)
        }
    }, [personLoginPermisos])


    const [component, setComponent] = useState(null)
    useEffect(() => {
        setComponent(
            <>
                <div style={visibilidad == sectionName ? { display: "block" } : { display: "none" }}>
                    <div style={{ width: '100%' }}>
                        < MUITable
                            rows={listApiSelector}
                            columns={columDataTableProp}
                            numPagination={numPagination}
                            setNumPagination={setNumPagination}
                            changeVisibilityInsertModalDispatch={changeVisibilityInsertModalDispatch}
                            sectionName={sectionName}
                            consultaSubdivisiones={consultaSubdivisiones}
                            addSection={addSection}
                            changeSection={changeSection}
                            deleteSectionState={deleteSectionState}
                            visibilidadDialogoConfirmacion={visibilidadDialogoConfirmacion}
                            setVisibilidadDialogoConfirmacion={setVisibilidadDialogoConfirmacion}
                            showSectionAPIDispatch={showSectionAPIDispatch}
                            selectedGridRowSelector={selectedGridRowSelector}
                            changeSelectionValue={changeSelectionValue}
                            visibilidad={visibilidad}
                            ModalInsertarComponent={ModalInsertarComponent}
                        />


                    </div>
                    {ModalInsertarComponent}
                </div>
                <Dialog open={visibilidadDialogoConfirmacion} fullWidth maxWidth='xs'>

                    <DialogTitle classes={{ root: classes.customDialogTitle }} >
                        Confirmation
                    </DialogTitle>
                    <DialogContent>
                        {`Are you sure you want to remove the ${moduleName}?`}
                    </DialogContent>
                    <DialogActions>

                        <Button variant="outlined" onClick={() => setVisibilidadDialogoConfirmacion(false)}>Decline</Button>
                        <Button variant="outlined" onClick={() => { deleteSection(); setVisibilidadDialogoConfirmacion(false); dispatch(changeSelectionValue([])) }}> Confirm</Button>

                    </DialogActions>

                </Dialog>


                {/* !!!!!!!!!!!!!!!!!! PAQUETE TRABAJO !!!!!!!!!!!!!!!!!!!!!!!!!!!! */}
                {
                    sectionName === "work package" && (
                        <>
                            <ModalInsertar />
                            <AssignedAppWP />
                        </>
                    )
                }

                {/* !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! */}

                

            </>
        )

    }, [
        ModalInsertarComponent,
        listApiSelector,
        visibilidad,
        sectionName,
        changeVisibilityInsertModalDispatch,
        visibilidadDialogoConfirmacion,
        numPagination,
        selectedGridRowSelector,

    ])


    return component && component;


}