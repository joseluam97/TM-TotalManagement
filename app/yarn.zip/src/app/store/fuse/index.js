import { combineReducers } from '@reduxjs/toolkit';
import dialog from './dialogSlice';
import message from './messageSlice';
import navbar from './navbarSlice';
import navigation from './navigationSlice';
import settings from './settingsSlice';

//IMPORTACIÓN DE REDUCERS VISTAS
import programasViewReducer from '../../../components/Managment/Programs/store/reducer'
import divisionViewReducer from '../../../components/Managment/Divisions/store/reducer'
import riskManagementViewReducer from '../../../views/tabsExcel_anterior/riskManagement/store/reducer'


//IMPORTACIÓN DE REDUCERS COMPONENTES GENERALES
import homeReducer from '../../../components/Home/store/reducer'
import programaReducer from '../../../components/Gestion/Programa/store/reducer'
import conjuntoReducer from '../../../components/Gestion/Conjunto/store/reducer'
import subDivisionReducer from '../../../components/Gestion/SubDivision/store/reducer'
import divisionReducer from '../../../components/Gestion/Division/store/reducer'
import subConjuntoReducer from '../../../components/Gestion/SubConjunto/store/reducer'
import contratoReducer from '../../../components/Gestion/ContratoServicio/store/reducer'
import misionPaqueteReducer from '../../../components/Gestion/PaqueteTrabajo/store/reducer'
import riskManagementReducer from '../../../components/TabsExcel/RiskManagement/store/reducer'
import improvementProposalsReducer from '../../../components/TabsExcel/ImprovementProposals/store/reducer'
import peopleManagementReducer from '../../../components/TabsExcel/PeopleManagement/store/reducer'
import userComponenteReducer from '../../../components/Managment/Users/store/reducer'
import deliverableReducer from '../../../components/TabsExcel/Deliverables/store/reducer'
import rmRegistroReducer from '../../../components/TabsExcel/RiskManagement/modals/RmRegistro/store/reducer'
import rmAccionReducer from '../../../components/TabsExcel/RiskManagement/modals/RmAccion/store/reducer'
import loginReducer from '../../../components/Login/store/reducer'
import tasksAccionesReducer from '../../../components/TabsExcel/RiskManagement/modals/tasks/store/reducer'
import newUserComponenteReducer from '../../../components/Managment/Users/modals/NewUser/store/reducer'
import customerReducer from '../../../components/Managment/Customers/store/reducer'
import insertPermissionsComponenteReducer from '../../../components/Managment/Users/modals/UserPermissions/store/reducer'
import taskModalSinPermisosComponenteReducer from '../../../components/Managment/Users/modals/Task/store/reducer'
import aplicationReducer from '../../../components/TabsExcel/PeopleManagement/Items/Aplications/store/reducer'
import acreditationReducer from '../../../components/TabsExcel/PeopleManagement/Items/Accreditation/store/reducer'
import misionReducer from '../../../components/Gestion/Mision/store/reducer'
import subMisionReducer from '../../../components/Gestion/SubMision/store/reducer'
import appReducer from '../../../components/Managment/App/store/reducer'
import processReducer from '../../../components/Managment/Process/store/reducer'
import categoriaReducer from '../../../components/Managment/Category/store/reducer'
import gestionAplicationReducer from '../../../components/Managment/App/store/reducer'
import actionImprovementProposalsReducer from '../../../components/TabsExcel/ImprovementProposals/ImprovementActions/store/reducer'
import kpiReducer from '../../../components/Managment/Kpi/store/reducer'
import PerformanceReducer from '../../../components/PowerBI/Performance/store/reducer'
import timeManagementReducer from '../../../components/PowerBI/TimeManagement/store/reducer'

import dataKpiReducer from '../../../components/TabsExcel/DataKpi/items/store/reducer'
import gestionDataKpiReducer from '../../../components/TabsExcel/DataKpi/store/reducer'
import logReducer from '../../../components/Managment/Log/store/reducer'
import logPersonaReducer from '../../../components/Managment/LogCambiosPersonas/store/reducer'
import departamentoViewReducer from '../../../components/Gestion/Departamentos/store/reducer'
import detallerUserReducer from '../../../components/Managment/Users/modals/NewUser copy/store/reducer'
import logRiskReducer from '../../../components/Managment/LogRisk/store/reducer'
import kanbanReducer from '../../../components/Gestion/Kanban/store/reducer'
import permisosReducer from '../../../components/Managment/Permisos/store/reducer'
import notificacionesReducer from '../../../components/Managment/Notifications/store/reducer'
import powerBIReducer from '../../../components/PowerBI/Performance/store/reducer'
import staffUserReducer from '../../../components/TabsExcel/PeopleManagement/Items/SearchUser/store/reducer'

const fuseReducers = combineReducers({

  //VISTAS
  programasView: programasViewReducer,
  riskManagementView: riskManagementViewReducer,

  //COMPONENTES GENERALES
  programaComponente: programaReducer,
  conjuntoComponente: conjuntoReducer,
  riskManagementComponente: riskManagementReducer,
  userComponente: userComponenteReducer,
  rmRegistroComponente : rmRegistroReducer,
  rmAccionComponente: rmAccionReducer,
  loginComponente: loginReducer,
  tasksAccionesComponente: tasksAccionesReducer,
  userComponente: userComponenteReducer,
  newUserComponente: newUserComponenteReducer,
  insertPermissionsComponente: insertPermissionsComponenteReducer,
  taskModalSinPermisosComponente: taskModalSinPermisosComponenteReducer,
  subConjuntoComponente: subConjuntoReducer,
  contratoComponente: contratoReducer,
  misionPaqueteComponente: misionPaqueteReducer,
  subDivisionComponente: subDivisionReducer,
  divisionViewComponente: divisionViewReducer,
  divisionComponente: divisionReducer,
  homeComponente: homeReducer,
  peopleManagementComponente: peopleManagementReducer,
  aplicationComponent: aplicationReducer,
  acreditationComponent: acreditationReducer,
  misionComponent: misionReducer,
  subMisionComponent: subMisionReducer,
  improvementProposalsComponent: improvementProposalsReducer,
  actionImprovementProposalsComponent: actionImprovementProposalsReducer,
  customerComponent: customerReducer,
  processComponent: processReducer,
  appComponent: appReducer,
  deliverableComponent: deliverableReducer,
  categoriaComponent: categoriaReducer,
  gestionAplicationComponent: gestionAplicationReducer,
  kpiComponent: kpiReducer,
  performanceComponent: PerformanceReducer,
  timeManagementComponent: timeManagementReducer,
  dataKpiComponent: dataKpiReducer,
  gestionDataKpiComponent: gestionDataKpiReducer,
  logComponent: logReducer,
  logPersonaComponent: logPersonaReducer,
  departamentoViewComponente: departamentoViewReducer,
  detallerUserComponente: detallerUserReducer,
  logRiskComponente: logRiskReducer,
  kanbanComponente: kanbanReducer,
  permisosComponente: permisosReducer,
  notificacionesComponente: notificacionesReducer,
  powerBiComponente: powerBIReducer,
  staffUserComponente: staffUserReducer,

  //OTROS
  navigation,
  settings,
  navbar,
  message,
  dialog,
});

export default fuseReducers;
