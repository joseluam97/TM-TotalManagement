module.exports = {
  eslint: {
    enable: false,
  },
};